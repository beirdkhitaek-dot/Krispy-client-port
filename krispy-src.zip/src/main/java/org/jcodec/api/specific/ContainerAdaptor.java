package org.jcodec.api.specific;

import org.jcodec.api.MediaInfo;
import org.jcodec.common.model.Packet;
import org.jcodec.common.model.Picture;

public interface ContainerAdaptor {

    Picture decodeFrame(Packet packet, byte[][] data);

    boolean canSeek(Packet data);

    byte[][] allocatePicture();

    MediaInfo getMediaInfo();
}
