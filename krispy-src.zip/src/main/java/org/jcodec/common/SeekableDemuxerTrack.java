package org.jcodec.common;

import java.io.IOException;

public interface SeekableDemuxerTrack extends DemuxerTrack {

    boolean gotoFrame(long frameNo) throws IOException;

    boolean gotoSyncFrame(long frameNo) throws IOException;

    long getCurFrame();

    void seek(double second) throws IOException;
}
