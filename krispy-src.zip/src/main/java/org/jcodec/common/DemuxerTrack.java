package org.jcodec.common;

import org.jcodec.common.model.Packet;

import java.io.IOException;

public interface DemuxerTrack {
    Packet nextFrame() throws IOException;

    DemuxerTrackMeta getMeta();
}
