package org.jcodec.common;

import java.io.IOException;
import java.nio.ByteBuffer;

import org.jcodec.common.model.Picture;

abstract public class VideoDecoder {
    private byte[][] byteBuffer;

    public abstract Picture decodeFrame(ByteBuffer data, byte[][] buffer);
    public abstract VideoCodecMeta getCodecMeta(ByteBuffer data);

    protected byte[][] getSameSizeBuffer(int[][] buffer) {
        if (byteBuffer == null || byteBuffer.length != buffer.length || byteBuffer[0].length != buffer[0].length)
            byteBuffer = ArrayUtil.create2D(buffer[0].length, buffer.length);
        return byteBuffer;
    }

    public VideoDecoder downscaled(int ratio) {
        if(ratio == 1)
            return this;
        return null;
    }
}