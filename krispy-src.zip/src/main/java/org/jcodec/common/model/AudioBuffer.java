package org.jcodec.common.model;
import org.jcodec.common.AudioFormat;

import java.nio.ByteBuffer;

public class AudioBuffer {
    protected ByteBuffer data;
    protected AudioFormat format;
    protected int nFrames;

    public AudioBuffer(ByteBuffer data, AudioFormat format, int nFrames) {
        this.data = data;
        this.format = format;
        this.nFrames = nFrames;
    }

    public ByteBuffer getData() {
        return data;
    }

    public AudioFormat getFormat() {
        return format;
    }

    public int getNFrames() {
        return nFrames;
    }
}
