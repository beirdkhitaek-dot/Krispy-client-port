package org.jcodec.codecs.mpeg4.es;
import java.nio.ByteBuffer;
import java.util.Collection;

public class ES extends NodeDescriptor {
    private int trackId;

    public ES(int trackId, Collection<Descriptor> children) {
        super(tag(), children);
        this.trackId = trackId;
    }

    public static int tag() {
        return 0x03;
    }

    protected void doWrite(ByteBuffer out) {
        out.putShort((short)trackId);
        out.put((byte)0);
        super.doWrite(out);
    }

    public int getTrackId() {
        return trackId;
    }
}
