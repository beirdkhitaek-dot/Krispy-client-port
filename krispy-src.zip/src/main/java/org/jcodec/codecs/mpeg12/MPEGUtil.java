package org.jcodec.codecs.mpeg12;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class MPEGUtil {

    public static final ByteBuffer gotoNextMarker(ByteBuffer buf) {
        return gotoMarker(buf, 0, 0x100, 0x1ff);
    }

    public static final ByteBuffer gotoMarker(ByteBuffer buf, int n, int mmin, int mmax) {
        if (!buf.hasRemaining())
            return null;

        int from = buf.position();
        ByteBuffer result = buf.slice();
        result.order(ByteOrder.BIG_ENDIAN);

        int val = 0xffffffff;
        while (buf.hasRemaining()) {
            val = (val << 8) | (buf.get() & 0xff);
            if (val >= mmin && val <= mmax) {
                if (n == 0) {
                    buf.position(buf.position() - 4);
                    result.limit(buf.position() - from);
                    break;
                }
                --n;
            }
        }
        return result;
    }

    public static final ByteBuffer nextSegment(ByteBuffer buf) {
        gotoMarker(buf, 0, 0x100, 0x1ff);
        return gotoMarker(buf, 1, 0x100, 0x1ff);
    }
}
