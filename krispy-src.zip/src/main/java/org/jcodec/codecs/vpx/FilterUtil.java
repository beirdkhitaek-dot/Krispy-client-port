package org.jcodec.codecs.vpx;
import static java.lang.Math.abs;
import static org.jcodec.codecs.vpx.FilterUtil.Segment.horizontal;
import static org.jcodec.codecs.vpx.FilterUtil.Segment.vertical;

import org.jcodec.api.NotImplementedException;
import org.jcodec.codecs.vpx.VPXMacroblock.Subblock;

public class FilterUtil {

    private static int clipPlus128(int v) {
        return (int) (clipSigned(v) + 128);
    }

    public static class Segment {

        int p0, p1, p2, p3;

        int q0, q1, q2, q3;

        public boolean isFilterRequired(int interior, int edge) {
            return ((abs(p0 - q0)<<2) + (abs(p1 - q1)>>2)) <= edge
                    && abs(p3 - p2) <= interior
                    && abs(p2 - p1) <= interior
                    && abs(p1 - p0) <= interior
                    && abs(q3 - q2) <= interior
                    && abs(q2 - q1) <= interior
                    && abs(q1 - q0) <= interior;
        }

        public boolean isHighVariance(int threshold) {
            return abs(p1 - p0) > threshold || abs(q1 - q0) > threshold;
        }

        public Segment getSigned() {
            Segment seg = new Segment();
            seg.p3 = minus128(this.p3);
            seg.p2 = minus128(this.p2);
            seg.p1 = minus128(this.p1);
            seg.p0 = minus128(this.p0);
            seg.q0 = minus128(this.q0);
            seg.q1 = minus128(this.q1);
            seg.q2 = minus128(this.q2);
            seg.q3 = minus128(this.q3);
            return seg;
        }

        public static Segment horizontal(Subblock right, Subblock left, int a) {
            Segment seg = new Segment();
            seg.p0 = left.val[3*4+a];
            seg.p1 = left.val[2*4+a];
            seg.p2 = left.val[1*4+a];
            seg.p3 = left.val[0*4+a];
            seg.q0 = right.val[0*4+a];
            seg.q1 = right.val[1*4+a];
            seg.q2 = right.val[2*4+a];
            seg.q3 = right.val[3*4+a];
            return seg;
        }

        public static Segment vertical(Subblock lower, Subblock upper, int a) {
            Segment seg = new Segment();
            seg.p0 = upper.val[a*4+3];
            seg.p1 = upper.val[a*4+2];
            seg.p2 = upper.val[a*4+1];
            seg.p3 = upper.val[a*4+0];
            seg.q0 = lower.val[a*4+0];
            seg.q1 = lower.val[a*4+1];
            seg.q2 = lower.val[a*4+2];
            seg.q3 = lower.val[a*4+3];
            return seg;
        }

        public void applyHorizontally(Subblock right, Subblock left, int a) {
            left.val[3*4+a] = this.p0;
            left.val[2*4+a] = this.p1;
            left.val[1*4+a] = this.p2;
            left.val[0*4+a] = this.p3;
            right.val[0*4+a] = this.q0;
            right.val[1*4+a] = this.q1;
            right.val[2*4+a] = this.q2;
            right.val[3*4+a] = this.q3;

        }

        public void applyVertically(Subblock lower, Subblock upper, int a) {
            upper.val[a*4+3] = this.p0;
            upper.val[a*4+2] = this.p1;
            upper.val[a*4+1] = this.p2;
            upper.val[a*4+0] = this.p3;
            lower.val[a*4+0] = this.q0;
            lower.val[a*4+1] = this.q1;
            lower.val[a*4+2] = this.q2;
            lower.val[a*4+3] = this.q3;

        }

         void filterMb(int hevThreshold, int interiorLimit, int edgeLimit) {
            Segment signedSeg = this.getSigned();
            if (signedSeg.isFilterRequired(interiorLimit, edgeLimit)) {
                if (!signedSeg.isHighVariance(hevThreshold)) {

                    int w = clipSigned(clipSigned(signedSeg.p1 - signedSeg.q1) + 3 * (signedSeg.q0 - signedSeg.p0));

                    int a = (27 * w + 63) >> 7;

                    q0 = clipPlus128(signedSeg.q0 - a);
                    p0 = clipPlus128(signedSeg.p0 + a);

                    a = (18 * w + 63) >> 7;

                    q1 = clipPlus128(signedSeg.q1 - a);
                    p1 = clipPlus128(signedSeg.p1 + a);

                    a = (9 * w + 63) >> 7;
                    q2 = clipPlus128(signedSeg.q2 - a);
                    p2 = clipPlus128(signedSeg.p2 + a);
                } else

                    this.adjust(true);
            }
        }

         public void filterSb(int hev_threshold,
                 int interior_limit,
                 int edge_limit) {
             Segment signedSeg = this.getSigned();
             if (signedSeg.isFilterRequired(interior_limit, edge_limit)) {
                 boolean hv = signedSeg.isHighVariance(hev_threshold);
                 int a = (this.adjust(hv) + 1) >> 1;
                 if (!hv) {
                     this.q1 = clipPlus128(signedSeg.q1 - a);
                     this.p1 = clipPlus128(signedSeg.p1 + a);
                 }
             }
         }

         private  int adjust(boolean use_outer_taps) {

             int p1 = minus128(this.p1);
             int p0 = minus128(this.p0);
             int q0 = minus128(this.q0);
             int q1 = minus128(this.q1);

             int a = clipSigned((use_outer_taps ? clipSigned(p1 - q1) : 0) + 3 * (q0 - p0));

             int b = (clipSigned(a + 3)) >> 3;

             a = clipSigned(a + 4) >> 3;

             this.q0 = clipPlus128(q0 - a);

             this.p0 = clipPlus128(p0 + b);

             return a;
         }
    }

    private static int clipSigned(int v) {
         return (int) (v < -128 ? -128 : (v > 127 ? 127 : v));
    }

    private static int minus128(int v) {
        return (int) (v - 128);
    }

    public static void loopFilterUV(VPXMacroblock[][] mbs, int sharpnessLevel, boolean keyFrame) {
                for (int y = 0; y < (mbs.length-2); y++) {
                    for (int x = 0; x < (mbs[0].length-2); x++) {
                        VPXMacroblock rmb = mbs[y+1][x+1];
                        VPXMacroblock bmb = mbs[y+1][x+1];
                        int loop_filter_level = rmb.filterLevel;
                        if (loop_filter_level != 0) {
                            int interior_limit = rmb.filterLevel;
                            if (sharpnessLevel > 0) {
                                interior_limit >>= sharpnessLevel > 4 ? 2 : 1;
                                if (interior_limit > 9 - sharpnessLevel)
                                    interior_limit = 9 - sharpnessLevel;
                            }
                            if (interior_limit == 0)
                                interior_limit = 1;

                            int hev_threshold = 0;
                            if (keyFrame)  {
                                if (loop_filter_level >= 40)
                                    hev_threshold = 2;
                                else if (loop_filter_level >= 15)
                                    hev_threshold = 1;
                            } else  {
                                throw new NotImplementedException("TODO: non-key frames are not supported yet.");

                            }

                            int mbedge_limit = ((loop_filter_level + 2) * 2) + interior_limit;

                            int sub_bedge_limit = (loop_filter_level * 2) + interior_limit;

                            if (x > 0) {
                                VPXMacroblock lmb = mbs[y+1][x+1-1];
                                for (int b = 0; b < 2; b++) {
                                    Subblock rsbU = rmb.uSubblocks[b][0];
                                    Subblock lsbU = lmb.uSubblocks[b][1];
                                    Subblock rsbV = rmb.vSubblocks[b][0];
                                    Subblock lsbV = lmb.vSubblocks[b][1];
                                    for (int a = 0; a < 4; a++) {
                                        Segment seg = horizontal(rsbU, lsbU, a);
                                        seg.filterMb(hev_threshold, interior_limit, mbedge_limit);
                                        seg.applyHorizontally(rsbU, lsbU, a);
                                        seg = horizontal(rsbV, lsbV, a);
                                        seg.filterMb(hev_threshold, interior_limit, mbedge_limit);
                                        seg.applyHorizontally(rsbV, lsbV, a);

                                    }
                                }
                            }

                            if (!rmb.skipFilter) {
                                for (int a = 1; a < 2; a++) {
                                    for (int b = 0; b < 2; b++) {
                                        Subblock lsbU = rmb.uSubblocks[b][a - 1];
                                        Subblock rsbU = rmb.uSubblocks[b][a];
                                        Subblock lsbV = rmb.vSubblocks[b][a - 1];
                                        Subblock rsbV = rmb.vSubblocks[b][a];
                                        for (int c = 0; c < 4; c++) {
                                            Segment seg = horizontal(rsbU, lsbU, c);
                                            seg.filterSb(hev_threshold, interior_limit, sub_bedge_limit);
                                            seg.applyHorizontally(rsbU, lsbU, c);
                                            seg = horizontal(rsbV, lsbV, c);
                                            seg.filterSb(hev_threshold, interior_limit, sub_bedge_limit);
                                            seg.applyHorizontally(rsbV, lsbV, c);
                                        }
                                    }
                                }
                            }

                            if (y > 0) {
                                VPXMacroblock tmb = mbs[y+1-1][x+1];
                                for (int b = 0; b < 2; b++) {
                                    Subblock tsbU = tmb.uSubblocks[1][b];
                                    Subblock bsbU = bmb.uSubblocks[0][b];
                                    Subblock tsbV = tmb.vSubblocks[1][b];
                                    Subblock bsbV = bmb.vSubblocks[0][b];
                                    for (int a = 0; a < 4; a++) {

                                        Segment seg = vertical(bsbU, tsbU, a);
                                        seg.filterMb(hev_threshold, interior_limit, mbedge_limit);
                                        seg.applyVertically(bsbU, tsbU, a);
                                        seg = vertical(bsbV, tsbV, a);
                                        seg.filterMb(hev_threshold, interior_limit, mbedge_limit);
                                        seg.applyVertically(bsbV, tsbV, a);
                                    }
                                }
                            }

                            if (!rmb.skipFilter) {
                                for (int a = 1; a < 2; a++) {
                                    for (int b = 0; b < 2; b++) {
                                        Subblock tsbU = bmb.uSubblocks[a-1][b];
                                        Subblock bsbU = bmb.uSubblocks[a][b];
                                        Subblock tsbV = bmb.vSubblocks[a-1][b];
                                        Subblock bsbV = bmb.vSubblocks[a][b];
                                        for (int c = 0; c < 4; c++) {
                                            Segment seg = vertical(bsbU, tsbU, c);
                                            seg.filterSb(hev_threshold, interior_limit, sub_bedge_limit);
                                            seg.applyVertically(bsbU, tsbU, c);
                                            seg = vertical(bsbV, tsbV, c);
                                            seg.filterSb(hev_threshold, interior_limit, sub_bedge_limit);
                                            seg.applyVertically(bsbV, tsbV, c);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

    public static void loopFilterY(VPXMacroblock[][] mbs, int sharpnessLevel, boolean keyFrame) {
                for (int y = 0; y < (mbs.length-2); y++) {
                    for (int x = 0; x < (mbs[0].length-2); x++) {
                        VPXMacroblock rmb = mbs[y+1][x+1];
                        VPXMacroblock bmb = mbs[y+1][x+1];
                        int loopFilterLevel = rmb.filterLevel;

                        if (loopFilterLevel != 0) {
                            int interiorLimit = rmb.filterLevel;

                            if (sharpnessLevel > 0) {
                                interiorLimit >>= sharpnessLevel > 4 ? 2 : 1;
                                if (interiorLimit > 9 - sharpnessLevel)
                                    interiorLimit = 9 - sharpnessLevel;
                            }
                            if (interiorLimit == 0)
                                interiorLimit = 1;

                            int varianceThreshold = 0;
                            if (keyFrame)  {
                                if (loopFilterLevel >= 40)
                                    varianceThreshold = 2;
                                else if (loopFilterLevel >= 15)
                                    varianceThreshold = 1;
                            } else  {
                                throw new NotImplementedException("TODO: non-key frames are not supported yet");

                            }

                            int edgeLimitMb = ((loopFilterLevel + 2) * 2) + interiorLimit;

                            int edgeLimitSb = (loopFilterLevel * 2) + interiorLimit;

                            if (x > 0) {
                                VPXMacroblock lmb = mbs[y+1][x-1+1];
                                for (int b = 0; b < 4; b++) {
                                    Subblock rsb = rmb.ySubblocks[b][0];
                                    Subblock lsb = lmb.ySubblocks[b][3];
                                    for (int a = 0; a < 4; a++) {
                                        Segment seg = horizontal(rsb, lsb, a);
                                        seg.filterMb(varianceThreshold, interiorLimit, edgeLimitMb);
                                        seg.applyHorizontally(rsb, lsb, a);
                                    }
                                }
                            }

                            if (!rmb.skipFilter) {
                                for (int a = 1; a < 4; a++) {
                                    for (int b = 0; b < 4; b++) {
                                        Subblock lsb = rmb.ySubblocks[b][a-1];
                                        Subblock rsb = rmb.ySubblocks[b][a];
                                        for (int c = 0; c < 4; c++) {
                                            Segment seg = horizontal(rsb, lsb, c);
                                            seg.filterSb(varianceThreshold, interiorLimit, edgeLimitSb);
                                            seg.applyHorizontally(rsb, lsb, c);
                                        }
                                    }
                                }
                            }

                            if (y > 0) {
                                VPXMacroblock tmb = mbs[y-1+1][x+1];
                                for (int b = 0; b < 4; b++) {
                                    Subblock tsb = tmb.ySubblocks[3][b];
                                    Subblock bsb = bmb.ySubblocks[0][b];
                                    for (int a = 0; a < 4; a++) {
                                        Segment seg = vertical(bsb, tsb, a);
                                        seg.filterMb(varianceThreshold, interiorLimit, edgeLimitMb);
                                        seg.applyVertically(bsb, tsb, a);
                                    }
                                }
                            }

                            if (!rmb.skipFilter) {
                                for (int a = 1; a < 4; a++) {
                                    for (int b = 0; b < 4; b++) {
                                        Subblock tsb = bmb.ySubblocks[a-1][b];
                                        Subblock bsb = bmb.ySubblocks[a][b];
                                        for (int c = 0; c < 4; c++) {
                                            Segment seg = vertical(bsb, tsb, c);
                                            seg.filterSb(varianceThreshold, interiorLimit, edgeLimitSb);
                                            seg.applyVertically(bsb, tsb, c);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

}
