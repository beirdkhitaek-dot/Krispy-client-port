package org.jcodec.codecs.mjpeg;
import java.nio.ByteBuffer;

public class FrameHeader {

    int headerLength;

    int bitsPerSample;

    int height;

    int width;

    int nComp;

    public static class Component {

        int index;

        int subH;

        int subV;

        int quantTable;
    }

    public int getHmax() {
        int max = 0;
        for (int i = 0; i < components.length; i++) {
            Component c = components[i];
            max = Math.max(max, c.subH);
        }
        return max;
    }

    public int getVmax() {
        int max = 0;
        for (int i = 0; i < components.length; i++) {
            Component c = components[i];
            max = Math.max(max, c.subV);
        }
        return max;
    }

    Component[] components;

    public static FrameHeader read(ByteBuffer is) {
        FrameHeader frame = new FrameHeader();
        frame.headerLength = is.getShort() & 0xffff;
        frame.bitsPerSample = is.get() & 0xff;
        frame.height = is.getShort() & 0xffff;
        frame.width = is.getShort() & 0xffff;
        frame.nComp = is.get() & 0xff;
        frame.components = new Component[frame.nComp];
        for (int i = 0; i < frame.components.length; i++) {
            Component c = frame.components[i] = new Component();
            c.index = is.get() & 0xff;
            int hv = is.get() & 0xff;
            c.subH = (hv & 0xf0) >>> 4;
            c.subV = (hv & 0x0f);
            c.quantTable = is.get() & 0xff;
        }
        return frame;
    }
}