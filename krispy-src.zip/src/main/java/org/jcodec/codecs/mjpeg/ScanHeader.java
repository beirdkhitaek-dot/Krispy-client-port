package org.jcodec.codecs.mjpeg;
import java.nio.ByteBuffer;

public class ScanHeader {

    int ls;

    int ns;

    public boolean isInterleaved() {
        return ns > 1;
    }

    public static class Component {

        int cs;

        int td;

        int ta;
    }

    Component[] components;

    int ss;

    int se;

    int ah;

    int al;

    public static ScanHeader read(ByteBuffer bb) {
        ScanHeader scan = new ScanHeader();
        scan.ls = bb.getShort() & 0xffff;
        scan.ns = bb.get() & 0xff;
        scan.components = new Component[scan.ns];
        for (int i = 0; i < scan.components.length; i++) {
            Component c = scan.components[i] = new Component();
            c.cs = bb.get() & 0xff;
            int tdta = bb.get() & 0xff;
            c.td = (tdta & 0xf0) >>> 4;
            c.ta = (tdta & 0x0f);
        }
        scan.ss = bb.get() & 0xff;
        scan.se = bb.get() & 0xff;
        int ahal = bb.get() & 0xff;
        scan.ah = (ahal & 0xf0) >>> 4;
        scan.al = (ahal & 0x0f);
        return scan;
    }
}
