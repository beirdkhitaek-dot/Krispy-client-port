package krispy.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import krispy.module.MacroCategories;
import krispy.module.settings.MacroBoolSetting;
import krispy.module.settings.MacroColorSetting;
import krispy.module.settings.MacroModeSetting;
import krispy.module.settings.MacroNumberSetting;
import krispy.modules.misc.MacroModule;
import krispy.modules.render.KrispyHandAura;
import krispy.modules.render.AccentColor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_9848;

@Environment(value=EnvType.CLIENT)
public final class HandAura
extends MacroModule {
    public static volatile HandAura active;
    private static String COLOR_THEME;
    private static String COLOR_MANUAL;
    private static final int WHITE = -1;
    private static final float SHEEN_LIFT = 0.55f;
    private static final long BREATH_NANOS = 3200000000L;
    private static final long SHEEN_NANOS = 4400000000L;
    private final MacroModeSetting colorMode = this.addSetting("color", new MacroModeSetting("Color", "Theme", "Theme", "Manual"));
    private final MacroColorSetting glowColor = this.addSetting("glow-color", new MacroColorSetting("Glow Color", -13338378));
    private final MacroNumberSetting aura = this.addSetting("aura", new MacroNumberSetting("Aura", 65.0f, 0.0f, 100.0f).step(5.0f));
    private final MacroNumberSetting reach = this.addSetting("reach", new MacroNumberSetting("Reach", 8.0f, 2.0f, 20.0f).step(1.0f));
    private final MacroNumberSetting rim = this.addSetting("rim", new MacroNumberSetting("Rim", 40.0f, 0.0f, 100.0f).step(5.0f));
    private final MacroNumberSetting sheen = this.addSetting("sheen", new MacroNumberSetting("Sheen", 25.0f, 0.0f, 100.0f).step(5.0f));
    private final MacroColorSetting sheenColor = this.addSetting("sheen-color", new MacroColorSetting("Sheen Color", -3153665));
    private final MacroBoolSetting breathe = this.addSetting("breathe", new MacroBoolSetting("Breathe", true));
    private static String[] a;

    public HandAura() {
        super("hand-aura", "Hand Aura", "Adds a glowing outline to your hand and held item.", MacroCategories.VISUALS);
        this.glowColor.visibleWhen(this::T);
        this.reach.visibleWhen(this::lmbd$new$0);
        this.sheenColor.visibleWhen(this::lmbd$new$1);
    }

    @Override
    public void onEnable() {
        active = this;
    }

    @Override
    public void onDisable() {
        active = null;
        if (RenderSystem.isOnRenderThread()) {
            KrispyHandAura.S();
            return;
        } else {
            class_310.method_1551().execute(HandAura::W);
        }
    }

    private static void W() {
        if (active != null) return;
        KrispyHandAura.S();
    }

    public static boolean C() {
        HandAura manual = active;
        if (manual == null) return false;
        if (!manual.P()) return false;
        if (!KrispyHandAura.M()) return false;
        return true;
    }

    public static void F(boolean bl) {
        if (!KrispyHandAura.a() || !bl) return;
        HandAura manual = active;
        float f = Math.max(1.0f, (float)class_310.method_1551().method_1522().field_1481 / 1080.0f);
        if (manual == null) {
            KrispyHandAura.Z(-1, 0.0f, 2.0f, 0.0f, 2.0f * f, -1, 0.0f, 0.0f);
            return;
        } else {
            long l = System.nanoTime();
            float f2 = (float)((double)(l % 4400000000L) / 4.4E9);
            int n = manual.D();
            KrispyHandAura.Z(n, manual.c(l), manual.reach.get() * f, manual.rim.get() / 100.0f, 2.0f * f, manual.U(n), manual.sheen.get() / 100.0f, f2);
        }
    }

    private boolean T() {
        return this.colorMode.is("Manual");
    }

    private int D() {
        return this.T() ? this.glowColor.argb() : AccentColor.N();
    }

    private int U(int n) {
        return this.T() ? this.sheenColor.argb() : class_9848.method_61319(0.55f, (int)n, -1);
    }

    private boolean P() {
        if (this.aura.get() > 0.0f) return true;
        if (!(this.rim.get() > 0.0f)) return false;
        return true;
    }

    private float c(long l) {
        float f = this.aura.get() / 100.0f;
        if (!this.breathe.get()) {
            return f;
        }
        double d = (double)(l % 3200000000L) / 3.2E9;
        float f2 = (float)Math.sin(d * Math.PI);
        return f * (0.6f + 0.4f * f2 * f2);
    }

    private boolean lmbd$new$1() {
        if (!(this.sheen.get() > 0.0f)) return false;
        if (!this.T()) return false;
        return true;
    }

    private boolean lmbd$new$0() {
        if (!(this.aura.get() > 0.0f)) return false;
        return true;
    }

    static {
        a = new String[]{"aura", "hand-aura", "Reach", "Glow Color", "reach", "glow-color", "Theme", "Color", "Theme", "Manual", "Sheen", "Adds a glowing outline to your hand and held item.", "Breathe", "Rim", "Sheen Color", "sheen-color", "color", "Aura", "breathe", "Hand Aura", "sheen", "Manual", "rim"};
        COLOR_MANUAL = a[9];
        COLOR_THEME = a[6];
    }
}
