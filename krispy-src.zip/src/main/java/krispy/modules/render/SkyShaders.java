package krispy.modules.render;

import java.util.Locale;
import krispy.module.Category;
import krispy.module.settings.ColorSetting;
import krispy.module.settings.Setting;
import krispy.module.settings.SettingGroup;
import krispy.modules.misc.Values;
import krispy.util.AccentColors;
import krispy.util.ShaderCompileFailed;

public class SkyShaders
extends Values {
    public static String[] stringArray;
    private static SkyShaders instance;
    private static float[] floatArray;
    private static float[] floatArray2;
    private static long time;
    private static long animationStart;
    private static String[] a;

    public SkyShaders() {
        super("Sky Shaders", Category.RENDER, "Animated procedural skies with selectable presets.");
        this.G();
        instance = this;
    }

    public static boolean R() {
        boolean bl;
        SkyShaders aurora = instance;
        return aurora != null && (bl = aurora.isEnabled());
    }

    public static String s() {
        String string;
        if (instance != null) {
            String[] stringArray = a;
            string = instance.getSetting("Preset", "Aurora");
        } else {
            string = "Aurora";
        }
        String string2 = string;
        String[] stringArray = SkyShaders.stringArray;
        int n = stringArray.length;
        int n2 = 0;
        int n3;
        while ((n3 = n2) < n) {
            int n4;
            String string3;
            boolean bl;
            if (!(bl = (string3 = stringArray[n4 = n2++]).equals(string2))) continue;
            return string3;
        }
        return "Aurora";
    }

    public static String w(String string) {
        Locale locale = Locale.ROOT;
        return string.toLowerCase(locale).replace(" ", "");
    }

    public static float l() {
        Float f = Float.valueOf(1.0f);
        float f2 = SkyShaders.K("Speed", f).floatValue();
        return SkyShaders.p(f2, 0.0f, 5.0f);
    }

    public static float o() {
        Float f = Float.valueOf(1.0f);
        float f2 = SkyShaders.K("Brightness", f).floatValue();
        return SkyShaders.p(f2, 0.0f, 3.0f);
    }

    public static float X() {
        Float f = Float.valueOf(1.0f);
        float f2 = SkyShaders.K("Intensity", f).floatValue();
        return SkyShaders.p(f2, 0.0f, 3.0f);
    }

    public static float q() {
        Float f = Float.valueOf(1.0f);
        float f2 = SkyShaders.K("Scale", f).floatValue();
        return SkyShaders.p(f2, 0.25f, 3.0f);
    }

    public static float k() {
        Float f = Float.valueOf(1.0f);
        float f2 = SkyShaders.K("Stars", f).floatValue();
        return SkyShaders.p(f2, 0.0f, 3.0f);
    }

    public static float r() {
        Float f = Float.valueOf(0.3f);
        float f2 = SkyShaders.K("Sky Rotation", f).floatValue();
        return SkyShaders.p(f2, -5.0f, 5.0f);
    }

    public static float D() {
        Float f = Float.valueOf(0.5f);
        float f2 = SkyShaders.K("Horizon Blend", f).floatValue();
        return SkyShaders.p(f2, 0.0f, 1.0f);
    }

    public static boolean A() {
        Boolean bl = true;
        return SkyShaders.K("Match Fog", bl);
    }

    public static boolean L() {
        Boolean bl = false;
        return SkyShaders.K("Sun & Moon", bl);
    }

    public static boolean H() {
        Boolean bl;
        boolean bl2;
        boolean bl3 = SkyShaders.R();
        return bl3 && (bl2 = SkyShaders.K("Hide Clouds", bl = Boolean.valueOf(true)).booleanValue());
    }

    public static boolean t() {
        Boolean bl = true;
        return SkyShaders.K("In The End", bl);
    }

    public static float M() {
        int n;
        String string;
        if (instance != null) {
            String[] stringArray = a;
            string = instance.getSetting("Resolution", "Full");
        } else {
            String[] stringArray = a;
            string = "Full";
        }
        String string2 = string;
        int n2 = -1;
        int n3 = string2.hashCode();
        switch (n3) {
            case 52458: {
                n = string2.equals("50%") ? 1 : 0;
                if (n == 0) break;
                n2 = 1;
                break;
            }
            case 54535: {
                boolean bl = string2.equals("75%");
                if (!bl) break;
                n2 = 0;
            }
        }
        n = n2;
        switch (n) {
            case 0: {
                return 0.75f;
            }
            case 1: {
                return 0.5f;
            }
            default: {
                return 1.0f;
            }
        }
    }

    private static int[] I(String string) {
        int n;
        int n2;
        int n3;
        int n4 = -1;
        int n5 = string.hashCode();
        switch (n5) {
            case -1965582497: {
                String[] stringArray = a;
                n3 = string.equals("Hcdsjg") ? 1 : 0;
                if (n3 == 0) break;
                n4 = 3;
                break;
            }
            case -1710645595: {
                String[] stringArray = a;
                boolean bl = string.equals("Thunderstorm");
                if (!bl) break;
                n4 = 2;
                break;
            }
            case -1315838013: {
                String[] stringArray = a;
                n2 = string.equals("Dreamscape") ? 1 : 0;
                if (n2 == 0) break;
                n4 = 6;
                break;
            }
            case -1301352427: {
                String[] stringArray = a;
                n = string.equals("Synthwave") ? 1 : 0;
                if (n == 0) break;
                n4 = 4;
                break;
            }
            case 77382433: {
                String[] stringArray = a;
                boolean bl = string.equals("Prism");
                if (!bl) break;
                n4 = 7;
                break;
            }
            case 296012929: {
                String[] stringArray = a;
                boolean bl = string.equals("Black Hole");
                if (!bl) break;
                n4 = 1;
                break;
            }
            case 785408423: {
                boolean bl = string.equals("Blood Moon");
                if (!bl) break;
                n4 = 5;
                break;
            }
            case 2125565744: {
                boolean bl = string.equals("Galaxy");
                if (!bl) break;
                n4 = 0;
            }
        }
        n3 = n4;
        switch (n3) {
            case 0: {
                return new int[]{16763274, 9413375};
            }
            case 1: {
                return new int[]{16767392, 16738847};
            }
            case 2: {
                return new int[]{13227775, 5923712};
            }
            case 3: {
                return new int[]{16727450, 3065343};
            }
            case 4: {
                return new int[]{16722541, 383464};
            }
            case 5: {
                return new int[]{16726831, 0x5A0A0A};
            }
            case 6: {
                return new int[]{8300543, 16757703};
            }
            case 7: {
                n2 = AccentColors.getAccentRgb();
                int[] nArray = new int[]{n2, n = AccentColors.getAccent2Rgb()};
                return nArray;
            }
            default: {
                return new int[]{2883464, 9063935};
            }
        }
    }

    public static float[][] b() {
        String string = SkyShaders.s();
        String[] stringArray = a;
        boolean bl = "Prism".equals(string);
        if (bl && ((Boolean)SkyShaders.K("Natural Colors", Boolean.valueOf(true))).booleanValue()) {
            return SkyShaders.S();
        }
        int[] object3 = SkyShaders.I(string);
        int object5 = object3[0];
        int object6 = object3[1];
        Boolean bl2 = true;
        boolean bl3 = SkyShaders.K("Natural Colors", bl2);
        if (!bl3 && instance != null) {
            float[][] fArrayArray = instance.getSetting("Color", null);
            Object var10_11 = instance.getSetting("Second Color", null);
            object5 = AccentColors.resolveRgb(fArrayArray, object5, false);
            object6 = AccentColors.resolveRgb(var10_11, object6, true);
        }
        float[][] fArrayArray = new float[2][];
        fArrayArray[0] = SkyShaders.g(object5);
        fArrayArray[1] = SkyShaders.g(object6);
        return fArrayArray;
    }

    public static float[] C(String string, float[] fArray, float[] fArray2) {
        float[] fArray3;
        int n;
        int n2 = -1;
        int n3 = string.hashCode();
        switch (n3) {
            case -1965582497: {
                String[] stringArray = a;
                n = string.equals("Nebula") ? 1 : 0;
                if (n == 0) break;
                n2 = 3;
                break;
            }
            case -1710645595: {
                String[] stringArray = a;
                boolean bl = string.equals("Thunderstorm");
                if (!bl) break;
                n2 = 2;
                break;
            }
            case -1315838013: {
                String[] stringArray = a;
                boolean bl = string.equals("Dreamscape");
                if (!bl) break;
                n2 = 6;
                break;
            }
            case -1301352427: {
                String[] stringArray = a;
                boolean bl = string.equals("Synthwave");
                if (!bl) break;
                n2 = 4;
                break;
            }
            case 77382433: {
                String[] stringArray = a;
                boolean bl = string.equals("Prism");
                if (!bl) break;
                n2 = 7;
                break;
            }
            case 296012929: {
                String[] stringArray = a;
                boolean bl = string.equals("Black Hole");
                if (!bl) break;
                n2 = 1;
                break;
            }
            case 785408423: {
                boolean bl = string.equals("Blood Moon");
                if (!bl) break;
                n2 = 5;
                break;
            }
            case 2125565744: {
                boolean bl = string.equals("Galaxy");
                if (!bl) break;
                n2 = 0;
            }
        }
        n = n2;
        switch (n) {
            case 0: {
                fArray3 = SkyShaders.j(SkyShaders.g(790300), fArray2, 0.1f);
                return fArray3;
            }
            case 1: {
                fArray3 = SkyShaders.j(SkyShaders.g(657936), fArray2, 0.06f);
                return fArray3;
            }
            case 2: {
                fArray3 = SkyShaders.Z(fArray2, 0.45f);
                return fArray3;
            }
            case 3: {
                float[] fArray4 = SkyShaders.g(789014);
                float[] fArray5 = SkyShaders.j(fArray, fArray2, 0.5f);
                fArray3 = SkyShaders.j(fArray4, fArray5, 0.08f);
                return fArray3;
            }
            case 4: {
                fArray3 = SkyShaders.Z(fArray, 0.8f);
                return fArray3;
            }
            case 5: {
                fArray3 = SkyShaders.Z(fArray2, 0.8f);
                return fArray3;
            }
            case 6: {
                float[] fArray6 = SkyShaders.g(16769216);
                fArray3 = SkyShaders.j(fArray2, fArray6, 0.25f);
                return fArray3;
            }
            case 7: {
                float[] fArray7 = SkyShaders.g(460815);
                float[] fArray8 = SkyShaders.j(fArray, fArray2, 0.5f);
                fArray3 = SkyShaders.j(fArray7, fArray8, 0.14f);
                return fArray3;
            }
            default: {
                fArray3 = SkyShaders.j(SkyShaders.g(726562), fArray, 0.08f);
            }
        }
        return fArray3;
    }

    public static synchronized float[][] S() {
        float[] fArray;
        float f;
        long l;
        int n = AccentColors.getAccentRgb();
        float[] fArray2 = SkyShaders.g(n);
        int n2 = AccentColors.getAccent2Rgb();
        float[] fArray3 = SkyShaders.g(n2);
        long l2 = System.nanoTime();
        if (floatArray == null) {
            floatArray = (float[])fArray2.clone();
            floatArray2 = (float[])fArray3.clone();
        }
        if ((l = time) == 0L) {
            f = 0.0f;
        } else {
            long l3 = time;
            long l4 = l2 - l3;
            float f2 = l4;
            float f3 = f2 / 1.0E9f;
            f = Math.min(0.1f, f3);
        }
        float f4 = f;
        time = l2;
        float f5 = f4 * 3.2f;
        double d = f5;
        double d2 = Math.exp(-d);
        float f6 = (float)d2;
        float f7 = 1.0f - f6;
        floatArray = SkyShaders.j(floatArray, fArray2, f7);
        floatArray2 = SkyShaders.j(floatArray2, fArray3, f7);
        float[] fArray4 = (float[])floatArray.clone();
        float[][] fArrayArray = new float[][]{fArray4, fArray = (float[])floatArray2.clone()};
        return fArrayArray;
    }

    private static <T> T K(String string, T t) {
        boolean bl;
        boolean bl2;
        SkyShaders aurora = instance;
        if (aurora == null) {
            return t;
        }
        T t2 = aurora.getSetting(string, t);
        boolean bl3 = t instanceof Float;
        if (bl3 && (bl2 = t2 instanceof Number)) {
            float f = ((Number)t2).floatValue();
            return (T)Float.valueOf(f);
        }
        bl2 = t instanceof Boolean;
        if (!bl2 || (bl = t2 instanceof Boolean)) return t2;
        return t;
    }

    private static float p(float f, float f2, float f3) {
        boolean bl = Float.isNaN(f);
        if (bl) {
            return f2;
        }
        float f4 = Math.min(f3, f);
        return Math.max(f2, f4);
    }

    private static float[] g(int n) {
        float f;
        float f2;
        float f3;
        float[] fArray = new float[3];
        int n2 = n >> 16;
        int n3 = n2 & 0xFF;
        float f4 = n3;
        fArray[0] = f3 = f4 / 255.0f;
        int n4 = n >> 8;
        int n5 = n4 & 0xFF;
        float f5 = n5;
        fArray[1] = f2 = f5 / 255.0f;
        int n6 = n & 0xFF;
        float f6 = n6;
        fArray[2] = f = f6 / 255.0f;
        return fArray;
    }

    private static float[] j(float[] fArray, float[] fArray2, float f) {
        float f2;
        float f3;
        float f4;
        float[] fArray3 = new float[3];
        float f5 = fArray[0];
        float f6 = fArray2[0];
        float f7 = fArray[0];
        float f8 = f6 - f7;
        float f9 = f8 * f;
        fArray3[0] = f4 = f5 + f9;
        float f10 = fArray[1];
        float f11 = fArray2[1];
        float f12 = fArray[1];
        float f13 = f11 - f12;
        float f14 = f13 * f;
        fArray3[1] = f3 = f10 + f14;
        float f15 = fArray[2];
        float f16 = fArray2[2];
        float f17 = fArray[2];
        float f18 = f16 - f17;
        float f19 = f18 * f;
        fArray3[2] = f2 = f15 + f19;
        return fArray3;
    }

    private static float[] Z(float[] fArray, float f) {
        float f2;
        float f3;
        float f4;
        float[] fArray2 = new float[3];
        float f5 = fArray[0];
        fArray2[0] = f4 = f5 * f;
        float f6 = fArray[1];
        fArray2[1] = f3 = f6 * f;
        float f7 = fArray[2];
        fArray2[2] = f2 = f7 * f;
        return fArray2;
    }

    private void G() {
        this.choice("Preset", "Aurora", stringArray);
        this.number("Speed", 1.0, 0.0, 5.0, 0.1);
        this.number("Brightness", 1.0, 0.0, 3.0, 0.1);
        this.number("Intensity", 1.0, 0.0, 3.0, 0.1);
        this.number("Scale", 1.0, 0.25, 3.0, 0.05);
        this.number("Stars", 1.0, 0.0, 3.0, 0.1);
        this.number("Sky Rotation", 0.3, -5.0, 5.0, 0.1);
        this.number("Horizon Blend", 0.5, 0.0, 1.0, 0.05);
        this.bool("Match Fog", true);
        this.bool("Sun & Moon", false);
        this.bool("Hide Clouds", true);
        this.bool("In The End", true);
        this.bool("Natural Colors", true);
        this.define(new ColorSetting("Color", -13893752));
        this.define(new ColorSetting("Second Color", -7713025));
        this.choice("Resolution", "Full", "Full", "13#", "50%");
        SettingGroup.set(this.getSettings().stream().filter(SkyShaders::lmbd$defineSettings$0).findFirst().orElseThrow(), this::lmbd$defineSettings$1);
        SettingGroup.set(this.getSettings().stream().filter(SkyShaders::lmbd$defineSettings$2).findFirst().orElseThrow(), this::lmbd$defineSettings$3);
    }

    public static float e() {
        return (float)((double)(System.nanoTime() - animationStart) / 1.0E9);
    }

    @Override
    public void onDisable() {
        ShaderCompileFailed.release();
        floatArray2 = null;
        floatArray = null;
        time = 0L;
    }

    private boolean lmbd$defineSettings$3() {
        if (this.getSetting("Natural Colors", true) != false) return false;
        return true;
    }

    private static boolean lmbd$defineSettings$2(Setting setting) {
        return setting.getName().toString().equals("Second Color");
    }

    private boolean lmbd$defineSettings$1() {
        if (this.getSetting("Natural Colors", true) != false) return false;
        return true;
    }

    private static boolean lmbd$defineSettings$0(Setting setting) {
        return setting.getName().toString().equals("Color");
    }

    static {
        a = new String[]{"Preset", "Color", "Black Hole", "Full", "Match Fog", "Aurora", "Intensity", "Resolution", "Preset", "Sun & Moon", "Thunderstorm", "Color", "50%", "Synthwave", "Brightness", "Galaxy", "Galaxy", "Natural Colors", "Dreamscape", "Thunderstorm", "Nebula", "Horizon Blend", "75%", "Sun & Moon", "Synthwave", "Intensity", "Second Color", "50%", "Dreamscape", "Blood Moon", "Scale", "Speed", "Hide Clouds", "Brightness", "Resolution", "Stars", "Sky Rotation", "Animated procedural skies with selectable presets.", "Sky Rotation", "Prism", "Prism", "Sky Shaders", "Aurora", "Stars", "Full", "Scale", "Second Color", "Horizon Blend", "Hide Clouds", "Blood Moon", "Match Fog", "In The End", "In The End", "Speed", "Black Hole", "Natural Colors", "13#", "Hcdsjg"};
        time = 0L;
        String[] stringArray = new String[9];
        String[] stringArray2 = a;
        stringArray[0] = stringArray2[5];
        stringArray[1] = stringArray2[16];
        stringArray[2] = stringArray2[2];
        stringArray[3] = stringArray2[10];
        stringArray[4] = stringArray2[20];
        stringArray[5] = stringArray2[13];
        stringArray[6] = stringArray2[29];
        stringArray[7] = stringArray2[28];
        stringArray[8] = stringArray2[40];
        String[] stringArray3 = stringArray;
        SkyShaders.stringArray = stringArray3;
        animationStart = System.nanoTime();
    }
}
