package krispy.modules.render;

import krispy.modules.render.TargetHUD;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2824;
import net.minecraft.class_310;

public class This0 {
    private static String[] a;
    public static class_310 MC;
    final TargetHUD this$0;

    This0(TargetHUD targetHUD) {
        this.this$0 = targetHUD;
    }

    public boolean O(class_2824 class_28242) {
        String string;
        try {
            string = class_28242.toString();
            if (string.contains("ATTACK")) {
                return true;
            }
        }
        catch (Exception exception) {
            if (This0.MC.field_1724 == null) return false;
            if (This0.MC.field_1724.method_6052() == null) return false;
            if (!(This0.MC.field_1724.method_6052() instanceof class_1657)) return false;
            return true;
        }
        try {
            if (This0.MC.field_1724 == null) return false;
            if (This0.MC.field_1724.method_6052() == null) return false;
            if (!(This0.MC.field_1724.method_6052() instanceof class_1657)) {
                return false;
            }
            boolean bl = string.contains(class_1268.field_5808.toString());
            boolean bl2 = string.contains("INTERACT_AT");
            if (bl && bl2) {
                return true;
            }
        }
        catch (Exception exception) {
            if (This0.MC.field_1724 == null) return false;
            if (This0.MC.field_1724.method_6052() == null) return false;
            if (!(This0.MC.field_1724.method_6052() instanceof class_1657)) return false;
            return true;
        }
        try {
            if (!This0.MC.field_1724.field_6252) return false;
            if (This0.MC.field_1724.method_6052() == null) return false;
            return true;
        }
        catch (Exception exception) {
            if (This0.MC.field_1724 == null) return false;
            if (This0.MC.field_1724.method_6052() == null) return false;
            if (!(This0.MC.field_1724.method_6052() instanceof class_1657)) return false;
            return true;
        }
    }

    static {
        a = new String[]{"INTERACT_AT", "ATTACK"};
        MC = class_310.method_1551();
    }
}
