package krispy.modules.render;

public enum Outline {
    Box,
    Outline,
    Both;

}
