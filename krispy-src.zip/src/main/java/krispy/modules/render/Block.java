package krispy.modules.render;

import net.minecraft.class_2248;
import net.minecraft.class_2338;

class Block {
    public final class_2338 pos;
    public final class_2248 block;

    public Block(class_2338 pos, class_2248 block) {
        this.pos = pos;
        this.block = block;
    }

    public class_2338 pos() {
        return this.pos;
    }

    public class_2248 block() {
        return this.block;
    }
}
