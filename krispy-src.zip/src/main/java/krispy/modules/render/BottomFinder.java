package krispy.modules.render;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;
import krispy.modules.render.Bottom;

public final class BottomFinder {
    private BottomFinder() {
    }

    public static List<Bottom> V(BitSet bitSet, int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2) {
        ArrayList<Bottom> arrayList = new ArrayList<Bottom>();
        for (int i = 1; i <= 16; ++i) {
            for (int j = 1; j <= 16; ++j) {
                if (Thread.currentThread().isInterrupted()) {
                    return List.of();
                }
                if (bl) {
                    BottomFinder.g(bitSet, n, n2, n3, n4, i, j, 1, 1, n5, arrayList);
                }
                if (bl2) {
                    BottomFinder.g(bitSet, n, n2, n3, n4, i, j, 3, 1, n5, arrayList);
                    BottomFinder.g(bitSet, n, n2, n3, n4, i, j, 1, 3, n5, arrayList);
                }
                if (arrayList.size() < 1024) continue;
                return List.copyOf(arrayList);
            }
        }
        return List.copyOf(arrayList);
    }

    private static boolean m(BitSet bitSet, int n, int n2, int n3) {
        return bitSet.get((n2 * 20 + n) * 20 + n3);
    }

    private static boolean O(BitSet bitSet, int n, int n2, int n3, int n4, int n5) {
        int n6;
        for (n6 = 0; n6 < n4; ++n6) {
            for (int i = 0; i < n5; ++i) {
                if (!BottomFinder.m(bitSet, n + n6, n2, n3 + i)) continue;
                return false;
            }
        }
        for (n6 = 0; n6 < n4; ++n6) {
            if (BottomFinder.m(bitSet, n + n6, n2, n3 - 1) && BottomFinder.m(bitSet, n + n6, n2, n3 + n5)) continue;
            return false;
        }
        for (n6 = 0; n6 < n5; ++n6) {
            if (BottomFinder.m(bitSet, n - 1, n2, n3 + n6) && BottomFinder.m(bitSet, n + n4, n2, n3 + n6)) continue;
            return false;
        }
        return true;
    }

    private static void g(BitSet bitSet, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, List<Bottom> list) {
        int n10 = 0;
        int n11 = 0;
        for (int i = 0; i < n; ++i) {
            if (BottomFinder.O(bitSet, n5, i, n6, n7, n8)) {
                if (n10 == 0) {
                    n11 = i;
                }
                ++n10;
                continue;
            }
            if (n10 >= n9) {
                list.add(new Bottom(n3 + n5 - 1, n4 + n6 - 1, n2 + n11, n2 + i, n7, n8));
            }
            n10 = 0;
        }
        if (n10 < n9) return;
        list.add(new Bottom(n3 + n5 - 1, n4 + n6 - 1, n2 + n11, n2 + n, n7, n8));
    }
}
