package krispy.modules.render.j;

import krispy.modules.render.j.DecalSizeMust;
import krispy.modules.render.j.Eseos0Au;
import krispy.modules.render.j.FollowAmount;
import krispy.modules.render.j.GradientNeedsLeast;
import krispy.modules.render.j.Height2;
import krispy.modules.render.j.Noise;
import krispy.modules.render.j.MinX;
import krispy.modules.render.j.Paints;
import krispy.modules.render.j.Name;
import krispy.modules.render.j.OutlineColorSet;
import krispy.modules.render.j.Paint;
import krispy.modules.render.j.RightArm;
import krispy.modules.render.j.ScaleMustBetween;
import krispy.modules.render.j.Fill;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class TungTungSahur
extends Name {
    private static final float R = 5.0f;
    private static final float BOTTOM = 12.0f;
    private static final float TOP = 34.0f;
    private static final float RIM = 0.85f;
    private static final float FIST_X = -7.0f;
    private static final float FIST_Y = 11.6f;
    private static final float FIST_Z = 0.72f;
    private static float[] KNUCKLE_DIR;
    private static final int WOOD = -1063542;
    private static final int WOOD_DARK = -4158378;
    private static final int WOOD_WORN = -5868993;
    private static final int FISSURE = -9551070;
    private static final int KNOT = -11653867;
    private static final int CUT = -1389672;
    private static final int LIMB = -3567528;
    private static final int LIMB_DARK = -7053254;
    private static final int INK = -15003638;
    private static final int LINE = -12967406;

    public TungTungSahur() {
        super("tung_tung_sahur", "Tung Tung Tung Sahur");
    }

    @Override
    protected void D(ScaleMustBetween scaleMustBetween) {
        scaleMustBetween.v(1.0f).H(-12967406, 0.16f).A(0.3f).q(false);
        scaleMustBetween.T(RightArm.HEAD).X(0.0f, 12.5f, 0.0f);
        OutlineColorSet outlineColorSet = scaleMustBetween.d("upright", RightArm.HEAD).K(FollowAmount.S().V(1.0f).H(100.0f));
        scaleMustBetween.D("log", outlineColorSet).v(TungTungSahur.a()).Z(1.5f).E(1.2f).i(0.35f).h(0.0f, 22.5f, 0.0f, 0.0f, 1.0f, 0.0f, 4.0f).R(0.6f, 0.0f, 40.0f).K(FollowAmount.S().F(0.0f, 4.0f, -6.0f, 1.0f).m(6.0f)).D(TungTungSahur.b()).D(TungTungSahur.T()).D(TungTungSahur.r());
        OutlineColorSet outlineColorSet2 = scaleMustBetween.T(RightArm.RIGHT_ARM).X(-5.3f, 22.8f, 0.2f).Y(-7.0f, 11.6f, 0.72f).v(TungTungSahur.O()).g(-6.57f, 17.1f, 0.14f, 0.6f);
        scaleMustBetween.T(RightArm.LEFT_ARM).F(outlineColorSet2);
        OutlineColorSet outlineColorSet3 = scaleMustBetween.d("hand_r", RightArm.RIGHT_ARM).v(TungTungSahur.g()).E(0.6f).Z(0.8f);
        scaleMustBetween.d("hand_l", RightArm.LEFT_ARM).F(outlineColorSet3);
        OutlineColorSet outlineColorSet4 = scaleMustBetween.T(RightArm.RIGHT_LEG).X(-2.2f, 12.8f, 0.0f).v(TungTungSahur.R()).q(0.6f, 35.0f).g(-2.3f, 6.75f, 0.16f, 0.7f);
        scaleMustBetween.T(RightArm.LEFT_LEG).F(outlineColorSet4);
        OutlineColorSet outlineColorSet5 = scaleMustBetween.d("foot_r", RightArm.RIGHT_LEG).v(TungTungSahur.m()).E(0.7f).Z(0.8f);
        scaleMustBetween.d("foot_l", RightArm.LEFT_LEG).F(outlineColorSet5);
    }

    private static Paint a() {
        Paint paint = Paints.A(TungTungSahur::I, -5.5f, 11.8f, -5.5f, 5.5f, 34.2f, 5.5f);
        Eseos0Au eseos0Au = new Eseos0Au(Fill.W(-1063542, -4158378, 0.3f, 0.0f, -0.2f, 0.0f, 1.0f, 0.0f, 0.8f).k(-5868993, 3.5f, 0.08f).h(0.35f, 0.04f));
        Paint paint2 = Paints.O(0.35f, paint.l(eseos0Au), TungTungSahur.s(38.0f, 17.2f, 0.8f), TungTungSahur.s(165.0f, 27.5f, 0.95f), TungTungSahur.s(-120.0f, 19.5f, 0.7f), TungTungSahur.s(-58.0f, 14.2f, 0.55f), TungTungSahur.V(128.0f, 25.2f), TungTungSahur.h(1.0f, eseos0Au), TungTungSahur.h(-1.0f, eseos0Au));
        Paint paint3 = Paints.P(0.0f, 25.35f, TungTungSahur.u(0.0f, 25.35f, 1.0f) + 0.12f, 2.7f, 1.05f, 0.55f);
        return Paints.N(0.12f, Paints.N(0.35f, paint2, paint3), Paints.j(TungTungSahur.S(165.0f, 27.5f, 0.32f), TungTungSahur.S(-120.0f, 19.5f, 0.24f)));
    }

    private static Paint V(float f, float f2) {
        float f3 = (float)Math.sin(Math.toRadians(f));
        float f4 = (float)Math.cos(Math.toRadians(f));
        float f5 = (float)Math.cos(Math.toRadians(32.0));
        float f6 = (float)Math.sin(Math.toRadians(32.0));
        float f7 = f3 * f5;
        float f8 = f6;
        float f9 = f4 * f5;
        float f10 = f3 * 3.9f;
        float f11 = f4 * 3.9f;
        float f12 = f10 + f7 * 3.05f;
        float f13 = f2 + f8 * 3.05f;
        float f14 = f11 + f9 * 3.05f;
        Paint paint = Paints.Q(f10, f2, f11, 0.98f, f12 + f7 * 0.4f, f13 + f8 * 0.4f, f14 + f9 * 0.4f, 0.64f).l(Fill.W(-1063542, -4158378, f10, f2, f11, f7, f8, f9, 0.3f));
        Fill sx2 = Fill.X(-6264264, f12, f13, f14, 0.75f, -1389672);
        return Paints.V(paint, Paints.E(f12, f13, f14, -f7, -f8, -f9).l(sx2));
    }

    private static Paint h(float f, Fill sx2) {
        float f2 = f * 2.14f;
        float f3 = 28.72f;
        float f4 = f2 / 5.0f;
        float f5 = (float)Math.sqrt(1.0f - f4 * f4);
        float f6 = TungTungSahur.u(f4, f3, f5) - 0.5f;
        float f7 = (float)Math.toDegrees(Math.asin(f4));
        return Paints.P(f4 * f6, f3, f5 * f6, 1.85f, 1.8f, 0.85f).L(0.0f, f7, 0.0f, f4 * f6, f3, f5 * f6).l(sx2);
    }

    private static Paint s(float f, float f2, float f3) {
        float f4 = (float)Math.sin(Math.toRadians(f));
        float f5 = (float)Math.cos(Math.toRadians(f));
        float f6 = TungTungSahur.u(f4, f2, f5) + 0.28f;
        float f7 = f6 - f3;
        return Paints.P(f4 * f7, f2, f5 * f7, f3, f3 * 1.35f, f3).l(Fill.X(-11653867, f4 * f6, f2, f5 * f6, f3 * 1.05f, -4158378));
    }

    private static Paint S(float f, float f2, float f3) {
        float f4 = (float)Math.sin(Math.toRadians(f));
        float f5 = (float)Math.cos(Math.toRadians(f));
        float f6 = TungTungSahur.u(f4, f2, f5) + 0.28f;
        return Paints.P(f4 * f6, f2, f5 * f6, f3, f3 * 1.3f, f3).n(-11653867);
    }

    private static float u(float f, float f2, float f3) {
        float f4 = 0.17f * Noise.m(f * 1.1f + 2.3f, f2 * 0.1f, f3 * 1.1f - 1.3f);
        return 5.0f + f4 - 0.17f * TungTungSahur.N(f, f2, f3);
    }

    public static float N(float f, float f2, float f3) {
        float f4 = Math.abs(Noise.m(f * 3.0f - 5.1f, f2 * 0.08f, f3 * 3.0f + 0.7f));
        float f5 = TungTungSahur.v(0.3f, 0.62f, f3) * TungTungSahur.v(21.8f, 23.6f, f2);
        return Math.max(0.0f, 1.0f - f4 / 0.28f) * (1.0f - 0.88f * f5);
    }

    private static float I(float f, float f2, float f3) {
        float f4 = (float)Math.sqrt(f * f + f3 * f3);
        float f5 = f4 > 1.0E-4f ? f / f4 : 0.0f;
        float f6 = f4 > 1.0E-4f ? f3 / f4 : 1.0f;
        float f7 = f4 - TungTungSahur.u(f5, f2, f6) + 0.85f;
        float f8 = Math.abs(f2 - 23.0f) - 11.0f + 0.85f;
        float f9 = Math.max(f7, 0.0f);
        float f10 = Math.max(f8, 0.0f);
        return (float)Math.sqrt(f9 * f9 + f10 * f10) + Math.min(Math.max(f7, f8), 0.0f) - 0.85f;
    }

    private static Paint O() {
        Fill sx2 = TungTungSahur.L(-5.4f, 22.6f, 0.2f, -7.0f, 11.6f, 0.72f);
        Paint paint = Paints.O(0.2f, Paints.e(-5.3f, 22.8f, 0.2f, 0.7f), Paints.b(-5.3f, 22.8f, 0.2f, -3.9f, 22.8f, 0.2f, 0.55f));
        Paint paint2 = Paints.Q(-5.4f, 22.5f, 0.2f, 0.64f, -6.55f, 17.3f, 0.12f, 0.54f);
        Paint paint3 = Paints.e(-6.57f, 17.1f, 0.14f, 0.6f);
        Paint paint4 = Paints.Q(-6.6f, 16.85f, 0.14f, 0.55f, -6.93f, 12.6f, 0.5f, 0.5f);
        return Paints.O(0.3f, paint, paint2, paint3, paint4).l(sx2);
    }

    private static Paint g() {
        float f = KNUCKLE_DIR[0];
        float f2 = KNUCKLE_DIR[1];
        float f3 = KNUCKLE_DIR[2];
        Paint paint = Paints.P(-6.92f, 11.650001f, 0.70000005f, 0.86f, 1.05f, 0.9f);
        Paint paint2 = Paints.Q(-6.93f, 12.75f, 0.5f, 0.5f, -6.95f, 12.150001f, 0.72f, 0.64f);
        Paint[] paintArray = new Paint[4];
        for (int i = 0; i < 4; ++i) {
            float f4 = -0.66f + (float)i * 0.44f;
            float f5 = -7.0f + f * f4 - 0.28f;
            float f6 = 11.6f + f2 * f4;
            float f7 = 0.72f + f3 * f4 + 0.72f;
            paintArray[i] = Paints.b(f5 - 0.35f, f6, f7 - 0.3f, f5 + 0.3f, f6, f7 + 0.1f, 0.26f + 0.02f * (float)(3 - i));
        }
        Paint paint3 = Paints.b(-6.38f, 12.1f, 0.92f, -6.82f, 12.320001f, 1.6700001f, 0.27f);
        return Paints.O(0.18f, Paints.O(0.3f, paint, paint2), Paints.j(paintArray), paint3).l(TungTungSahur.L(-6.9f, 12.8f, 0.5f, -7.0f, 10.6f, 0.72f));
    }

    private static Paint R() {
        Fill sx2 = TungTungSahur.L(-2.2f, 12.8f, 0.0f, -2.35f, 1.4f, 0.0f);
        Paint paint = Paints.e(-2.2f, 12.6f, 0.0f, 0.8f);
        Paint paint2 = Paints.Q(-2.2f, 12.4f, 0.0f, 0.74f, -2.3f, 7.0f, 0.12f, 0.62f);
        Paint paint3 = Paints.e(-2.3f, 6.75f, 0.16f, 0.68f);
        Paint paint4 = Paints.Q(-2.3f, 6.5f, 0.12f, 0.62f, -2.36f, 1.9f, 0.0f, 0.55f);
        return Paints.O(0.3f, paint, paint2, paint3, paint4).l(sx2);
    }

    private static Paint m() {
        Paint paint = Paints.O(0.5f, Paints.P(-2.42f, 0.55f, 1.0f, 1.2f, 0.55f, 1.9f), Paints.P(-2.36f, 0.95f, -0.1f, 0.8f, 0.85f, 1.0f), Paints.e(-2.36f, 1.75f, 0.0f, 0.55f));
        Paint paint2 = Paints.j(Paints.e(-1.7f, 0.38f, 2.55f, 0.4f), Paints.e(-2.2f, 0.35f, 2.8f, 0.36f), Paints.e(-2.68f, 0.34f, 2.76f, 0.33f), Paints.e(-3.12f, 0.33f, 2.52f, 0.31f));
        return Paints.T(Paints.O(0.22f, paint, paint2), Paints.I(0.0f)).l(TungTungSahur.L(-2.4f, 0.6f, -1.0f, -2.4f, 0.6f, 3.0f));
    }

    private static Fill L(float f, float f2, float f3, float f4, float f5, float f6) {
        return Fill.W(-3567528, -7053254, f, f2, f3, f4 - f, f5 - f2, f6 - f3, 0.35f).h(0.3f, 0.05f);
    }

    private static DecalSizeMust b() {
        Height2 height2 = new Height2(336, 208);
        for (int i = -1; i <= 1; i += 2) {
            float f = 168.0f + (float)i * 85.5f;
            float f2 = 122.0f;
            height2.a(MinX.R(f, f2, 75.0f), 808458248, 13.0f);
            height2.H(MinX.R(f, f2, 66.0f), -15003638);
            height2.h(MinX.R(f, f2, 60.75f), GradientNeedsLeast.radial(f - 15.0f, f2 - 18.0f, 78.0f, -1, -132105, -1054240));
            float f3 = f - (float)i * 1.5f;
            float f4 = f2 + 1.0f;
            height2.H(MinX.R(f3, f4, 12.0f), -15857658);
            height2.H(MinX.R(f3 - 3.9f, f4 - 4.4f, 3.6f), -285212673);
        }
        MinX minX = MinX.h(15.0f, 48.0f, 74.0f, 18.0f, 147.0f, 71.0f, 21.0f, 34.5f);
        height2.H(minX, -15003638);
        height2.H(minX.I(168.0f).s(6.0f, 321.0f, 48.0f).Y(0.0f, -7.0f), -15003638);
        return DecalSizeMust.Z(height2, 0.0f, 29.175f, 5.0f, 8.4f, 5.2f).O(3.6f, 1.5f).u(72.0f).V(1.0f).B(0.0f);
    }

    private static DecalSizeMust T() {
        Height2 height2 = new Height2(272, 104);
        MinX minX = MinX.f(136.0f, 19.0f, 124.5f, 78.0f).o(MinX.R(136.0f, -482.0f, 507.0f));
        height2.H(minX.O(6.0f), -15003638);
        height2.h(minX, GradientNeedsLeast.linear(136.0f, 10.0f, 136.0f, 95.5f, -15071227, -12970996));
        height2.H(MinX.f(136.0f, 98.5f, 75.0f, 39.0f).m(minX), -3646898);
        return DecalSizeMust.Z(height2, 0.0f, 24.675f, 5.0f, 6.8f, 2.6f).O(3.6f, 1.5f).u(72.0f);
    }

    private static DecalSizeMust r() {
        Height2 height2 = new Height2(168, 168);
        height2.Q(MinX.R(84.0f, 84.0f, 72.0f), GradientNeedsLeast.radial(81.0f, 86.0f, 72.0f, -3565470, -1917818, -1521774, -2709138), 4.0f);
        MinX minX = MinX.P(TungTungSahur::lmbd$rings$0, 12.0f, 17.0f, 150.0f, 155.0f);
        height2.H(minX, -1602927328);
        height2.H(MinX.R(81.0f, 86.0f, 3.6f), -9813984);
        height2.H(MinX.D(87.0f, 81.0f, 3.0f, 133.0f, 52.0f, 1.0f), -1069538288);
        height2.H(MinX.D(77.0f, 91.0f, 2.2f, 47.0f, 126.0f, 1.0f), -1337973744);
        return DecalSizeMust.Y(height2, 0.0f, 34.0f, 0.0f, 9.678f, 9.678f).O(0.6f, 0.6f).u(35.0f);
    }

    public static float v(float f, float f2, float f3) {
        float f4 = Math.max(0.0f, Math.min(1.0f, (f3 - f) / (f2 - f)));
        return f4 * f4 * (3.0f - 2.0f * f4);
    }

    private static float[] i(float f, float f2, float f3) {
        float f4 = (float)Math.sqrt(f * f + f2 * f2 + f3 * f3);
        return new float[]{f / f4, f2 / f4, f3 / f4};
    }

    private static float lmbd$rings$0(float f, float f2) {
        float f3 = f - 81.0f;
        float f4 = f2 - 86.0f;
        float f5 = (float)Math.sqrt(f3 * f3 + f4 * f4) + 0.001f;
        float f6 = f5 + 2.5f * Noise.m(f3 / f5 * 1.3f, f4 / f5 * 1.3f, f5 * 0.028f);
        float f7 = f6 / 8.25f;
        float f8 = f7 - (float)Math.round(f7);
        return Math.max(Math.max(Math.abs(f8) * 8.25f - 0.82f, f5 - 67.5f), 6.7f - f5);
    }

    private static String[] b;

    static {
        b = new String[]{"tung_tung_sahur", "foot_l", "hand_l", "log", "upright", "foot_r", "hand_r", "Tung Tung Tung Sahur"};
        KNUCKLE_DIR = TungTungSahur.i(-0.16f, 0.86f, 0.48f);
    }
}
