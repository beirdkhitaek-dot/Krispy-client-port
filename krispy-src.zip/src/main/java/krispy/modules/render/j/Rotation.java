package krispy.modules.render.j;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import krispy.modules.render.j.Nodes;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Rotation {
    private static String[] a;
    private Rotation() {
    }

    static float[] K() {
        float[] fArray = new float[16];
        fArray[15] = 1.0f;
        fArray[10] = 1.0f;
        fArray[5] = 1.0f;
        fArray[0] = 1.0f;
        return fArray;
    }

    static float[] b(float[] fArray, float[] fArray2) {
        float[] fArray3 = new float[16];
        for (int i = 0; i < 4; ++i) {
            for (int j = 0; j < 4; ++j) {
                float f = 0.0f;
                for (int k = 0; k < 4; ++k) {
                    f += fArray[k * 4 + j] * fArray2[i * 4 + k];
                }
                fArray3[i * 4 + j] = f;
            }
        }
        return fArray3;
    }

    static float[] M(JsonObject jsonObject) {
        JsonArray jsonArray = Nodes.A(jsonObject, "matrix");
        if (jsonArray.size() != 16) {
            float[] fArray;
            float[] fArray2 = Rotation.X(jsonObject, "translation", 0.0f, 3);
            float[] fArray3 = Rotation.X(jsonObject, "scale", 1.0f, 3);
            if (jsonObject.has("rotation")) {
                fArray = Rotation.X(jsonObject, "rotation", 0.0f, 4);
            } else {
                float[] fArray4 = new float[4];
                fArray4[0] = 0.0f;
                fArray4[1] = 0.0f;
                fArray4[2] = 0.0f;
                fArray = fArray4;
                fArray4[3] = 1.0f;
            }
            float[] fArray5 = fArray;
            float f = fArray5[0];
            float f2 = fArray5[1];
            float f3 = fArray5[2];
            float f4 = fArray5[3];
            return new float[]{(1.0f - 2.0f * (f2 * f2 + f3 * f3)) * fArray3[0], 2.0f * (f * f2 + f3 * f4) * fArray3[0], 2.0f * (f * f3 - f2 * f4) * fArray3[0], 0.0f, 2.0f * (f * f2 - f3 * f4) * fArray3[1], (1.0f - 2.0f * (f * f + f3 * f3)) * fArray3[1], 2.0f * (f2 * f3 + f * f4) * fArray3[1], 0.0f, 2.0f * (f * f3 + f2 * f4) * fArray3[2], 2.0f * (f2 * f3 - f * f4) * fArray3[2], (1.0f - 2.0f * (f * f + f2 * f2)) * fArray3[2], 0.0f, fArray2[0], fArray2[1], fArray2[2], 1.0f};
        }
        float[] fArray = new float[16];
        for (int i = 0; i < 16; ++i) {
            fArray[i] = jsonArray.get(i).getAsFloat();
        }
        return fArray;
    }

    private static float[] X(JsonObject jsonObject, String string, float f, int n) {
        float[] fArray = new float[n];
        JsonArray jsonArray = Nodes.A(jsonObject, string);
        for (int i = 0; i < n; ++i) {
            fArray[i] = i < jsonArray.size() ? jsonArray.get(i).getAsFloat() : f;
        }
        return fArray;
    }

    static float[] s(float f, float[] fArray) {
        double d = Math.toRadians(f);
        float f2 = (float)Math.cos(d);
        float f3 = (float)Math.sin(d);
        float[] fArray2 = Rotation.K();
        fArray2[0] = f2;
        fArray2[1] = f3;
        fArray2[4] = -f3;
        fArray2[5] = f2;
        fArray2[12] = fArray[0] - f2 * fArray[0] + f3 * fArray[1];
        fArray2[13] = fArray[1] - f3 * fArray[0] - f2 * fArray[1];
        fArray2[14] = 0.0f;
        return fArray2;
    }

    static float[] r(float[] fArray, float f, float f2, float f3) {
        return new float[]{fArray[0] * f + fArray[4] * f2 + fArray[8] * f3 + fArray[12], fArray[1] * f + fArray[5] * f2 + fArray[9] * f3 + fArray[13], fArray[2] * f + fArray[6] * f2 + fArray[10] * f3 + fArray[14]};
    }

    static float[] S(float[] fArray, float f, float f2, float f3) {
        return new float[]{fArray[0] * f + fArray[4] * f2 + fArray[8] * f3, fArray[1] * f + fArray[5] * f2 + fArray[9] * f3, fArray[2] * f + fArray[6] * f2 + fArray[10] * f3};
    }

    static void B(float[] fArray) {
        float f = (float)Math.sqrt(fArray[0] * fArray[0] + fArray[1] * fArray[1] + fArray[2] * fArray[2]);
        if (f < 1.0E-12f) {
            fArray[1] = 1.0f;
            return;
        } else {
            fArray[0] = fArray[0] / f;
            fArray[1] = fArray[1] / f;
            fArray[2] = fArray[2] / f;
        }
    }

    static float[] k(float[] fArray, int n, int n2, int n3) {
        float f = fArray[n2 * 3] - fArray[n * 3];
        float f2 = fArray[n2 * 3 + 1] - fArray[n * 3 + 1];
        float f3 = fArray[n2 * 3 + 2] - fArray[n * 3 + 2];
        float f4 = fArray[n3 * 3] - fArray[n * 3];
        float f5 = fArray[n3 * 3 + 1] - fArray[n * 3 + 1];
        float f6 = fArray[n3 * 3 + 2] - fArray[n * 3 + 2];
        return new float[]{f2 * f6 - f3 * f5, f3 * f4 - f * f6, f * f5 - f2 * f4};
    }

    static float a(float[] fArray, int n, int n2, int n3) {
        float[] fArray2 = Rotation.k(fArray, n, n2, n3);
        return (float)Math.sqrt(fArray2[0] * fArray2[0] + fArray2[1] * fArray2[1] + fArray2[2] * fArray2[2]) * 0.5f;
    }

    static {
        a = new String[]{"rotation", "scale", "matrix", "translation", "rotation"};
    }
}
