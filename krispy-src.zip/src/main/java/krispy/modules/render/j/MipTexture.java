package krispy.modules.render.j;

import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.TextureFormat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1011;
import net.minecraft.class_1044;

@Environment(value=EnvType.CLIENT)
final class MipTexture
extends class_1044 {
    MipTexture(String string, int n, int n2, int[][] nArray) {
        GpuDevice gpuDevice = RenderSystem.getDevice();
        this.field_56974 = gpuDevice.createTexture(() -> MipTexture.lmbd$new$0(string), 5, TextureFormat.RGBA8, n, n2, 1, nArray.length);
        this.field_60597 = gpuDevice.createTextureView(this.field_56974);
        CommandEncoder commandEncoder = gpuDevice.createCommandEncoder();
        int n3 = n;
        int n4 = n2;
        for (int i = 0; i < nArray.length; ++i) {
            int[] nArray2 = nArray[i];
            try (class_1011 class_10112 = new class_1011(n3, n4, false);){
                for (int j = 0; j < n4; ++j) {
                    for (int k = 0; k < n3; ++k) {
                        class_10112.method_61941(k, j, nArray2[j * n3 + k]);
                    }
                }
                commandEncoder.writeToTexture(this.field_56974, class_10112, i, 0, 0, 0, n3, n4, 0, 0);
            }
            n3 = Math.max(1, n3 / 2);
            n4 = Math.max(1, n4 / 2);
        }
        this.field_63613 = RenderSystem.getSamplerCache().method_76520(FilterMode.LINEAR, true);
    }

    private static String lmbd$new$0(String string) {
        return string;
    }
}
