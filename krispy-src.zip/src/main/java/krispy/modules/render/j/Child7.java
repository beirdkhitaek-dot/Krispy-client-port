package krispy.modules.render.j;

import java.util.function.UnaryOperator;
import krispy.modules.render.j.Noise;
import krispy.modules.render.j.OcclusionWeight;
import krispy.modules.render.j.Paint;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Child7
extends Paint {
    private final Paint child;
    private final float amp;
    private final float freq;

    Child7(Paint paint, float f, float f2) {
        this.child = paint;
        this.amp = f;
        this.freq = 1.0f / Math.max(0.01f, f2);
        this.i(paint, Math.abs(f));
    }

    @Override
    Paint N(float f, float f2, float f3, float f4, float f5, float f6) {
        Paint paint = this.child.N(f, f2, f3, f4, f5, f6);
        return paint == this.child ? this : new Child7(paint, this.amp, 1.0f / this.freq);
    }

    @Override
    Paint h(UnaryOperator<Paint> unaryOperator) {
        Paint paint = this.child.h(unaryOperator);
        return (Paint)unaryOperator.apply(paint == this.child ? this : new Child7(paint, this.amp, 1.0f / this.freq).t(this));
    }

    @Override
    public float Q(float f, float f2, float f3) {
        float f4 = this.child.Q(f, f2, f3);
        return f4 > this.amp * 1.5f + 0.5f ? f4 : f4 + this.amp * Noise.m(f * this.freq, f2 * this.freq, f3 * this.freq);
    }

    @Override
    float R(float f, float f2, float f3, OcclusionWeight occlusionWeight) {
        return this.child.I(f, f2, f3, occlusionWeight) + this.amp * Noise.m(f * this.freq, f2 * this.freq, f3 * this.freq);
    }
}
