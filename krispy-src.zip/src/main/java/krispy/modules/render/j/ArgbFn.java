package krispy.modules.render.j;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public interface ArgbFn {
    public int argb(float var1, float var2, float var3);
}
