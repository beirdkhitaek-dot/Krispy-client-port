package krispy.modules.render.j;

import krispy.modules.render.j.MinX;
import krispy.modules.render.j.DistanceFn;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Field
extends MinX {
    private final DistanceFn field;

    Field(DistanceFn c92, float f, float f2, float f3, float f4) {
        this.field = c92;
        this.L(f, f2, f3, f4);
    }

    @Override
    public float d(float f, float f2) {
        return this.field.distance(f, f2);
    }
}
