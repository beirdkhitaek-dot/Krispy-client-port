package krispy.modules.render.j;

import krispy.modules.render.j.MinX;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Size
extends MinX {
    private final float cx;
    private final float cy;
    private final float size;

    Size(float f, float f2, float f3) {
        this.cx = f;
        this.cy = f2;
        this.size = f3;
        this.L(f - f3 * 0.7f, f2 - f3 * 0.35f, f + f3 * 0.7f, f2 + f3 * 0.8f);
    }

    @Override
    public float d(float f, float f2) {
        float f3;
        float f4 = Math.abs(f - this.cx) / this.size;
        if (f4 + (f3 = (this.cy + this.size * 0.75f - f2) / this.size) > 1.0f) {
            float f5 = f4 - 0.25f;
            float f6 = f3 - 0.75f;
            return ((float)Math.sqrt(f5 * f5 + f6 * f6) - 0.35355338f) * this.size;
        }
        float f7 = f4;
        float f8 = f3 - 1.0f;
        float f9 = Math.max(f4 + f3, 0.0f) * 0.5f;
        float f10 = f4 - f9;
        float f11 = f3 - f9;
        return (float)Math.sqrt(Math.min(f7 * f7 + f8 * f8, f10 * f10 + f11 * f11)) * Math.signum(f4 - f3) * this.size;
    }
}
