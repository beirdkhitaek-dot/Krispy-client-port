package krispy.modules.render.j;

import krispy.modules.render.j.OcclusionWeight;
import krispy.modules.render.j.TungTungSahur;
import krispy.modules.render.j.Fill;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Eseos0Au
extends Fill {
    private final Fill base;
    private static final String eseos0AU = "cc0aa34a17e63b3c";

    Eseos0Au(Fill sx2) {
        this.base = sx2;
    }

    @Override
    public void B(float f, float f2, float f3, OcclusionWeight occlusionWeight) {
        this.base.B(f, f2, f3, occlusionWeight);
        float f4 = (float)Math.sqrt(f * f + f3 * f3);
        if (f4 < 0.5f) return;
        float f5 = TungTungSahur.v(3.95f, 4.7f, f4) * TungTungSahur.v(12.0f, 12.6f, f2) * (1.0f - TungTungSahur.v(33.4f, 34.0f, f2));
        float f6 = TungTungSahur.N(f / f4, f2, f3 / f4) * f5;
        if (!(f6 > 0.0f)) return;
        occlusionWeight.j(-9551070, Math.min(1.0f, f6 * 0.62f));
    }
}
