package krispy.modules.render.j;

import java.util.ArrayList;
import java.util.List;
import krispy.modules.render.j.Canvas;
import krispy.modules.render.j.DecalSizeMust;
import krispy.modules.render.j.FlatMode;
import krispy.modules.render.j.Folds;
import krispy.modules.render.j.FollowAmount;
import krispy.modules.render.j.GradientNeedsLeast;
import krispy.modules.render.j.Height2;
import krispy.modules.render.j.MinX;
import krispy.modules.render.j.Paints;
import krispy.modules.render.j.Name;
import krispy.modules.render.j.Outline;
import krispy.modules.render.j.OutlineColorSet;
import krispy.modules.render.j.Paint;
import krispy.modules.render.j.RightArm;
import krispy.modules.render.j.ScaleMustBetween;
import krispy.modules.render.j.Colors;
import krispy.modules.render.j.Vec3;
import krispy.modules.render.j.Fill;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class Luna
extends Name {
    private static final int SKIN = -6958;
    private static final int SKIN_SHADE = -1331558;
    private static final int SKIN_LINE = -5737368;
    private static final int HAIR = -1912065;
    private static final int HAIR_MID = -4940554;
    private static final int HAIR_TIP = -7706904;
    private static final int HAIR_ROOT = -6519080;
    private static final int HAIR_LIGHT = -1647873;
    private static final int HAIR_LINE = -10794346;
    private static final int NAVY = -14603682;
    private static final int NAVY_DARK = -15460295;
    private static final int NAVY_LINE = -15921370;
    private static final int BODICE = -13945223;
    private static final int TIER = -12693598;
    private static final int LINING = -7571752;
    private static final int RIBBON = -4544530;
    private static final int PETTICOAT = -4611086;
    private static final int LACE = -1036;
    private static final int GOLD = -1326758;
    private static final int GOLD_DARK = -5011921;
    private static final int GOLD_PALE = -2868;
    private static final int GOLD_LINE = -8760296;
    private static final int TIGHTS = -12959880;
    private static final int TIGHTS_SHEEN = -10656082;
    private static final int BOOT = -7710146;
    private static final int BOOT_DARK = -9550799;
    private static final int BOOT_CUFF = -6395064;
    private static final int LEATHER = -8762574;
    private static final int LEATHER_DARK = -11653344;
    private static final int MOON = -4688;
    private static final float HEAD_K = 1.05f;
    private static final float NECK_Y = 24.7f;
    private static final float NECK_Z = -0.1f;
    private static final float AXIS_Z = -0.3f;
    private static final float HAT_TILT_X = -8.0f;
    private static final float HAT_TILT_Z = 4.0f;
    private static Vec3 HAT_CENTRE;
    private static MinX BRIM;
    private static final float BRIM_WAVE = 0.3f;
    private static final float RIM_R = 5.86f;
    private static Vec3 ELBOW;
    private static final float ELBOW_PITCH = -12.0f;
    private static final float ELBOW_ROLL = 3.0f;
    private static final float FACE_PPU = 41.48148f;
    private static final float FACE_LEFT = -2.3142858f;
    private static final float FACE_TOP = 28.810715f;
    private static float[] CAPE_Y;
    private static float[] CAPE_RX;
    private static float[] CAPE_RZ;
    private static float[] CAPE_CZ;
    private static float[] CAPE_WRAP;
    private static final int CAPE_STEPS = 96;
    private static float[] CAPE_LUT;
    private static float[] CURTAIN_Y;
    private static float[] CURTAIN_RX;
    private static float[] CURTAIN_RZ;
    private static float[] CURTAIN_CZ;
    private static String[] b;

    public Luna() {
        super("luna", "Luna");
    }

    @Override
    protected void D(ScaleMustBetween scaleMustBetween) {
        scaleMustBetween.v(1.0f).H(-15396047, 0.15f).A(0.35f);
        Height2 height2 = new Height2(128, 12);
        Luna.V(height2);
        Paint paint = Luna.T();
        Paint paint2 = Paints.P(0.0f, 27.55f, -0.35f, 2.82f, 2.94f, 2.88f).T(Paints.E(0.0f, 24.6f, -2.7f, 0.0f, -1.0f, 0.86f));
        List<Outline> list = Luna.n(paint);
        Luna.J(scaleMustBetween, paint, list);
        Luna.A(scaleMustBetween, paint2, list);
        Luna.K(scaleMustBetween);
        Luna.k(scaleMustBetween);
        Luna.o(scaleMustBetween);
        Luna.X(scaleMustBetween, height2);
        Luna.X5(scaleMustBetween, height2);
        Luna.Q(scaleMustBetween);
    }

    private static Paint T() {
        Paint paint = Paints.P(0.0f, 27.5f, -0.3f, 2.38f, 2.5f, 2.42f);
        Paint paint2 = Paints.P(0.0f, 26.3f, 0.3f, 1.84f, 1.32f, 1.84f);
        Paint paint3 = Paints.Q(0.0f, 25.75f, 0.4f, 1.28f, 0.0f, 24.74f, 1.02f, 0.34f);
        return Paints.O(1.0f, paint, paint2, paint3);
    }

    private static void J(ScaleMustBetween scaleMustBetween, Paint paint, List<Outline> list) {
        scaleMustBetween.T(RightArm.HEAD).X(0.0f, 24.7f, -0.1f).v(Luna.F(paint.l(Fill.Z(-6958)))).E(0.9f).Z(1.5f).i(1.0f).G(0.2f).W(-5737368, 0.08f).D(Luna.H(list));
    }

    private static Paint F(Paint paint) {
        return paint.X(1.05f, 0.0f, 24.7f, -0.1f);
    }

    private static Vec3 v(float f, float f2, float f3) {
        return new Vec3(f * 1.05f, 24.7f + (f2 - 24.7f) * 1.05f, -0.1f + (f3 - -0.1f) * 1.05f);
    }

    private static OutlineColorSet E(OutlineColorSet outlineColorSet, Vec3 vn) {
        return outlineColorSet.X(vn.x(), vn.y(), vn.z());
    }

    private static List<Outline> n(Paint paint) {
        float[][] fArrayArray = new float[][]{{-50.0f, 26.5f, 0.75f, 0.3f, 0.0f},new float[]{-24.0f, 27.6f, 0.72f, 0.25f, 0.0f},new float[]{4.0f, 26.9f, 0.8f, -0.2f, 0.0f},new float[]{27.0f, 27.8f, 0.7f, -0.25f, 0.0f},new float[]{52.0f, 26.62f, 0.75f, -0.3f, 0.0f},new float[]{-37.0f, 27.2f, 0.36f, 0.2f, 1.0f},new float[]{40.0f, 27.02f, 0.36f, -0.2f, 1.0f}};
        ArrayList<Outline> arrayList = new ArrayList<Outline>();
        for (float[] fArray : fArrayArray) {
            float[] fArray2 = new float[10];
            float[] fArray3 = new float[10];
            for (int i = 0; i < 10; ++i) {
                fArray2[i] = fArray[1] - 0.3f + (29.6f - fArray[1] + 0.3f) * (float)i / 9.0f;
                fArray3[i] = Luna.m(paint, fArray[0], fArray2[i]);
            }
            arrayList.add(fArray[4] > 0.0f ? new Outline(fArray[0], 29.4f, fArray[1], fArray[2], fArray[3], 0.7f, 0.75f, 0.1f, 0.3f, 0.2f, fArray2, fArray3) : new Outline(fArray[0], 29.4f, fArray[1], fArray[2], fArray[3], 0.5f, 0.45f, 0.05f, 0.4f, 0.22f, fArray2, fArray3));
        }
        return arrayList;
    }

    public static float R(float[] fArray, float[] fArray2, float f) {
        int n = fArray.length;
        if (f <= fArray[0]) {
            return fArray2[0];
        }
        if (f >= fArray[n - 1]) {
            return fArray2[n - 1];
        }
        int n2 = 0;
        while (f > fArray[n2 + 1]) {
            ++n2;
        }
        return fArray2[n2] + (fArray2[n2 + 1] - fArray2[n2]) * (f - fArray[n2]) / (fArray[n2 + 1] - fArray[n2]);
    }

    private static float m(Paint paint, float f, float f2) {
        float f3;
        double d = Math.toRadians(f);
        float f4 = (float)Math.sin(d);
        float f5 = (float)Math.cos(d);
        float f6 = 4.5f;
        for (int i = 0; i < 80 && !(Math.abs(f3 = paint.Q(f4 * f6, f2, -0.3f + f5 * f6)) < 0.001f); ++i) {
            f6 -= f3;
        }
        return f6;
    }

    private static void A(ScaleMustBetween scaleMustBetween, Paint paint, List<Outline> list) {
        int n;
        Outline outline2;
        ArrayList<Paint> arrayList = new ArrayList<Paint>();
        arrayList.add(paint);
        for (int i = -1; i <= 1; i += 2) {
            arrayList.add(Paints.X(0.74f, 0.24f, (float)i * 2.35f, 29.2f, -0.9f, (float)i * 3.04f, 27.6f, -0.72f, (float)i * 3.02f, 26.0f, -0.5f, (float)i * 2.78f, 24.5f, -0.35f).d(1.5f, 0.0f, 26.8f, -0.6f));
        }
        Fill sx2 = Fill.s(Luna::lmbd$hair$0);
        String[] stringArray = b;
        scaleMustBetween.d("hair", RightArm.HEAD).v(Luna.F(Paints.j(arrayList.toArray(new Paint[0])).l(sx2))).E(1.3f).Z(0.6f).i(0.4f).J();
        ArrayList<Paint> arrayList2 = new ArrayList<Paint>();
        for (Outline outline3 : list) {
            arrayList2.add(outline3.t());
        }
        Fill sx3 = Fill.s(Luna::lmbd$hair$1);
        stringArray = b;
        scaleMustBetween.d("bangs", RightArm.HEAD).v(Luna.F(Paints.j(arrayList2.toArray(new Paint[0])).l(sx3))).E(0.45f).Z(1.3f).i(0.7f).G(0.15f).W(-10794346, 0.08f);
        outline2 = new Outline(-72.0f, 29.4f, 24.3f, 0.62f, 0.9f, 0.0f, 0.0f, 0.0f, 0.45f, 0.3f, new float[]{24.0f, 25.0f, 26.2f, 27.6f, 28.8f, 29.6f}, new float[]{2.26f, 2.54f, 2.72f, 2.7f, 2.42f, 2.0f});
        Fill sx4 = Fill.s(Luna::lmbd$hair$2);
        scaleMustBetween.d("locks", RightArm.HEAD).v(Luna.F(outline2.t().s().l(sx4))).E(0.45f).Z(0.7f).i(0.5f).G(0.3f).W(-10794346, 0.08f);
        ArrayList<Paint> arrayList3 = new ArrayList<Paint>();
        ArrayList<Paint> arrayList4 = new ArrayList<Paint>();
        for (n = 0; n < 5; ++n) {
            arrayList3.add(Luna.l(118.0f + 31.0f * (float)n, -0.22f, 18.2f + (float)(n % 2) * 0.35f, 1.25f, 0.5f, 2.6f, (float)n * 1.7f));
        }
        for (n = 0; n < 7; ++n) {
            float f = (float)n / 6.0f;
            float f2 = 16.9f + 1.4f * (float)Math.pow(Math.abs(f - 0.5f) * 2.0f, 1.5) + (float)(n % 3) * 0.3f;
            arrayList4.add(Luna.l(116.0f + 128.0f * f, n % 2 == 0 ? 0.14f : 0.06f, f2, 0.66f, 0.12f, 1.7f, (float)n * 2.3f));
        }
        Paint paint2 = Paints.j(arrayList3.toArray(new Paint[0])).l(Fill.V(-9152312, 18.0f, -5993238, 26.0f));
        Paint paint3 = Paints.j(arrayList4.toArray(new Paint[0])).l(Fill.s(Luna::lmbd$hair$3));
        stringArray = b;
        Luna.E(scaleMustBetween.d("hair_back", RightArm.HEAD), Luna.v(0.0f, 28.2f, -1.6f)).v(Luna.F(Paints.j(paint2, paint3))).K(FollowAmount.O().V(0.8f).m(18.0f)).E(1.15f).Z(0.85f).i(0.35f).W(-10794346, 0.1f);
        FlatMode flatMode = Paints.u(-2.3f, 29.0f, -0.2f, 0.52f, -2.8f, 27.4f, -0.05f, 0.58f, -2.95f, 25.6f, 0.25f, 0.56f, -2.8f, 23.8f, 1.0f, 0.5f, -2.66f, 22.2f, 1.7f, 0.46f, -2.62f, 20.8f, 2.02f, 0.42f).d(1.45f, 0.0f, 22.0f, -0.5f);
        int n2 = 20;
        float[] fArray = new float[n2 * 4];
        for (int i = 0; i < n2; ++i) {
            float f = (float)i / ((float)n2 - 1.0f);
            double d = Math.PI + (double)f * Math.PI * 5.0;
            float f3 = 0.8f - 0.22f * f;
            fArray[i * 4] = -1.82f + f3 * (float)Math.cos(d);
            fArray[i * 4 + 1] = 20.8f - 3.3f * f;
            fArray[i * 4 + 2] = 2.02f + f3 * (float)Math.sin(d);
            fArray[i * 4 + 3] = 0.42f - 0.18f * f;
        }
        Paint paint4 = Paints.j(flatMode, Paints.u(fArray)).l(Fill.V(-7706904, 17.4f, -1912065, 25.0f));
        OutlineColorSet outlineColorSet = Luna.E(scaleMustBetween.d("curl_r", RightArm.HEAD), Luna.v(-2.35f, 28.7f, -0.15f)).v(Luna.F(paint4)).E(0.9f).K(FollowAmount.O().m(4.0f).F(3.0f, 0.0f, 3.5f, 2.0f).V(0.7f).R(10.0f, 0.0f).N(1.4f)).Z(0.9f).i(0.4f).W(-10794346, 0.1f);
        scaleMustBetween.d("curl_l", RightArm.HEAD).F(outlineColorSet);
    }

    private static int i(float f) {
        if (!(f > 26.2f)) return f > 22.0f ? Colors.S(-4940554, -1912065, Luna.M((f - 22.0f) / 4.2f)) : Colors.S(-7706904, -4940554, Luna.M((f - 17.2f) / 4.8f));
        return Colors.S(-1912065, -6519080, Luna.M((f - 26.2f) / 1.9f));
    }

    private static int Z(int n, float f, float f2, float f3, float f4, float f5, int n2, float f6) {
        float f7 = (float)Math.atan2(f, f3 - -0.3f);
        float f8 = Math.abs(f2 - f4 + 0.25f * (1.0f - (float)Math.cos(f7)));
        if (f8 > f5) {
            return n;
        }
        float f9 = (float)Math.sin(f7 * (float)n2 + f6) + 0.2f;
        if (f9 <= 0.0f) {
            return n;
        }
        float f10 = (1.0f - f8 / f5) * Math.min(1.0f, f9 * 3.0f) * 0.8f;
        return Colors.S(n, Colors.S(n, -1, 0.5f), Math.min(1.0f, f10 * 1.6f));
    }

    private static Paint l(float f, float f2, float f3, float f4, float f5, float f6, float f7) {
        double d = Math.toRadians(f);
        float f8 = (float)Math.sin(d);
        float f9 = (float)Math.cos(d);
        float[] fArray = new float[]{29.3f, 27.6f, 25.3f, 23.0f, 20.8f, 18.9f, f3};
        float[] fArray2 = new float[fArray.length * 3];
        for (int i = 0; i < fArray.length; ++i) {
            float f10 = fArray[i];
            float f11 = Luna.g(CURTAIN_Y, CURTAIN_RX, f10) + f2;
            float f12 = Luna.g(CURTAIN_Y, CURTAIN_RZ, f10) + f2;
            float f13 = Luna.g(CURTAIN_Y, CURTAIN_CZ, f10);
            float f14 = 0.32f * Luna.M((26.5f - f10) / 5.0f) * (float)Math.sin(f10 * 0.95f + f7);
            float f15 = i == fArray.length - 1 ? 0.16f : 0.0f;
            fArray2[i * 3] = (f11 + f15) * f8 + f14 * f9;
            fArray2[i * 3 + 1] = f10;
            fArray2[i * 3 + 2] = f13 + (f12 + f15) * f9 - f14 * f8;
        }
        return Paints.X(f4, f5, fArray2).F(f6, f8, 0.0f, f9);
    }

    private static void K(ScaleMustBetween scaleMustBetween) {
        Fill sx2 = Fill.V(-15460295, 28.6f, -14603682, 31.0f);
        Paint paint = Paints.A(Luna::f, -6.1f, 28.1f, -6.35f, 6.1f, 30.1f, 5.85f).l(sx2);
        scaleMustBetween.d("brim", RightArm.HEAD).v(Luna.e(paint)).E(1.2f).Z(0.65f).W(-15921370, 0.12f);
        Paint paint2 = Paints.A(Luna::w, -6.2f, 28.35f, -6.45f, 6.2f, 29.65f, 5.95f).l(Fill.Z(-1326758).h(0.6f, 0.08f));
        Paint paint3 = Paints.Q(0.0f, 28.7f, -0.25f, 3.43f, 0.0f, 31.2f, -0.3f, 3.08f).T(Paints.h(0.0f, 29.95f, -0.27f, 3.6f, 0.5f, 3.6f)).P(Paints.Q(0.0f, 28.7f, -0.25f, 2.75f, 0.0f, 31.2f, -0.3f, 2.4f)).l(Fill.V(-6650664, 29.45f, -4544530, 30.3f));
        scaleMustBetween.d("hat_trim", RightArm.HEAD).v(Luna.e(Paints.j(paint2, paint3))).E(0.95f).Z(0.35f).J();
        Paint paint4 = Paints.Q(0.0f, 28.7f, -0.25f, 3.2f, 0.0f, 31.2f, -0.3f, 2.85f).T(Paints.h(0.0f, 29.6f, -0.27f, 3.5f, 0.75f, 3.5f));
        scaleMustBetween.d("hat", RightArm.HEAD).v(Luna.e(paint4.l(sx2))).E(1.2f).Z(0.3f).W(-15921370, 0.15f);
        scaleMustBetween.d("hat_pin", RightArm.HEAD).v(Luna.e(Luna.d())).E(0.4f).Z(0.9f).W(-8760296, 0.06f);
        Paint paint5 = Paints.u(0.0f, 30.2f, -0.29f, 2.8f, 0.0f, 32.2f, -0.42f, 2.24f, 0.0f, 34.1f, -0.74f, 1.56f, 0.04f, 35.3f, -1.42f, 1.02f, 0.14f, 36.0f, -2.45f, 0.64f, 0.3f, 36.15f, -3.65f, 0.36f).T(Paints.I(30.15f)).V(0.25f, Paints.P(0.0f, 34.45f, -2.3f, 0.9f, 0.35f, 0.45f)).l(Fill.V(-14603682, 30.0f, -14011792, 37.0f));
        Vec3 vn = Luna.a(0.0f, 30.4f, -0.3f);
        OutlineColorSet outlineColorSet = Luna.E(scaleMustBetween.D("hat_tip", scaleMustBetween.T(RightArm.HEAD)), Luna.v(vn.x(), vn.y(), vn.z())).v(Luna.e(paint5)).E(1.25f).K(new FollowAmount().o(2.0f, 0.0f, 2.0f, 0.3f).F(6.0f, 0.0f, 4.0f, 2.0f).m(7.0f).V(0.25f).R(10.0f, 0.0f).e(38.0f, 4.5f).N(1.7f).H(35.0f)).Z(0.75f).W(-15921370, 0.15f);
        Vec3 vn2 = Luna.a(0.28f, 35.9f, -3.5f);
        Paint paint6 = Paints.X(0.08f, 0.08f, vn2.x(), vn2.y(), vn2.z(), vn2.x(), vn2.y() - 0.8f, vn2.z()).n(-5011921);
        Paint paint7 = Paints.D(MinX.t(0.0f, 0.0f, 0.62f, 0.27f, 5).s(180.0f, 0.0f, 0.0f), 0.14f, 0.05f).J(0.0f, 90.0f, 0.0f).B(vn2.x(), vn2.y() - 1.3f, vn2.z()).l(Fill.Z(-9872).l());
        Luna.E(scaleMustBetween.D("hat_charm", outlineColorSet), Luna.v(vn2.x(), vn2.y(), vn2.z())).v(Luna.F(Paints.j(paint6, paint7))).K(FollowAmount.O().V(0.9f).e(60.0f, 6.0f)).E(0.45f).Z(1.2f).W(-8760296, 0.05f);
    }

    private static float f(float f, float f2, float f3) {
        float f4 = f3 + 0.25f;
        float f5 = (float)Math.sqrt(f * f + f4 * f4);
        return BRIM.d(f5, f2 - Luna.q(f, f4, f5, Luna.M((f5 - 2.9f) / 2.9f)));
    }

    private static float w(float f, float f2, float f3) {
        float f4 = f3 + 0.25f;
        float f5 = (float)Math.sqrt(f * f + f4 * f4);
        float f6 = f5 - 5.86f;
        float f7 = f2 - 29.0f - Luna.q(f, f4, f5, 1.0f);
        return (float)Math.sqrt(f6 * f6 + f7 * f7) - 0.31f;
    }

    private static float q(float f, float f2, float f3, float f4) {
        if (f3 < 0.001f) {
            return 0.0f;
        }
        float f5 = 0.3f * f4 * f4 * (f * f - f2 * f2) / (f3 * f3);
        return f5;
    }

    private static Paint d() {
        MinX minX = MinX.R(0.0f, 0.0f, 0.68f).o(MinX.R(0.34f, 0.18f, 0.52f));
        MinX minX2 = MinX.t(0.46f, 0.14f, 0.38f, 0.17f, 5).s(180.0f, 0.46f, 0.14f);
        Paint paint = Paints.j(Paints.D(minX, 0.14f, 0.06f).l(Fill.X(-4688, -0.3f, -0.2f, 0.0f, 0.8f, -1326758).l()), Paints.D(minX2, 0.12f, 0.05f).B(0.0f, 0.0f, 0.04f).l(Fill.Z(-9872).l()));
        double d = Math.toRadians(38.0);
        float f = 3.38f;
        return paint.J(-8.0f, 38.0f, 0.0f).B(f * (float)Math.sin(d), 29.95f, -0.25f + f * (float)Math.cos(d));
    }

    private static Paint e(Paint paint) {
        return Luna.F(paint.L(-8.0f, 0.0f, 4.0f, HAT_CENTRE.x(), HAT_CENTRE.y(), HAT_CENTRE.z()));
    }

    private static Vec3 a(float f, float f2, float f3) {
        return new Vec3(f, f2, f3).rotate(-8.0f, 0.0f, 4.0f, HAT_CENTRE);
    }

    private static void k(ScaleMustBetween scaleMustBetween) {
        Paint paint = Paints.P(0.0f, 21.35f, 0.05f, 2.2f, 1.75f, 1.4f);
        Paint paint2 = Paints.b(0.0f, 22.95f, -0.15f, -2.45f, 22.4f, -0.15f, 0.72f).s();
        Paint paint3 = Paints.P(0.0f, 19.0f, 0.0f, 1.62f, 1.5f, 1.15f);
        Paint paint4 = Paints.P(0.0f, 16.8f, -0.05f, 2.2f, 1.75f, 1.5f);
        Paint paint5 = Paints.O(1.1f, paint, paint2, paint3, paint4);
        Paint paint6 = paint5.l(Fill.V(-14933168, 16.5f, -13945223, 22.5f));
        Paint paint7 = Paints.b(0.0f, 22.9f, -0.15f, 0.0f, 25.1f, -0.05f, 0.6f).l(Fill.V(-6958, 23.7f, -1331558, 24.2f).K(1.0f).T(0.25f));
        Paint paint8 = Paints.Q(0.0f, 22.5f, -0.12f, 1.02f, 0.0f, 24.3f, -0.1f, 0.78f).T(Paints.h(0.0f, 23.45f, -0.1f, 1.3f, 0.63f, 1.3f));
        Paint paint9 = paint5.C(0.22f).T(Paints.h(0.0f, 18.45f, 0.0f, 3.0f, 0.6f, 3.0f)).l(Fill.V(-11653344, 17.9f, -8762574, 18.9f));
        scaleMustBetween.T(RightArm.BODY).X(0.0f, 24.5f, 0.0f).v(Paints.j(paint6, paint7, paint9)).E(1.2f).Z(0.9f).G(0.3f).W(-15921370, 0.14f).D(Luna.Y());
        scaleMustBetween.d("zvuuxk", RightArm.BODY).v(paint8.l(Fill.V(-15460295, 22.9f, -13945223, 24.05f))).E(0.6f).Z(0.35f).G(0.3f).W(-15921370, 0.08f);
        ArrayList<Paint> arrayList = new ArrayList<Paint>();
        float f = Luna.L(paint5, 0.0f, 23.1f, 4.0f);
        float f2 = Math.max(f, Luna.L(paint8, 0.0f, 23.1f, 4.0f));
        arrayList.add(Paints.P(0.0f, 23.08f, f2 + 0.12f, 0.3f, 0.26f, 0.2f).n(-4544530));
        arrayList.add(Paints.P(0.6f, 23.14f, f2 + 0.02f, 0.5f, 0.3f, 0.18f).L(0.0f, -18.0f, -14.0f, 0.6f, 23.14f, f2).s().n(-4544530));
        for (int i = -1; i <= 1; i += 2) {
            float f3 = Luna.L(paint5, (float)i * 0.35f, 22.3f, 4.0f);
            float f4 = Luna.L(paint5, (float)i * 0.55f, 21.6f, 4.0f);
            arrayList.add(Paints.X(0.22f, 0.16f, (float)i * 0.12f, 22.95f, f2 + 0.08f, (float)i * 0.35f, 22.3f, f3 + 0.14f, (float)i * 0.55f, 21.6f, f4 + 0.12f).F(1.7f, 0.0f, 0.0f, 1.0f).n(-4544530));
        }
        arrayList.add(Paints.e(0.0f, 23.08f, f2 + 0.3f, 0.17f).l(Fill.Z(-4678401).l()));
        float f5 = Luna.L(paint9, 0.0f, 18.45f, 4.0f);
        arrayList.add(Paints.D(MinX.t(0.0f, 0.0f, 0.56f, 0.25f, 5).s(180.0f, 0.0f, 0.0f), 0.17f, 0.05f).B(0.0f, 18.45f, f5 + 0.08f).n(-1326758));
        scaleMustBetween.d("trim", RightArm.BODY).v(Paints.j(arrayList.toArray(new Paint[0]))).E(0.5f).Z(0.55f).J();
    }

    private static void o(ScaleMustBetween scaleMustBetween) {
        Paint paint = Paints.A(Luna::I, -6.0f, 6.3f, -6.2f, 6.0f, 25.4f, 1.3f).l(Fill.s(Luna::b));
        scaleMustBetween.d("cape", RightArm.BODY).X(0.0f, 23.0f, -1.0f).v(paint).E(1.35f).K(FollowAmount.t().m(12.0f).V(0.6f)).Z(0.45f).G(0.3f).J().D(Luna.c()).D(Luna.u());
    }

    private static float t(int n, float f) {
        float f2 = (f - CAPE_Y[0]) / (CAPE_Y[CAPE_Y.length - 1] - CAPE_Y[0]) * 96.0f;
        f2 = f2 < 0.0f ? 0.0f : Math.min(f2, 96.0f);
        int n2 = Math.min((int)f2, 95);
        float f3 = CAPE_LUT[n2 * 4 + n];
        return f3 + (CAPE_LUT[n2 * 4 + 4 + n] - f3) * (f2 - (float)n2);
    }

    private static float[] O() {
        float[] fArray = new float[388];
        for (int i = 0; i <= 96; ++i) {
            float f = CAPE_Y[0] + (CAPE_Y[CAPE_Y.length - 1] - CAPE_Y[0]) * (float)i / 96.0f;
            fArray[i * 4] = Luna.g(CAPE_Y, CAPE_RX, f);
            fArray[i * 4 + 1] = Luna.g(CAPE_Y, CAPE_RZ, f);
            fArray[i * 4 + 2] = Luna.g(CAPE_Y, CAPE_CZ, f);
            fArray[i * 4 + 3] = Luna.g(CAPE_Y, CAPE_WRAP, f);
        }
        return fArray;
    }

    private static float I(float f, float f2, float f3) {
        float f4;
        float f5;
        float f6 = Luna.t(0, f2);
        float f7 = Luna.t(1, f2);
        float f8 = Luna.t(2, f2);
        float f9 = Math.abs(Luna.P(f, f3 - f8, f6, f7)) - 0.43f;
        if (f9 < 0.6f) {
            f5 = (float)Math.toDegrees(Math.atan2(Math.abs(f) / f6, -(f3 - f8) / f7));
            f9 = Math.max(f9, (f5 - Luna.t(3, f2)) * 0.0174533f * (f6 + f7) * 0.5f);
        }
        f9 = Math.max(f9, Math.max(f2 - 23.4f, 7.0f - f2));
        if (f2 < 22.5f) {
            return f9;
        }
        f5 = Luna.M((f2 - 22.9f) / 2.3f);
        float f10 = 1.45f + 0.35f * f5;
        float f11 = Math.abs(Luna.P(f, f3 + 0.3f, f10, f4 = 1.3f + 0.3f * f5)) - 0.38f;
        if (f11 < 0.6f) {
            float f12 = (float)Math.toDegrees(Math.atan2(Math.abs(f) / f10, -(f3 + 0.3f) / f4));
            f11 = Math.max(f11, (f12 - 118.0f) * 0.0174533f * 1.5f);
        }
        f11 = Math.max(f11, Math.max(f2 - 25.2f, 22.8f - f2));
        return Math.min(f9, f11);
    }

    private static int b(float f, float f2, float f3) {
        float f4;
        float f5;
        float f6 = Luna.t(0, f2);
        float f7 = Luna.t(1, f2);
        float f8 = Luna.t(2, f2);
        if (f2 > 22.9f && Math.abs(f5 = Luna.P(f, f3 + 0.3f, 1.45f + 0.35f * (f4 = Luna.M((f2 - 22.9f) / 2.3f)), 1.3f + 0.3f * f4)) < Math.abs(Luna.P(f, f3 - f8, f6, f7))) {
            if (!(f5 > 0.0f)) return -7571752;
            return -14603682;
        }
        f4 = Luna.P(f, f3 - f8, f6, f7);
        if (f4 < 0.0f) {
            return -7571752;
        }
        int n = Colors.S(-15460295, -14603682, Luna.M((f2 - 7.0f) / 14.0f));
        return n;
    }

    private static DecalSizeMust c() {
        Height2 height2 = new Height2(176, 176);
        long l = 7L;
        for (int i = 0; i < 36; ++i) {
            long l2 = l * 6364136223846793005L + 1442695040888963407L;
            float f = 7.0f + (float)((l2 >>> 33) % 162L);
            long l3 = l2 * 6364136223846793005L + 1442695040888963407L;
            float f2 = 8.0f + (float)((l3 >>> 33) % 160L);
            l = l3 * 6364136223846793005L + 1442695040888963407L;
            float f3 = 2.8f + (float)((l >>> 33) % 3L);
            boolean bl = (l >>> 40) % 3L == 0L;
            MinX minX = bl ? MinX.t(f, f2, f3 * 1.3f, f3 * 0.3f, 4) : MinX.t(f, f2, f3, f3 * 0.46f, 5);
            height2.H(minX, bl ? -598638 : -1326758);
        }
        height2.H(MinX.R(88.0f, 92.0f, 19.0f).o(MinX.R(97.0f, 86.0f, 16.0f)), -1326758);
        height2.H(MinX.t(97.0f, 88.0f, 7.5f, 3.2f, 5), -598638);
        return DecalSizeMust.J(height2, 0.0f, 12.5f, -3.0f, 11.0f, 11.0f).O(4.0f, 4.0f).u(62.0f);
    }

    private static DecalSizeMust u() {
        Height2 height2 = new Height2(192, 12);
        Luna.V(height2);
        return DecalSizeMust.f(height2, 0.0f, 7.27f, -0.8f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, -1.0f, 230.0f, 0.48f).T(0.03f);
    }

    private static void V(Height2 height2) {
        float f = height2.k();
        float f2 = f * 2.0f;
        height2.V((arg_0, arg_1) -> Luna.lmbd$paintBand$0(f, f2, arg_0, arg_1));
    }

    private static Height2 S(int n, int n2) {
        Height2 height2 = new Height2(n, 16);
        float f = (float)n / (float)n2;
        height2.H(MinX.J((float)n * 0.5f, 3.0f, (float)n * 0.5f, 3.0f, 0.0f), -1036);
        for (int i = 0; i < n2; ++i) {
            float f2 = ((float)i + 0.5f) * f;
            height2.H(MinX.R(f2, 6.5f, f * 0.52f), -1036);
            height2.U(MinX.R(f2, 6.8f, f * 0.16f));
        }
        return height2;
    }

    private static void X(ScaleMustBetween scaleMustBetween, Height2 height2) {
        Height2 height22 = Luna.S(448, 34);
        for (int i = -1; i <= 1; i += 2) {
            String string;
            RightArm rightArm = i < 0 ? RightArm.RIGHT_LEG : RightArm.LEFT_LEG;
            Paint paint = Paints.j(Luna.j(i, 18.5f, 12.4f, 1.75f, 3.45f, 2.5f, 11.0f, 0.24f, 0.78f, 6.0f, 16.0f).b(-13945223, -15460295), Luna.j(i, 13.4f, 9.1f, 3.1f, 3.95f, 1.3f, 14.0f, 0.28f, 0.74f, 14.0f, 22.0f).b(-12693598, -14603682), Luna.j(i, 9.55f, 8.6f, 3.7f, 4.05f, 1.0f, 20.0f, 0.16f, 0.74f, 20.0f, 24.0f).b(-4611086, -7571752));
            if (i < 0) {
                String[] stringArray = b;
                string = "jrpkmFk";
            } else {
                string = "skirt_l";
            }
            scaleMustBetween.d(string, RightArm.BODY).X(0.0f, 18.2f, 0.0f).v(paint).E(1.15f).K(FollowAmount.J(rightArm).D(rightArm, 0.3f, 12.0f)).Z(0.4f).G(0.3f).J().D(Luna.W(height2, 12.58f, (float)i * 76.0f, 140.0f, 0.36f)).D(Luna.W(height2, 9.28f, (float)i * 79.0f, 134.0f, 0.36f)).D(Luna.W(height22, 8.8f, (float)i * 80.0f, 132.0f, 0.34f));
        }
        Folds folds = new Folds(18.2f, 8.7f, 1.6f, 2.9f, 1.6f, 16.0f, 0.12f, 0.66f, -42.0f, -42.0f, 42.0f, 42.0f);
        scaleMustBetween.d("underskirt", RightArm.BODY).X(0.0f, 18.2f, 0.2f).v(folds.b(-4611086, -7571752)).E(1.1f).K(new FollowAmount().m(-8.0f).F(-5.0f, 0.0f, 0.0f, 2.0f).f(90.0f).e(120.0f, 14.0f).N(1.0f)).Z(0.4f).G(0.3f).J().D(Luna.N());
    }

    private static Folds j(int n, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10) {
        return n > 0 ? new Folds(f, f2, f3, f4, f5, f6, f7, f8, f9, f10, 188.0f, 188.0f) : new Folds(f, f2, f3, f4, f5, f6, f7, f8, -188.0f, -188.0f, -f9, -f10);
    }

    private static DecalSizeMust W(Height2 height2, float f, float f2, float f3, float f4) {
        double d = Math.toRadians(f2);
        return DecalSizeMust.f(height2, 0.0f, f, 0.0f, 0.0f, 1.0f, 0.0f, (float)Math.sin(d), 0.0f, (float)Math.cos(d), f3, f4).T(0.03f);
    }

    private static DecalSizeMust N() {
        int n;
        Height2 height2 = new Height2(192, 288);
        long l = 3L;
        for (n = 0; n < 20; ++n) {
            long l2 = l * 6364136223846793005L + 1442695040888963407L;
            float f = 12.0f + (float)((l2 >>> 33) % 168L);
            l = l2 * 6364136223846793005L + 1442695040888963407L;
            float f2 = 88.0f + (float)((l >>> 33) % 170L);
            height2.H(MinX.t(f, f2, 5.4f, 1.7f, 4), -1326758);
        }
        for (n = 0; n < 18; ++n) {
            float f = ((float)n + 0.5f) * 192.0f / 18.0f;
            height2.H(MinX.R(f, 278.0f, 6.2f), -1036);
            height2.U(MinX.R(f, 278.5f, 1.9f));
        }
        height2.H(MinX.J(96.0f, 272.0f, 96.0f, 4.0f, 0.0f), -1036);
        return DecalSizeMust.Z(height2, 0.0f, 13.5f, 3.0f, 6.4f, 9.6f).O(3.5f, 3.0f).u(66.0f);
    }

    private static DecalSizeMust Y() {
        int n;
        Height2 height2 = new Height2(64, 96);
        for (n = -1; n <= 1; n += 2) {
            height2.H(MinX.i(2.0f, 2.0f, 32.0f + (float)n * 10.5f, 2.0f, 32.0f + (float)n * 9.0f, 48.0f, 32.0f + (float)n * 9.8f, 94.0f), -1326758);
        }
        for (n = 0; n < 4; ++n) {
            float f = 13.0f + (float)n * 21.0f;
            height2.H(MinX.R(32.0f, f, 5.0f), -5011921);
            height2.H(MinX.R(32.0f, f, 4.0f), -1326758);
            height2.H(MinX.R(30.8f, f - 1.3f, 1.5f), -2868);
        }
        return DecalSizeMust.Z(height2, 0.0f, 20.6f, 3.0f, 2.0f, 3.0f).O(2.5f, 2.0f).u(70.0f);
    }

    private static Paint s(Paint paint, int n) {
        return paint.L(-12.0f, 0.0f, (float)n * 3.0f, (float)n * ELBOW.x(), ELBOW.y(), ELBOW.z());
    }

    private static Vec3 p(float f, float f2, float f3) {
        return new Vec3(f, f2, f3).rotate(-12.0f, 0.0f, 3.0f, ELBOW);
    }

    private static void X5(ScaleMustBetween scaleMustBetween, Height2 height2) {
        Fill sx2 = Fill.Z(-6958).K(1.0f).T(0.25f);
        Paint paint = Paints.P(-3.5f, 22.0f, -0.1f, 0.92f, 1.0f, 0.9f);
        Paint paint2 = Paints.Q(-3.55f, 21.5f, -0.1f, 0.66f, -3.72f, 18.45f, -0.05f, 0.55f);
        Paint paint3 = Paints.e(-3.72f, 18.4f, -0.05f, 0.55f);
        Paint paint4 = Luna.s(Paints.Q(-3.72f, 18.3f, -0.05f, 0.54f, -3.84f, 15.6f, 0.12f, 0.5f), 1);
        Paint paint5 = Paints.O(0.35f, paint, paint2, paint3, paint4).l(Fill.V(-14867372, 15.0f, -13945223, 22.0f));
        Paint paint6 = Luna.s(Paints.Q(-3.84f, 16.1f, 0.12f, 0.52f, -3.92f, 14.3f, 0.2f, 1.02f).T(Paints.I(14.3f)), 1).n(-13945223);
        Paint paint7 = Luna.s(Paints.Q(-3.84f, 15.7f, 0.12f, 0.2f, -3.93f, 14.0f, 0.2f, 0.5f), 1).n(-7571752);
        Paint paint8 = Paints.j(paint5, Paints.V(paint6, paint7));
        Vec3 vn = Luna.p(-4.0f, 13.3f, 0.42f);
        Vec3 vn2 = Luna.p(-3.91f, 14.52f, 0.2f);
        Vec3 vn3 = new Vec3(-0.04f, 1.0f, 0.05f).rotate(-12.0f, 0.0f, 3.0f);
        Vec3 vn4 = new Vec3(0.0f, 0.0f, 1.0f).rotate(-12.0f, 0.0f, 3.0f);
        OutlineColorSet outlineColorSet = scaleMustBetween.T(RightArm.RIGHT_ARM).X(-3.5f, 22.3f, -0.1f).Y(vn.x(), vn.y(), vn.z()).v(paint8).E(0.95f).Z(0.75f).G(0.3f).W(-15921370, 0.13f).L(0.8f).g(ELBOW.x(), ELBOW.y(), ELBOW.z(), 0.55f).D(DecalSizeMust.f(height2, vn2.x(), vn2.y(), vn2.z(), vn3.x(), vn3.y(), vn3.z(), vn4.x(), vn4.y(), vn4.z(), 360.0f, 0.36f).T(0.03f));
        scaleMustBetween.T(RightArm.LEFT_ARM).F(outlineColorSet);
        ArrayList<Paint> arrayList = new ArrayList<Paint>();
        arrayList.add(Paints.Q(3.92f, 14.6f, 0.22f, 0.33f, 3.97f, 13.8f, 0.28f, 0.33f));
        arrayList.add(Paints.P(4.0f, 13.25f, 0.32f, 0.27f, 0.6f, 0.52f));
        float[] fArray = new float[]{-24.0f, -19.0f, -14.0f, -8.0f};
        for (int i = 0; i < 4; ++i) {
            float f = 0.02f + (float)i * 0.21f;
            float f2 = i != 0 && i != 3 ? 0.8f : 0.62f;
            arrayList.add(Paints.b(4.02f, 12.8f, f, 3.94f, 12.8f - f2, f + 0.1f, 0.12f).L(0.0f, 0.0f, fArray[i], 4.02f, 12.85f, f));
        }
        arrayList.add(Paints.b(3.86f, 13.35f, 0.76f, 3.74f, 12.75f, 0.96f, 0.14f));
        OutlineColorSet outlineColorSet2 = scaleMustBetween.d("hand_l", RightArm.LEFT_ARM).v(Luna.s(Paints.O(0.18f, arrayList.toArray(new Paint[0])).l(sx2), -1)).E(0.5f).Z(0.6f).W(-5737368, 0.08f);
        scaleMustBetween.d("hand_r", RightArm.RIGHT_ARM).F(outlineColorSet2);
    }

    private static void Q(ScaleMustBetween scaleMustBetween) {
        Paint paint = Paints.Q(-1.3f, 15.3f, 0.0f, 1.18f, -1.1f, 8.6f, 0.08f, 0.82f);
        Paint paint2 = Paints.e(-1.08f, 8.25f, 0.14f, 0.78f);
        Paint paint3 = Paints.e(-1.08f, 8.3f, 0.45f, 0.55f);
        Paint paint4 = Paints.Q(-1.08f, 8.0f, 0.1f, 0.8f, -1.14f, 2.1f, -0.1f, 0.5f);
        Paint paint5 = Paints.P(-1.12f, 5.9f, -0.3f, 0.85f, 1.5f, 0.9f);
        Paint paint6 = Paints.O(0.45f, paint, paint2, paint3, paint4, paint5).l(Fill.s(Luna::h));
        Paint paint7 = Paints.Q(-1.12f, 4.9f, -0.08f, 0.8f, -1.1f, 1.5f, -0.1f, 0.62f).T(Paints.d(5.0f));
        Paint paint8 = Paints.P(-1.1f, 0.48f, 1.0f, 0.6f, 0.48f, 0.82f);
        Paint paint9 = Paints.P(-1.1f, 1.0f, 0.25f, 0.64f, 0.62f, 0.9f);
        Paint paint10 = Paints.O(0.35f, paint7, paint8, paint9).l(Fill.V(-9550799, 0.5f, -7710146, 4.6f));
        Paint paint11 = Paints.k(-1.1f, 0.42f, -0.5f, 0.4f, 0.42f, 0.36f, 0.14f).n(-12704232);
        Paint paint12 = Paints.k(-1.1f, 0.12f, 0.97f, 0.64f, 0.12f, 0.8f, 0.1f).n(-12966888);
        Paint paint13 = Paints.p(-1.1f, 1.75f, -0.05f, 0.62f, 0.26f).n(-11653344);
        Paint paint14 = Paints.P(-1.72f, 1.75f, 0.57f, 0.24f, 0.3f, 0.14f).L(0.0f, -45.0f, 0.0f, -1.72f, 1.75f, 0.57f).n(-1326758);
        Paint paint15 = Paints.j(paint10, paint11, paint12, paint13, paint14).L(0.0f, -7.0f, 0.0f, -1.12f, 0.0f, -0.1f);
        Paint paint16 = Paints.j(paint6, paint15).T(Paints.I(0.0f));
        OutlineColorSet outlineColorSet = scaleMustBetween.T(RightArm.RIGHT_LEG).X(-1.3f, 15.3f, 0.0f).v(paint16).E(1.2f).Z(0.75f).G(0.3f).W(-14411226, 0.13f).q(0.55f, 30.0f).g(-1.08f, 8.25f, 0.14f, 0.8f);
        scaleMustBetween.T(RightArm.LEFT_LEG).F(outlineColorSet);
        Paint paint17 = Paints.Z(-1.12f, 4.45f, -0.08f, -1.12f, 5.18f, -0.08f, 0.94f, 0.18f).l(Fill.V(-7710146, 4.5f, -6395064, 5.1f));
        OutlineColorSet outlineColorSet2 = scaleMustBetween.d("cuff_r", RightArm.RIGHT_LEG).v(paint17).E(0.7f).Z(0.9f).G(0.3f).W(-12966888, 0.08f);
        scaleMustBetween.d("cuff_l", RightArm.LEFT_LEG).F(outlineColorSet2);
    }

    private static int h(float f, float f2, float f3) {
        float f4 = -1.1f - 0.2f * Luna.M((f2 - 8.0f) / 7.0f);
        float f5 = 0.05f;
        float f6 = (float)Math.atan2(f - f4, f3 - f5);
        float f7 = (float)Math.exp(-(f6 + 0.35f) * (f6 + 0.35f) / 0.16f);
        int n = Colors.S(Colors.p(-12959880, 0.82f), -12959880, Luna.M((f2 - 3.0f) / 6.0f));
        return Colors.S(n, -10656082, 0.55f * f7);
    }

    private static DecalSizeMust H(List<Outline> list) {
        Height2 height2 = new Height2(192, 158);
        MinX minX = null;
        for (Outline outline : list) {
            MinX minX2 = outline.k(0.28f).O(3.7333333f);
            minX = minX == null ? minX2 : minX.j(minX2);
        }
        height2.a(minX, Colors.K(-1199194, 0.55f), 4.0f);
        height2.J(Luna.r(), 12, 44);
        Vec3 vn = Luna.v(0.0f, 26.90625f, 3.0f);
        return DecalSizeMust.Z(height2, vn.x(), vn.y(), vn.z(), 4.8599997f, 3.9993749f).O(3.0f, 3.0f).u(74.0f).B(0.3f).V(1.0f);
    }

    private static Height2 r() {
        float f = 0.5833333f;
        Height2 height2 = new Height2(168, 114);
        Height2 height22 = new Height2(64, 80);
        Luna.U(new Canvas(height22, f, 60.0f, 96.0f), 122.0f, 181.0f, -1);
        height2.J(height22, 7, 0);
        height2.J(height22.b(), 97, 0);
        Canvas canvas = new Canvas(height2, f, 48.0f, 96.0f);
        for (int i = -1; i <= 1; i += 2) {
            float f2 = 192.0f + (float)i * 70.0f;
            float f3 = 181.0f;
            canvas.k(MinX.t(f2 - 10.0f, f3 - 13.0f, 14.0f, 3.8f, 4), -1);
            canvas.k(MinX.R(f2 - 10.0f, f3 - 13.0f, 4.8f), -1);
            canvas.k(MinX.t(f2 + 12.0f, f3 + 17.0f, 7.0f, 2.1f, 4), -285212673);
            canvas.k(MinX.R(f2 + 10.0f, f3 - 2.0f, 2.3f), -1191182337);
            canvas.P(MinX.f(192.0f + (float)i * 96.0f, 226.0f, 27.0f, 12.0f), 1895793815, 12.0f);
        }
        canvas.k(MinX.h(191.0f, 232.0f, 195.0f, 238.0f, 190.0f, 242.0f, 2.4f, 1.6f), -2135459206);
        canvas.k(MinX.h(180.0f, 275.0f, 192.0f, 284.0f, 204.0f, 275.0f, 3.2f, 3.2f), -7060390);
        canvas.k(MinX.h(188.0f, 285.0f, 192.0f, 287.0f, 196.0f, 285.0f, 1.8f, 1.8f), 1438670960);
        return height2;
    }

    private static void U(Canvas canvas, float f, float f2, int n) {
        MinX minX = MinX.f(f, f2 + 2.0f, 37.0f, 46.0f);
        canvas.Q(minX, GradientNeedsLeast.linear(f, f2 - 44.0f, f, f2 - 8.0f, -3160852, -1));
        GradientNeedsLeast gradientNeedsLeast = GradientNeedsLeast.linear(f, f2 - 36.0f, f, f2 + 44.0f, -14282676, -11194192, -6656782, -2044673);
        canvas.Q(MinX.f(f, f2 + 4.0f, 29.0f, 41.0f).m(minX), (arg_0, arg_1) -> Luna.lmbd$eye$0(f, f2, gradientNeedsLeast, arg_0, arg_1));
        canvas.k(MinX.f(f, f2 + 5.0f, 12.0f, 17.0f), -15136210);
        canvas.k(MinX.i(6.0f, 12.0f, f - (float)n * 37.0f, f2 - 6.0f, f - (float)n * 24.0f, f2 - 36.0f, f + (float)n * 2.0f, f2 - 48.0f, f + (float)n * 25.0f, f2 - 42.0f, f + (float)n * 39.0f, f2 - 26.0f, f + (float)n * 50.0f, f2 - 32.0f), -14938064);
        canvas.k(MinX.h(f + (float)n * 40.0f, f2 - 28.0f, f + (float)n * 52.0f, f2 - 40.0f, f + (float)n * 58.0f, f2 - 50.0f, 5.0f, 1.0f), -14938064);
        canvas.k(MinX.h(f + (float)n * 30.0f, f2 - 38.0f, f + (float)n * 38.0f, f2 - 50.0f, f + (float)n * 40.0f, f2 - 58.0f, 3.5f, 1.0f), -14938064);
        canvas.k(MinX.h(f + (float)n * 6.0f, f2 + 48.0f, f + (float)n * 26.0f, f2 + 44.0f, f + (float)n * 35.0f, f2 + 28.0f, 1.5f, 4.0f), -1069931696);
        canvas.k(MinX.i(2.0f, 2.0f, f - (float)n * 18.0f, f2 - 55.0f, f + (float)n * 4.0f, f2 - 60.0f, f + (float)n * 27.0f, f2 - 53.0f), 1883909461);
        canvas.k(MinX.i(5.5f, 2.0f, f - (float)n * 28.0f, f2 - 70.0f, f + (float)n * 2.0f, f2 - 82.0f, f + (float)n * 36.0f, f2 - 76.0f), -7703368);
    }

    private static float P(float f, float f2, float f3, float f4) {
        float f5 = f / f3;
        float f6 = f2 / f4;
        float f7 = (float)Math.sqrt(f5 * f5 + f6 * f6);
        float f8 = (float)Math.sqrt(f5 * f5 / (f3 * f3) + f6 * f6 / (f4 * f4));
        return f8 < 1.0E-6f ? -Math.min(f3, f4) : f7 * (f7 - 1.0f) / f8;
    }

    private static float g(float[] fArray, float[] fArray2, float f) {
        int n;
        int n2 = fArray.length;
        if (f <= fArray[0]) {
            return fArray2[0];
        }
        if (f >= fArray[n2 - 1]) {
            return fArray2[n2 - 1];
        }
        for (n = 0; n < n2 - 2 && f > fArray[n + 1]; ++n) {
        }
        float f2 = (f - fArray[n]) / (fArray[n + 1] - fArray[n]);
        float f3 = fArray[n + 1] - fArray[n];
        float f4 = n == 0 ? (fArray2[1] - fArray2[0]) / (fArray[1] - fArray[0]) : (fArray2[n + 1] - fArray2[n - 1]) / (fArray[n + 1] - fArray[n - 1]);
        float f5 = n + 2 >= n2 ? (fArray2[n2 - 1] - fArray2[n2 - 2]) / (fArray[n2 - 1] - fArray[n2 - 2]) : (fArray2[n + 2] - fArray2[n]) / (fArray[n + 2] - fArray[n]);
        float f6 = f2 * f2;
        float f7 = f6 * f2;
        return (2.0f * f7 - 3.0f * f6 + 1.0f) * fArray2[n] + (f7 - 2.0f * f6 + f2) * f3 * f4 + (-2.0f * f7 + 3.0f * f6) * fArray2[n + 1] + (f7 - f6) * f3 * f5;
    }

    private static float L(Paint paint, float f, float f2, float f3) {
        float f4;
        float f5 = f3;
        for (int i = 0; i < 80 && !(Math.abs(f4 = paint.Q(f, f2, f5)) < 0.001f); ++i) {
            f5 -= f4;
        }
        return f5;
    }

    public static float M(float f) {
        if (f < 0.0f) {
            return 0.0f;
        }
        float f2 = Math.min(f, 1.0f);
        return f2;
    }

    private static int lmbd$eye$0(float f, float f2, GradientNeedsLeast gradientNeedsLeast, float f3, float f4) {
        float f5 = (f3 - f) / 32.0f;
        float f6 = (f4 - f2 + 28.0f) / 19.0f;
        float f7 = (f3 - f) / 18.0f;
        float f8 = (f4 - f2 - 27.0f) / 10.0f;
        float f9 = (f3 - f) / 29.0f;
        float f10 = (f4 - f2 - 4.0f) / 41.0f;
        float f11 = Luna.M((1.0f - (float)Math.sqrt(f5 * f5 + f6 * f6)) * 8.0f) * 0.47f;
        float f12 = Luna.M((1.0f - (float)Math.sqrt(f7 * f7 + f8 * f8)) * 5.0f) * 0.5f;
        float f13 = Luna.M(((float)Math.sqrt(f9 * f9 + f10 * f10) - 0.88f) / 0.06f) * 0.82f;
        int n = Colors.S(Colors.S(gradientNeedsLeast.argb(f3, f4), -14676416, f11), -726785, f12);
        return Colors.S(n, -14479041, f13);
    }

    private static int lmbd$paintBand$0(float f, float f2, float f3, float f4) {
        float f5 = f4 / f;
        if (f5 < 0.1f) return 0;
        if (f5 > 0.9f) {
            return 0;
        }
        if (f5 < 0.24f) return -5011921;
        if (f5 > 0.76f) return -5011921;
        float f6 = ((float)Math.floor(f3 / f2) + 0.5f) * f2;
        if (!(Math.abs(f3 - f6) + Math.abs(f4 - f * 0.5f) < f * 0.22f)) return -1326758;
        return -2868;
    }

    private static int lmbd$hair$3(float f, float f2, float f3) {
        return Luna.Z(Luna.i(f2), f, f2, f3, 27.25f, 0.3f, 6, 1.1f);
    }

    private static int lmbd$hair$2(float f, float f2, float f3) {
        return f2 > 27.2f ? Colors.S(-1647873, -6519080, Luna.M((f2 - 27.2f) / 1.8f)) : Colors.S(-4940554, -1647873, Luna.M((f2 - 24.3f) / 2.9f));
    }

    private static int lmbd$hair$1(float f, float f2, float f3) {
        return Luna.Z(Colors.S(-1647873, -6519080, Luna.M((f2 - 27.1f) / 1.9f)), f, f2, f3, 28.45f, 0.14f, 11, 0.9f);
    }

    private static int lmbd$hair$0(float f, float f2, float f3) {
        return Luna.Z(Colors.S(-4940554, -1912065, Luna.M((f2 - 24.6f) / 3.6f)), f, f2, f3, 28.1f, 0.26f, 7, 0.3f);
    }

    static {
        b = new String[]{"brim", "hat_pin", "curl_r", "hair_back", "hand_l", "bangs", "cuff_r", "locks", "underskirt", "hand_r", "hair", "curl_l", "luna", "hat_trim", "hat_charm", "hat", "skirt_l", "Luna", "cape", "hat_tip", "cuff_l", "trim", "jrpkmFk", "zvuuxk"};
        HAT_CENTRE = new Vec3(0.0f, 29.15f, -0.25f);
        BRIM = MinX.D(2.9f, 29.25f, 0.82f, 5.72f, 29.0f, 0.5f);
        ELBOW = new Vec3(-3.72f, 18.4f, -0.05f);
        CAPE_Y = new float[]{7.0f, 10.0f, 13.5f, 17.0f, 20.5f, 23.4f};
        CAPE_RX = new float[]{5.15f, 4.85f, 4.15f, 3.45f, 3.2f, 3.15f};
        CAPE_RZ = new float[]{4.45f, 4.2f, 3.5f, 2.3f, 1.62f, 1.3f};
        CAPE_CZ = new float[]{-0.8f, -0.85f, -0.85f, -0.6f, -0.45f, -0.35f};
        CAPE_WRAP = new float[]{104.0f, 102.0f, 100.0f, 105.0f, 118.0f, 132.0f};
        CAPE_LUT = Luna.O();
        CURTAIN_Y = new float[]{17.0f, 20.0f, 22.5f, 24.5f, 27.6f, 29.3f};
        CURTAIN_RX = new float[]{3.2f, 3.05f, 2.95f, 2.95f, 3.12f, 2.35f};
        CURTAIN_RZ = new float[]{3.0f, 2.65f, 2.25f, 2.55f, 3.05f, 2.35f};
        CURTAIN_CZ = new float[]{-0.95f, -0.95f, -0.9f, -0.65f, -0.3f, -0.3f};
    }
}
