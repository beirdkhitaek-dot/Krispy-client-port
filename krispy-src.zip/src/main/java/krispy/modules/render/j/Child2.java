package krispy.modules.render.j;

import krispy.modules.render.j.MinX;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Child2
extends MinX {
    private final MinX child;
    private final float r;
    private final boolean ring;

    Child2(MinX minX, float f, boolean bl) {
        this.child = minX;
        this.r = f;
        this.ring = bl;
        float f2 = Math.abs(f);
        this.L(minX.minX - f2, minX.minY - f2, minX.maxX + f2, minX.maxY + f2);
    }

    @Override
    public float d(float f, float f2) {
        float f3 = this.child.d(f, f2);
        return this.ring ? Math.abs(f3) - this.r : f3 - this.r;
    }
}
