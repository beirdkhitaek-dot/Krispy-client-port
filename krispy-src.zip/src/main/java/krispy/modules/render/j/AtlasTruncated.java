package krispy.modules.render.j;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.zip.InflaterInputStream;
import krispy.modules.render.j.FirstPersonArms;
import krispy.modules.render.j.Height3;
import krispy.modules.render.j.Medium;
import krispy.modules.render.j.MotionSlot;
import krispy.modules.render.j.QuadCount;
import krispy.modules.render.j.RightArm;
import krispy.modules.render.j.Source2;
import krispy.modules.render.j.Triangles;
import krispy.modules.render.j.CharacterMesh;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class AtlasTruncated {
    private static String[] a;
    public static final int MAGIC = 1095648072;
    public static final int VERSION = 3;
    private static final int SHIPPED_VERSION = 4;

    private AtlasTruncated() {
    }

    static FirstPersonArms B(Source2 source2, Medium medium) {
        FirstPersonArms firstPersonArms;
        long l = System.nanoTime();
        InputStream inputStream;
        try {
            inputStream = source2.J();
        }
        catch (IOException iOException) {
            throw new UncheckedIOException(iOException);
        }
        try {
            int n;
            DataInputStream dataInputStream = new DataInputStream(new BufferedInputStream(inputStream));
            int n2 = n = dataInputStream.readInt() == 1095648072 ? dataInputStream.readInt() : -1;
            if (n != 3 && n != 4) {
                throw new IllegalStateException(source2.C() + ": not a version 3 baked character");
            }
            int n3 = 0;
            int n4 = 0;
            int[] nArray = null;
            if (n == 4) {
                n3 = dataInputStream.readInt();
                n4 = dataInputStream.readInt();
                byte[] byArray = new byte[n3 * n4 * 4];
                dataInputStream.readFully(byArray);
                nArray = AtlasTruncated.P(byArray, n3, n4);
            }
            float f = dataInputStream.readFloat();
            float f2 = dataInputStream.readFloat();
            float f3 = dataInputStream.readFloat();
            float f4 = dataInputStream.readFloat();
            boolean bl = dataInputStream.readBoolean();
            boolean bl2 = dataInputStream.readBoolean();
            int n5 = dataInputStream.readInt();
            int n6 = Math.min(medium.ordinal(), n5 - 1);
            MotionSlot[] motionSlotArray = new MotionSlot[dataInputStream.readInt()];
            for (int i = 0; i < motionSlotArray.length; ++i) {
                RightArm rightArm = RightArm.values()[dataInputStream.readByte()];
                float f5 = dataInputStream.readFloat();
                float f6 = dataInputStream.readFloat();
                float f7 = dataInputStream.readFloat();
                float f8 = dataInputStream.readFloat();
                float f9 = dataInputStream.readFloat();
                float f10 = dataInputStream.readFloat();
                float[] fArray = new float[6];
                for (int j = 0; j < 6; ++j) {
                    fArray[j] = dataInputStream.readFloat();
                }
                float f11 = dataInputStream.readFloat();
                float f12 = dataInputStream.readFloat();
                boolean bl3 = dataInputStream.readBoolean();
                float f13 = 0.0f;
                float f14 = 0.0f;
                float f15 = 0.0f;
                if (bl3) {
                    f13 = dataInputStream.readFloat() - f5;
                    f14 = dataInputStream.readFloat() - f6;
                    f15 = dataInputStream.readFloat() - f7;
                }
                Triangles triangles = null;
                Triangles triangles2 = null;
                for (int j = 0; j < n5; ++j) {
                    Triangles triangles3 = AtlasTruncated.H(dataInputStream, fArray, f5, f6, f7, f4, bl2, bl3, j == n6);
                    Triangles triangles4 = AtlasTruncated.H(dataInputStream, fArray, f5, f6, f7, f4, bl2, bl3, j == n6);
                    if (j != n6) continue;
                    triangles = triangles3;
                    triangles2 = triangles4;
                }
                motionSlotArray[i] = new MotionSlot(rightArm.name(), rightArm, -1, false, f5, f6, f7, f8, f9, f10, null, triangles, null, triangles2, -1, f11, f12, bl3, f13, f14, f15, false, 0.0f, 0.0f, 0.0f);
            }
            if (n == 3) {
                n3 = dataInputStream.readInt();
                n4 = dataInputStream.readInt();
                byte[] byArray = new byte[dataInputStream.readInt()];
                dataInputStream.readFully(byArray);
                nArray = AtlasTruncated.Y(byArray, n3, n4);
            }
            long l2 = (System.nanoTime() - l) / 1000000L;
            firstPersonArms = new FirstPersonArms(source2.C(), source2.B(), medium, 1.0f, motionSlotArray, 0, n3, n4, Height3.d(nArray, n3, n4), 0.0f, 0.0f, f, f2, f3, bl, l2);
            if (inputStream == null) return firstPersonArms;
        }
        catch (Throwable throwable) {
            try {
                if (inputStream == null) throw throwable;
                try {
                    inputStream.close();
                    throw throwable;
                }
                catch (Throwable throwable2) {
                    throwable.addSuppressed(throwable2);
                }
                throw throwable;
            }
            catch (IOException iOException) {
                throw new UncheckedIOException(source2.B() + ": " + iOException.getMessage(), iOException);
            }
        }
        try {
            inputStream.close();
        }
        catch (IOException iOException) {

        }
        return firstPersonArms;
    }

    private static int[] Y(byte[] byArray, int n, int n2) throws IOException {
        byte[] byArray2 = new byte[n * n2 * 4];
        try (InflaterInputStream inflaterInputStream = new InflaterInputStream(new ByteArrayInputStream(byArray));){
            int n3 = inflaterInputStream.readNBytes(byArray2, 0, byArray2.length);
            if (n3 == byArray2.length) return AtlasTruncated.P(byArray2, n, n2);
            throw new IOException("atlas is truncated");
        }
    }

    private static int[] P(byte[] byArray, int n, int n2) {
        int[] nArray = new int[n * n2];
        for (int i = 0; i < nArray.length; ++i) {
            int n3 = i % n == 0 ? 0 : nArray[i - 1];
            int n4 = 0;
            for (int j = 0; j < 4; ++j) {
                int n5 = 24 - j * 8;
                n4 |= (byArray[i * 4 + j] + (n3 >>> n5) & 0xFF) << n5;
            }
            nArray[i] = n4;
        }
        return nArray;
    }

    private static Triangles H(DataInputStream dataInputStream, float[] fArray, float f, float f2, float f3, float f4, boolean bl, boolean bl2, boolean bl3) throws IOException {
        int n;
        int n2 = dataInputStream.readInt();
        if (!bl3) {
            dataInputStream.skipNBytes((long)n2 * (13L + (bl ? 3L : 0L) + (bl2 ? 1L : 0L)));
            dataInputStream.skipNBytes((long)dataInputStream.readInt() * (n2 > 65535 ? 12L : 6L));
            return null;
        }
        float[] fArray2 = new float[n2 * 3];
        for (int i = 0; i < fArray2.length; ++i) {
            int n3 = i % 3;
            fArray2[i] = fArray[n3] + (float)dataInputStream.readChar() / 65535.0f * (fArray[n3 + 3] - fArray[n3]);
        }
        byte[] byArray = new byte[n2 * 3];
        dataInputStream.readFully(byArray);
        float[] fArray3 = new float[n2 * 2];
        for (int i = 0; i < fArray3.length; ++i) {
            fArray3[i] = (float)dataInputStream.readChar() / 65535.0f;
        }
        int[] nArray = new int[n2];
        for (int i = 0; i < n2; ++i) {
            nArray[i] = bl ? 0xFF000000 | dataInputStream.readUnsignedByte() << 16 | dataInputStream.readUnsignedByte() << 8 | dataInputStream.readUnsignedByte() : -1;
        }
        float[] fArray4 = null;
        if (bl2) {
            fArray4 = new float[n2];
            for (n = 0; n < n2; ++n) {
                fArray4[n] = (float)dataInputStream.readUnsignedByte() / 255.0f;
            }
        }
        n = dataInputStream.readInt();
        int[] nArray2 = new int[n * 3];
        for (int i = 0; i < nArray2.length; ++i) {
            nArray2[i] = n2 > 65535 ? dataInputStream.readInt() : (int)dataInputStream.readChar();
        }
        if (n2 == 0 || n == 0) return null;
        QuadCount quadCount = new QuadCount();
        for (int i = 0; i < n2; ++i) {
            float f5 = (float)byArray[i * 3] / 127.0f;
            float f6 = (float)byArray[i * 3 + 1] / 127.0f;
            float f7 = (float)byArray[i * 3 + 2] / 127.0f;
            float f8 = (float)Math.sqrt(f5 * f5 + f6 * f6 + f7 * f7);
            if (f8 > 1.0E-6f) {
                f5 /= f8;
                f6 /= f8;
                f7 /= f8;
            }
            quadCount.G(fArray2[i * 3] - f, fArray2[i * 3 + 1] - f2, fArray2[i * 3 + 2] - f3, f5, f6, f7, fArray3[i * 2], fArray3[i * 2 + 1], nArray[i], false, f4);
        }
        CharacterMesh.A(nArray2, n, n2, quadCount);
        Triangles triangles = quadCount.i();
        if (triangles == null || fArray4 == null) return triangles;
        for (float f8 : fArray4) {
            if (!(f8 > 0.0f)) continue;
            triangles.joint = fArray4;
            return triangles;
        }
        return triangles;
    }

    static {
        a = new String[]{": ", ": not a version 3 baked character", "atlas is truncated"};
    }
}
