package krispy.modules.render.j;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import krispy.modules.render.j.DecalSizeMust;
import krispy.modules.render.j.FlatMode;
import krispy.modules.render.j.FollowAmount;
import krispy.modules.render.j.GradientNeedsLeast;
import krispy.modules.render.j.Height2;
import krispy.modules.render.j.MinX;
import krispy.modules.render.j.Paints;
import krispy.modules.render.j.Name;
import krispy.modules.render.j.OutlineColorSet;
import krispy.modules.render.j.Paint;
import krispy.modules.render.j.RightArm;
import krispy.modules.render.j.ScaleMustBetween;
import krispy.modules.render.j.Colors;
import krispy.modules.render.j.Fill;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class Aoi
extends Name {
    private static final float TAU = (float)Math.PI * 2;
    private static final float NECK = 24.4f;
    private static final float HEAD_K = 1.16f;
    private static final float HEAD_DY = -0.25f;
    private static final float FACE_X = 2.25f;
    private static final float FACE_TOP = 28.6f;
    private static final float FACE_LOW = 26.08f;
    private static final float FACE_PX = 80.0f;
    private static final float YOKE = 21.75f;
    private static final float BEND = 13.0f;
    private static final int SKIN = -9274;
    private static final int SKIN_SHADE = -1331558;
    private static final int SKIN_LINE = -6657438;
    private static final int HAIR = -14140794;
    private static final int HAIR_DEEP = -15063975;
    private static final int HAIR_TOP = -12756032;
    private static final int HAIR_BLUE = -12948262;
    private static final int HAIR_TIP = -13246209;
    private static final int HAIR_INNER = -13646610;
    private static final int HAIR_SHINE = -7363350;
    private static final int HAIR_LINE = -15327158;
    private static final int CYAN = -13703425;
    private static final int NAVY = -14932394;
    private static final int JACKET = -12959662;
    private static final int JACKET_DARK = -14210250;
    private static final int JACKET_WHITE = -1446155;
    private static final int JACKET_SHADE = -3945254;
    private static final int LINE = -15065558;
    private static final int TOP = -525828;
    private static final int TOP_SHADE = -2498584;
    private static final int SKIRT = -12892555;
    private static final int SKIRT_DARK = -14472632;
    private static final int BLACK = -15263457;
    private static final int SILVER = -3550757;
    private static final int SOCK = -14012606;
    private static final int SOLE = -920586;
    private static final float SKIRT_ZC = -0.05f;
    private static final float SKIRT_TOP = 17.3f;
    private static final float SKIRT_HEM = 11.25f;
    private static final int PLEATS = 18;
    private static float[][] MAIN_LOCKS;
    private static float[][] ACCENT_LOCKS;
    private static String[] b;

    public Aoi() {
        super("aoi", "Aoi");
    }

    @Override
    protected void D(ScaleMustBetween scaleMustBetween) {
        scaleMustBetween.v(1.0f).H(-15065558, 0.13f).A(0.35f);
        Height2 height2 = Aoi.M();
        Paint paint = Aoi.k();
        List<float[]> list = Aoi.o(paint, MAIN_LOCKS, 0.2f, 0.17f);
        List<float[]> list2 = Aoi.o(paint, ACCENT_LOCKS, 0.2f, 0.17f);
        scaleMustBetween.T(RightArm.HEAD).X(0.0f, 24.4f, 0.0f).v(Aoi.j(paint.n(-9274))).Z(1.1f).E(0.85f).W(-6657438, 0.09f).i(1.0f).G(0.2f).D(Aoi.Z(list));
        Aoi.X(scaleMustBetween, list, list2);
        Aoi.J(scaleMustBetween);
        Paint paint2 = Aoi.Q(scaleMustBetween, height2);
        Aoi.I(scaleMustBetween, height2);
        Aoi.b(scaleMustBetween, height2);
        Aoi.N(scaleMustBetween);
        Aoi.Ii(scaleMustBetween, paint2);
    }

    private static Paint j(Paint paint) {
        return paint.X(1.16f, 0.0f, 24.4f, 0.0f).B(0.0f, -0.25f, 0.0f);
    }

    private static float g(float f) {
        return 24.4f + (f - 24.4f) * 1.16f + -0.25f;
    }

    private static Paint k() {
        Paint paint = Paints.P(0.0f, 28.52f, -0.15f, 2.28f, 2.24f, 2.32f);
        Paint paint2 = Paints.P(0.0f, 27.4f, 0.7f, 1.95f, 1.1f, 1.45f);
        Paint paint3 = Paints.Q(0.0f, 27.25f, 0.42f, 1.68f, 0.0f, 26.15f, 1.18f, 0.55f);
        Paint paint4 = Paints.D(MinX.c(-2.6f, 31.5f, -2.6f, 29.0f, -2.24f, 27.6f, -2.11f, 27.2f, -1.9f, 26.8f, -1.62f, 26.44f, -1.28f, 26.12f, -0.92f, 25.91f, -0.54f, 25.79f, -0.25f, 25.75f, 0.0f, 25.74f, 0.25f, 25.75f, 0.54f, 25.79f, 0.92f, 25.91f, 1.28f, 26.12f, 1.62f, 26.44f, 1.9f, 26.8f, 2.11f, 27.2f, 2.24f, 27.6f, 2.6f, 29.0f, 2.6f, 31.5f), 4.0f, 0.0f);
        Paint paint5 = Paints.O(0.9f, paint, paint2, paint3);
        Paint paint6 = paint5.w(0.3f, paint4);
        return Paints.A((arg_0, arg_1, arg_2) -> Aoi.lmbd$headShape$0(paint5, paint6, arg_0, arg_1, arg_2), paint5.o(), paint5.j(), -1.1f, paint5.u(), 30.2f, paint5.p());
    }

    private static List<float[]> o(Paint paint, float[][] fArray, float f, float f2) {
        ArrayList<float[]> arrayList = new ArrayList<float[]>();
        for (float[] fArray2 : fArray) {
            int n = (fArray2.length - 1) / 2;
            float[] fArray3 = new float[n * 4];
            for (int i = 0; i < n; ++i) {
                float f3 = fArray2[1 + i * 2];
                float f4 = fArray2[2 + i * 2];
                float f5 = 1.0f - f3 * f3 / 6.76f - (f4 - 28.62f) * (f4 - 28.62f) / 7.08f;
                float f6 = Math.max(Aoi.s(paint, f3, f4, 5.0f), -0.5f + 2.64f * (float)Math.sqrt(Math.max(0.0f, f5)));
                float f7 = f3;
                float f8 = f4 - 28.3f;
                float f9 = f6 + 0.4f;
                float f10 = (float)Math.sqrt(f7 * f7 + f8 * f8 + f9 * f9);
                float f11 = (float)i / ((float)n - 1.0f);
                float f12 = (i == 0 ? 0.1f : (i == n - 1 ? f2 : f)) + 0.22f * Aoi.R(1.3f, 2.2f, Math.abs(f3));
                fArray3[i * 4] = f3 + f7 / f10 * f12;
                fArray3[1 + i * 4] = f4 + f8 / f10 * f12;
                fArray3[2 + i * 4] = f6 + f9 / f10 * f12;
                fArray3[3 + i * 4] = fArray2[0] * (float)Math.pow(1.0f - f11, 1.2f) + 0.05f * f11;
            }
            arrayList.add(fArray3);
        }
        return arrayList;
    }

    private static void X(ScaleMustBetween scaleMustBetween, List<float[]> list, List<float[]> list2) {
        ArrayList<Paint> arrayList = new ArrayList<Paint>();
        arrayList.add(Paints.N(0.35f, Paints.P(0.0f, 28.62f, -0.2f, 2.6f, 2.66f, 2.64f), Paints.P(0.0f, 26.75f, 2.75f, 2.45f, 2.85f, 2.72f)).T(Paints.I(26.0f)));
        for (float sx3 : new float[]{-155.0f, -118.0f, -80.0f, 80.0f, 118.0f, 155.0f}) {
            arrayList.add(Aoi.eT(sx3));
        }
        scaleMustBetween.d("hair", RightArm.HEAD).v(Aoi.j(Paints.j(arrayList.toArray(new Paint[0])).l(Aoi.O()))).Z(0.8f).E(0.95f).W(-15327158, 0.1f).i(0.5f).G(0.4f);
        OutlineColorSet outlineColorSet = scaleMustBetween.d("fringe", RightArm.HEAD).v(Aoi.j(Aoi.P(list, list2))).Z(0.4f).E(0.55f).W(-15327158, 0.09f).i(0.5f).G(0.2f);
        Aoi.F(outlineColorSet, list);
        FollowAmount followAmount = FollowAmount.O().o(1.5f, 0.0f, 1.5f, 0.35f).F(3.0f, 0.0f, 3.0f, 2.0f).m(8.0f).V(0.7f).R(10.0f, 0.0f).e(60.0f, 7.0f).N(1.3f);
        Fill sx2 = Fill.s(Aoi::lmbd$hair$0);
        Fill sx3 = Fill.s(Aoi::lmbd$hair$1);
        Paint paint = Paints.j(Paints.u(-1.55f, 29.95f, 1.0f, 0.4f, -2.32f, 28.5f, 1.4f, 0.55f, -2.55f, 27.1f, 1.3f, 0.52f, -2.48f, 25.9f, 1.15f, 0.42f, -2.3f, 24.9f, 1.2f, 0.28f, -2.1f, 24.3f, 1.34f, 0.04f).d(2.0f, 0.0f, 27.5f, -0.5f).l(sx2), Paints.u(-1.7f, 29.7f, 0.7f, 0.36f, -2.28f, 28.2f, 1.05f, 0.44f, -2.36f, 26.8f, 0.95f, 0.42f, -2.22f, 25.6f, 0.9f, 0.3f, -2.05f, 24.55f, 1.0f, 0.04f).d(2.0f, 0.0f, 27.5f, -0.5f).l(sx3));
        OutlineColorSet outlineColorSet2 = scaleMustBetween.d("lock_r", RightArm.HEAD).X(-2.32f, Aoi.g(29.2f), 1.16f).v(Aoi.j(paint)).K(followAmount).Z(0.7f).E(0.7f).W(-15327158, 0.1f).i(0.5f).G(0.35f);
        scaleMustBetween.d("lock_l", RightArm.HEAD).F(outlineColorSet2);
    }

    private static Paint eT(float f) {
        float f2 = 0.0f;
        float f3 = 28.62f;
        float f4 = -0.2f;
        float f5 = 2.6f;
        float f6 = 2.66f;
        float f7 = 2.64f;
        float f8 = (float)Math.toRadians(f);
        float f9 = Math.abs(f);
        float f10 = 29.1f - 1.7f * Aoi.R(20.0f, 90.0f, f9) - 1.2f * Aoi.R(95.0f, 160.0f, f9);
        float f11 = (float)Math.asin(Math.max(-0.95f, Math.min(0.95f, (f10 - f3) / f6)));
        float f12 = (float)(Math.sin(f8) * Math.cos(f11));
        float f13 = (float)Math.sin(f11);
        float f14 = (float)(Math.cos(f8) * Math.cos(f11));
        float f15 = 0.0f;
        float f16 = 30.25f - f3;
        float f17 = -1.95f - f4;
        float f18 = (float)Math.sqrt(f15 * f15 + f16 * f16 + f17 * f17);
        f15 /= f18;
        f16 /= f18;
        f17 /= f18;
        float[] fArray = new float[]{0.0f, 0.35f, 0.7f, 1.0f};
        float[] fArray2 = new float[]{0.5f, 0.56f, 0.5f, 0.32f};
        float[] fArray3 = new float[16];
        for (int i = 0; i < 4; ++i) {
            float f19 = f12 + (f15 - f12) * fArray[i];
            float f20 = f13 + (f16 - f13) * fArray[i];
            float f21 = f14 + (f17 - f14) * fArray[i];
            float f22 = (float)Math.sqrt(f19 * f19 + f20 * f20 + f21 * f21);
            float f23 = 1.0f / (float)Math.sqrt((f19 /= f22) * f19 / (f5 * f5) + (f20 /= f22) * f20 / (f6 * f6) + (f21 /= f22) * f21 / (f7 * f7));
            float f24 = i == 3 ? -0.1f : 0.04f;
            fArray3[i * 4] = f2 + f19 * (f23 + f24);
            fArray3[i * 4 + 1] = f3 + f20 * (f23 + f24);
            fArray3[i * 4 + 2] = f4 + f21 * (f23 + f24);
            fArray3[i * 4 + 3] = fArray2[i];
        }
        return Paints.u(fArray3).d(2.4f, f2, f3, f4);
    }

    private static Fill O() {
        return Fill.s(Aoi::lmbd$capPaint$0);
    }

    private static Paint P(List<float[]> list, List<float[]> list2) {
        Paint[] paintArray = new Paint[list.size() + list2.size()];
        for (int i = 0; i < paintArray.length; ++i) {
            boolean bl = i >= list.size();
            float[] fArray = bl ? list2.get(i - list.size()) : list.get(i);
            int n = fArray.length / 4;
            float[] fArray2 = new float[n * 2];
            for (int j = 0; j < n; ++j) {
                fArray2[j * 2] = fArray[j * 4];
                fArray2[j * 2 + 1] = fArray[j * 4 + 1];
            }
            float f = bl ? 1.12f : ((i & 1) == 0 ? 0.93f : 1.04f);
            paintArray[i] = Paints.u(fArray).d(2.6f, 0.0f, 28.4f, -0.3f).T(Paints.D(MinX.i(fArray[3] * 2.6f, 0.02f, fArray2), 4.0f, 0.0f)).l(Fill.s((arg_0, arg_1, arg_2) -> Aoi.lmbd$fringe$0(f, arg_0, arg_1, arg_2)));
        }
        return Paints.j(paintArray);
    }

    private static void F(OutlineColorSet outlineColorSet, List<float[]> list) {
        for (int i = 0; i < list.size(); ++i) {
            float[] fArray = list.get(i);
            int n = fArray.length / 4;
            for (int j = 1; j < n; ++j) {
                float f;
                float f2 = fArray[j * 4 - 3];
                float f3 = fArray[j * 4 + 1];
                if (f2 < 29.15f || f3 > 29.15f) continue;
                float f4 = (f2 - 29.15f) / (f2 - f3);
                float f5 = fArray[j * 4 - 4] + (fArray[j * 4] - fArray[j * 4 - 4]) * f4;
                float f6 = fArray[j * 4 - 2] + (fArray[j * 4 + 2] - fArray[j * 4 - 2]) * f4;
                float f7 = fArray[j * 4 - 1] + (fArray[j * 4 + 3] - fArray[j * 4 - 1]) * f4;
                float f8 = (float)Math.atan2(f5, f6 + 0.2f);
                if (Math.abs(f8) > 0.96f) continue;
                float f9 = f7 * 1.1f / (float)Math.sqrt(f5 * f5 + (f6 + 0.2f) * (f6 + 0.2f));
                float f10 = 7.0f + (float)Math.toDegrees(f9) * 0.25f;
                float f11 = 64.0f / (f9 * 1.5f);
                float[] fArray2 = new float[6];
                float[] fArray3 = new float[6];
                for (int k = 0; k < 3; ++k) {
                    f = f9 * 0.6f * ((float)k * 0.5f - 1.0f);
                    float f12 = f9 * 0.6f * (float)k * 0.5f;
                    fArray2[k * 2] = 32.0f + f * f11;
                    fArray2[k * 2 + 1] = 13.0f + 25.0f * ((float)Math.cos(f8) - (float)Math.cos(f8 + f));
                    fArray3[k * 2] = 32.0f + f12 * f11;
                    fArray3[k * 2 + 1] = 13.0f + 25.0f * ((float)Math.cos(f8) - (float)Math.cos(f8 + f12));
                }
                Height2 height2 = new Height2(64, 26);
                height2.a(MinX.i(f10 * 0.2f, f10, fArray2).j(MinX.i(f10, f10 * 0.2f, fArray3)), Colors.K(-7363350, 0.5f), 5.0f);
                f = Aoi.g(29.1f) + 0.081f - 0.29f * (1.0f - (float)Math.cos(f8)) + (float)((i & 1) * 2 - 1) * 0.03f;
                outlineColorSet.D(DecalSizeMust.f(height2, 0.0f, f, -0.232f, 0.0f, 1.0f, 0.0f, (float)Math.sin(f8), 0.0f, (float)Math.cos(f8), (float)Math.toDegrees(f9 * 1.5f), 0.30159998f).H(1.8f, 4.2f).V(0.8f));
            }
        }
    }

    private static void J(ScaleMustBetween scaleMustBetween) {
        float[][] fArrayArray;
        int var11_19 = 0;
        float[][] fArrayArray2 = new float[][]{{30.4f, -2.0f},new float[]{31.1f, -2.5f},new float[]{31.35f, -3.25f},new float[]{30.95f, -3.95f},new float[]{29.7f, -4.3f},new float[]{27.6f, -4.38f},new float[]{25.1f, -4.22f},new float[]{22.5f, -4.0f},new float[]{19.9f, -3.8f},new float[]{17.5f, -3.68f},new float[]{15.3f, -3.74f}};
        int n = fArrayArray2.length;
        float[] fArray = new float[]{0.0f, 0.55f, 1.0f, 1.18f, 1.22f, 1.18f, 1.08f, 0.96f, 0.86f, 0.98f, 1.35f};
        float[] fArray2 = new float[]{0.45f, 0.88f, 1.05f, 1.1f, 1.1f, 1.05f, 0.98f, 0.86f, 0.7f, 0.52f, 0.34f};
        float[] fArray3 = new float[n];
        float[] fArray4 = new float[n];
        for (int i = 0; i < n; ++i) {
            int n2 = Math.max(0, i - 1);
            int n3 = Math.min(n - 1, i + 1);
            float i2 = fArrayArray2[n3][0] - fArrayArray2[n2][0];
            float f = fArrayArray2[n3][1] - fArrayArray2[n2][1];
            float paint = (float)Math.sqrt(i2 * i2 + f * f);
            fArray3[i] = f / paint;
            fArray4[i] = -i2 / paint;
        }
        float[][] fArrayArray3 = new float[][]{{-1.02f, 0.25f, 10.1f, 0.68f, 0.0f, -1.0f},new float[]{-0.5f, -0.3f, 10.25f, 0.72f, 1.1f, -1.0f},new float[]{0.02f, 0.3f, 10.8f, 0.74f, 2.3f, 0.0f},new float[]{0.54f, -0.28f, 9.7f, 0.72f, 0.6f, 1.0f},new float[]{1.03f, 0.22f, 9.55f, 0.66f, 1.7f, 1.0f},new float[]{-0.72f, 0.62f, 9.4f, 0.62f, 2.9f, -1.0f},new float[]{0.74f, 0.6f, 9.5f, 0.62f, 0.3f, 1.0f},new float[]{-0.05f, -0.62f, 10.6f, 0.64f, 2.0f, 0.0f}};
        ArrayList<Paint> arrayList = new ArrayList<Paint>();
        float[][] object = fArrayArray3;
        int fArrayArray4 = object.length;
        while (var11_19 < fArrayArray4) {
            float f;
            int n2;
            float[] fArray5 = object[var11_19];
            int n3 = Math.min((int)Math.floor(fArray5[2]), n - 1);
            float f2 = fArray5[2] - (float)n3;
            float[] fArray6 = new float[(n3 + 2) * 4];
            for (n2 = 0; n2 <= n3; ++n2) {
                float f3 = fArray[n2];
                f = Aoi.R(6.5f, 8.6f, n2);
                float f4 = 0.14f * (float)Math.sin((float)n2 * 0.9f + fArray5[4]) * Aoi.R(1.0f, 4.0f, n2) * (1.0f - f);
                float f5 = fArray5[0] * f3 + f4;
                float f6 = fArray5[1] * f3 * 0.75f * (1.0f - 0.6f * f);
                fArray6[n2 * 4] = f5 + (fArray5[5] * 1.15f * f3 + fArray5[0] * 0.2f * f3 - f5) * f;
                fArray6[n2 * 4 + 1] = fArrayArray2[n2][0] + fArray3[n2] * f6;
                fArray6[n2 * 4 + 2] = fArrayArray2[n2][1] + fArray4[n2] * f6;
                fArray6[n2 * 4 + 3] = fArray5[3] * 1.08f * fArray2[n2];
            }
            n2 = (n3 + 1) * 4;
            int n4 = Math.min(n3 + 1, n - 1);
            f = Math.max(f2, 0.45f);
            fArray6[n2] = fArray6[n3 * 4] * 1.12f + fArray5[5] * 0.2f;
            fArray6[n2 + 1] = fArrayArray2[n3][0] + (fArrayArray2[n4][0] - fArrayArray2[n3][0]) * f - 1.1f;
            fArray6[n2 + 2] = fArray6[n3 * 4 + 2] + (fArrayArray2[n4][1] - fArrayArray2[n3][1]) * f - 0.1f;
            fArray6[n2 + 3] = 0.04f;
            Aoi.d(arrayList, fArray6, 6, 1.6f, true);
            ++var11_19;
        }
        float[] fArray7 = new float[36];
        for (fArrayArray4 = 0; fArrayArray4 < 9; ++fArrayArray4) {
            fArray7[fArrayArray4 * 4 + 1] = fArrayArray2[fArrayArray4][0];
            fArray7[fArrayArray4 * 4 + 2] = fArrayArray2[fArrayArray4][1];
            fArray7[fArrayArray4 * 4 + 3] = 0.64f * fArray2[fArrayArray4];
        }
        Aoi.d(arrayList, fArray7, 5, 1.4f, false);
        for (float[] fArray8 : fArrayArray = new float[][]{{0.05f, 30.55f, -2.15f, 0.1f, 31.45f, -2.6f, 0.15f, 32.05f, -3.35f, 0.1f, 31.85f, -4.15f},new float[]{0.3f, 30.5f, -2.1f, 0.72f, 31.25f, -2.7f, 0.98f, 31.72f, -3.45f, 1.08f, 31.42f, -4.05f},new float[]{-0.35f, 30.5f, -2.1f, -0.76f, 31.2f, -2.75f, -1.02f, 31.62f, -3.4f, -1.12f, 31.32f, -4.0f}}) {
            arrayList.add(Paints.u(fArray8[0], fArray8[1], fArray8[2], 0.36f, fArray8[3], fArray8[4], fArray8[5], 0.44f, fArray8[6], fArray8[7], fArray8[8], 0.3f, fArray8[9], fArray8[10], fArray8[11], 0.04f).d(1.8f, 0.0f, 26.0f, 0.5f));
        }
        Fill sx2 = Fill.s(Aoi::lmbd$ponytail$0);
        Paint paint = Paints.j(arrayList.toArray(new Paint[0])).l(sx2);
        Paint paint2 = Aoi.p(0.0f, 30.38f, -2.05f, 0.0f, 0.55f, -0.83f, 0.52f, 0.38f).g(0.05f, 0.3f).n(-13703425);
        scaleMustBetween.d("ponytail", RightArm.HEAD).X(0.0f, Aoi.g(30.35f), -2.3779998f).v(Aoi.j(Paints.j(paint, paint2))).Z(1.0f).E(1.3f).W(-15327158, 0.12f).i(0.4f).G(0.4f).K(FollowAmount.O().o(3.0f, 0.0f, 2.5f, 0.3f).F(7.0f, 0.0f, 5.0f, 2.0f).m(22.0f).V(0.3f).u(RightArm.BODY, 0.6f).R(18.0f, 4.0f).e(36.0f, 4.2f).N(1.5f).H(70.0f));
    }

    private static void d(List<Paint> list, float[] fArray, int n, float f, boolean bl) {
        int n2 = fArray.length / 4;
        if (n2 < n + 3) {
            list.add(Paints.u(fArray).d(f, 0.0f, 26.0f, 0.5f));
            return;
        } else {
            list.add(Paints.u(Arrays.copyOfRange(fArray, 0, (n + 2) * 4)).d(f, 0.0f, 26.0f, 0.5f));
            Paint paint = Paints.u(Arrays.copyOfRange(fArray, (n - 1) * 4, n2 * 4)).d(f, 0.0f, 26.0f, 0.5f);
            if (bl) {
                int n3 = (n2 - 3) * 4;
                int n4 = (n2 - 2) * 4;
                int n5 = (n2 - 1) * 4;
                MinX minX = MinX.i(2.4f, 0.02f, fArray[n3], fArray[n3 + 1], fArray[n4], fArray[n4 + 1], fArray[n5], fArray[n5 + 1]);
                paint = paint.T(Paints.j(Paints.I(fArray[n4 + 1]), Paints.D(minX, 8.0f, 0.0f)));
            }
            list.add(paint);
        }
    }

    private static Paint Q(ScaleMustBetween scaleMustBetween, Height2 height2) {
        Fill sx2 = Fill.s(Aoi::lmbd$body$0).K(1.0f).T(0.1f);
        Paint paint = Paints.Q(0.0f, 23.2f, -0.22f, 0.66f, 0.0f, 26.3f, 0.0f, 0.58f).l(sx2);
        Paint paint2 = Paints.O(1.0f, Paints.P(0.0f, 21.15f, 0.0f, 2.25f, 2.05f, 1.45f), Paints.P(0.0f, 18.7f, 0.0f, 1.78f, 1.75f, 1.22f), Paints.P(0.0f, 16.6f, -0.05f, 2.0f, 1.5f, 1.4f), Paints.b(-2.2f, 22.3f, -0.18f, 0.0f, 22.62f, -0.18f, 0.88f), Paints.b(0.0f, 22.62f, -0.18f, 2.2f, 22.3f, -0.18f, 0.88f)).E(0.6f, Paints.P(0.82f, 20.85f, 0.55f, 0.88f, 0.82f, 0.85f).s());
        paint2.l(Fill.V(-2498584, 17.2f, -525828, 19.4f).K(0.4f));
        Paint paint3 = Paints.Q(0.0f, 23.0f, -0.2f, 0.9f, 0.0f, 25.3f, -0.12f, 0.74f).w(0.06f, Paints.d(25.1f)).n(-15263457);
        Paint paint4 = Paints.P(0.0f, 14.95f, -0.05f, 1.95f, 1.2f, 1.35f).n(-15263457);
        Paint paint5 = Paints.O(1.1f, Paints.P(0.0f, 21.0f, -0.1f, 2.7f, 2.4f, 1.98f), Paints.b(-2.62f, 22.25f, -0.22f, 0.0f, 22.6f, -0.22f, 1.04f), Paints.b(0.0f, 22.6f, -0.22f, 2.62f, 22.25f, -0.22f, 1.04f), Aoi.l(-0.1f, 18.3f, 20.3f, 2.45f, 1.97f, 2.55f, 1.97f)).l(Fill.s(Aoi::lmbd$body$1).K(0.3f).T(0.18f));
        Paint paint6 = Aoi.l(-0.1f, 17.42f, 18.45f, 2.45f, 2.03f, 2.47f, 2.02f).n(-14210250);
        Paint paint7 = Paints.p(0.0f, 23.52f, -0.28f, 1.28f, 0.38f).L(16.0f, 0.0f, 0.0f, 0.0f, 23.52f, -0.28f).n(-14210250);
        Paint paint8 = Paints.j(paint5, paint6, paint7);
        Paint paint9 = Paints.N(0.06f, paint8, Aoi.c(0.0f));
        float f = Aoi.s(paint8, -1.85f, 18.95f, 6.0f);
        float f2 = 16.95f;
        float f3 = Aoi.S(Aoi.h(f2));
        float f4 = 1.85f + 1.6f * f3 + 0.22f;
        float f5 = 1.5f + 1.4f * f3 + 0.22f;
        Paint paint10 = Aoi.H(-0.05f, f2, 0.42f, f4, f5, 0.26f).n(-15263457);
        float f6 = -0.05f + f5 * (float)Math.sqrt(1.0f - 0.3025f / (f4 * f4)) + 0.26f;
        Paint paint11 = Paints.k(0.55f, f2, f6 + 0.05f, 0.46f, 0.36f, 0.14f, 0.1f).n(-13749702);
        OutlineColorSet outlineColorSet = scaleMustBetween.T(RightArm.BODY).X(0.0f, 24.4f, 0.0f).v(Paints.j(paint, paint3, paint2, paint4, paint9, paint10, paint11)).Z(1.0f).W(-15065558, 0.13f).G(0.3f);
        Height2 height22 = Aoi.V();
        Height2 height23 = Aoi.E();
        outlineColorSet.D(Aoi.w()).D(DecalSizeMust.J(height22, 2.02f, 19.6f, -2.0f, 0.6f, 4.0f).O(1.4f, 1.4f)).D(DecalSizeMust.J(height22, -2.02f, 19.6f, -2.0f, 0.6f, 4.0f).O(1.4f, 1.4f)).D(DecalSizeMust.f(height2, 0.0f, 18.12f, -0.1f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 360.0f, 0.3f).H(1.95f, 3.2f)).D(DecalSizeMust.Z(Aoi.f(), -1.85f, 18.95f, f, 0.95f, 0.36f).O(0.5f, 0.5f).u(70.0f)).D(DecalSizeMust.Z(Aoi.f().b(), 1.85f, 18.95f, f, 0.95f, 0.36f).O(0.5f, 0.5f).u(70.0f)).D(DecalSizeMust.Z(height23, 0.0f, 17.62f, 1.9f, 2.0f, 0.28f).O(1.2f, 0.4f).u(70.0f)).D(DecalSizeMust.f(height23, 0.0f, 24.8f, -0.14f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 240.0f, 0.26f).H(0.4f, 1.05f)).D(DecalSizeMust.Z(Aoi.tu(), 0.55f, f2, f6 + 0.19f, 0.92f, 0.72f).O(0.4f, 0.3f).u(60.0f));
        Paint paint12 = Paints.j(Paints.u(0.98f, 16.7f, f6 + 0.02f, 0.28f, 1.02f, 15.8f, f6 + 0.26f, 0.28f, 1.05f, 14.9f, f6 + 0.45f, 0.27f, 1.07f, 14.3f, f6 + 0.55f, 0.26f).F(2.2f, 0.0f, 0.0f, 1.0f).n(-15263457), Paints.k(1.07f, 14.15f, f6 + 0.56f, 0.28f, 0.2f, 0.13f, 0.08f).n(-3550757));
        scaleMustBetween.d("strap", RightArm.BODY).X(0.98f, 16.7f, f6).v(paint12).E(0.7f).Z(0.3f).J().K(FollowAmount.t().F(8.0f, 0.0f, 5.0f, 2.0f).m(6.0f).e(40.0f, 5.0f).N(1.2f));
        return paint8;
    }

    private static float v(float f) {
        return 0.85f + 0.65f * (24.9f - f) / 10.1f;
    }

    private static Paint c(float f) {
        return Paints.D(MinX.c(-0.85f - f, 24.9f, 0.85f + f, 24.9f, 1.5f + f, 14.8f, -1.5f - f, 14.8f), 2.6f, 0.0f).B(0.0f, 0.0f, 3.15f);
    }

    private static Paint U(Paint paint, float f, float f2, float f3) {
        float[] fArray = new float[24];
        for (int i = 0; i < 8; ++i) {
            float f4 = f2 + (f3 - f2) * (float)i / 7.0f;
            float f5 = Aoi.v(f4);
            fArray[i * 3] = f * (f5 + 0.09f);
            fArray[i * 3 + 1] = f4;
            fArray[i * 3 + 2] = Aoi.s(paint, f * (f5 + 0.1f), f4, 6.0f) - 0.06f;
        }
        return Paints.X(0.13f, 0.13f, fArray);
    }

    private static void I(ScaleMustBetween scaleMustBetween, Height2 height2) {
        Fill sx2 = Fill.s(Aoi::lmbd$skirt$0).K(0.15f);
        DecalSizeMust decalSizeMust = DecalSizeMust.f(height2, 0.0f, 11.77f, -0.05f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 360.0f, 0.27f).H(2.4f, 4.6f);
        float f = (float)Math.toRadians(30.0);
        float f2 = (float)Math.toRadians(14.0);
        String[] stringArray = new String[3];
        String[] stringArray2 = b;
        stringArray[0] = "skirt_f";
        stringArray[1] = "skirt_s";
        stringArray[2] = "skirt_b";
        String[] stringArray3 = stringArray;
        float[] fArray = new float[]{-30.0f, -90.0f, -150.0f};
        float[] fArray2 = new float[]{0.5f, 0.42f, 0.5f};
        float[] fArray3 = new float[]{16.0f, 13.0f, 15.0f};
        for (int i = 0; i < 3; ++i) {
            float f3 = (float)Math.toRadians(fArray[i]);
            float f4 = 1.8f * (float)Math.sin(f3);
            float f5 = -0.05f + 1.45f * (float)Math.cos(f3);
            FollowAmount followAmount = FollowAmount.J(RightArm.RIGHT_LEG).D(RightArm.RIGHT_LEG, fArray2[i], fArray3[i]).m(i == 0 ? 0.0f : 3.0f);
            OutlineColorSet outlineColorSet = scaleMustBetween.d(stringArray3[i] + "_r", RightArm.BODY).X(f4, 16.9f, f5).v(Aoi.P2(f3, f, f2).l(sx2)).K(followAmount).Z(0.32f).E(1.0f).G(0.3f).J().D(decalSizeMust);
            scaleMustBetween.d(stringArray3[i] + "_l", RightArm.BODY).F(outlineColorSet);
        }
    }

    private static float h(float f) {
        return Aoi.e((17.3f - f) / 6.049999f);
    }

    private static float S(float f) {
        return f * (1.25f - 0.25f * f);
    }

    private static float i(float f, float f2, float f3, float f4, float f5) {
        float f6;
        float f7 = Aoi.h(f5);
        float f8 = Aoi.S(f7);
        float f9 = 1.5f + 1.4f * f8;
        float f10 = (float)Math.sqrt(f9 * f9 * f * f + (f6 = 1.85f + 1.6f * f8) * f6 * f2 * f2);
        float f11 = f10 < 1.0E-5f ? f6 : f6 * f9 * f3 / f10;
        return f11 + (0.05f + 0.24f * f7) * Aoi.a(f4 * 18.0f / ((float)Math.PI * 2));
    }

    private static Paint P2(float f, float f2, float f3) {
        float f4 = 0.0f;
        float f5 = 0.0f;
        float f6 = -0.05f;
        float f7 = -0.05f;
        for (int i = 0; i <= 16; ++i) {
            float f8 = f - f2 - f3 + (f2 + f3) * 2.0f * (float)i / 16.0f;
            for (float f9 : new float[]{1.4f, 4.05f}) {
                f4 = Math.min(f4, f9 * (float)Math.sin(f8));
                f5 = Math.max(f5, f9 * (float)Math.sin(f8));
                f6 = Math.min(f6, -0.05f + f9 * (float)Math.cos(f8));
                f7 = Math.max(f7, -0.05f + f9 * (float)Math.cos(f8));
            }
        }
        return Paints.A((arg_0, arg_1, arg_2) -> Aoi.lmbd$skirtPanel$0(f, f2, f3, arg_0, arg_1, arg_2), f4 - 0.2f, 11.05f, f6 - 0.2f, f5 + 0.2f, 17.5f, f7 + 0.2f);
    }

    private static void b(ScaleMustBetween scaleMustBetween, Height2 height2) {
        float f = -3.68f;
        float f2 = 18.4f;
        float f3 = -0.1f;
        float f4 = f + 3.3f;
        float f5 = f2 - 21.8f;
        float f6 = f3 + 0.12f;
        float f7 = (float)Math.sqrt(f4 * f4 + f5 * f5 + f6 * f6);
        Paint paint = Paints.O(0.45f, Paints.e(-3.22f, 22.2f, -0.15f, 1.1f), Paints.Q(-3.3f, 21.8f, -0.12f, 1.07f, f, f2, f3, 0.96f));
        Paint paint2 = paint.T(Paints.E(f, f2, f3, f4 /= f7, f5 /= f7, f6 /= f7).n(-14210250)).l(Fill.s(Aoi::lmbd$arms$0).K(0.3f));
        float f8 = f - f4 * 0.05f;
        float f9 = f2 - f5 * 0.05f;
        float f10 = f3 - f6 * 0.05f;
        Paint paint3 = Aoi.p(f8, f9, f10, f4, f5, f6, 0.86f, 0.34f).n(-14210250);
        Fill sx2 = Fill.Z(-9274).K(1.0f).T(0.25f);
        Paint paint4 = Paints.Q(f, f2 - 0.1f, f3 + 0.05f, 0.55f, -3.92f, 14.66f, 0.15f, 0.39f).l(sx2).L(-13.0f, 0.0f, 0.0f, f, f2, f3);
        float f11 = -1.5f;
        float f12 = (float)Math.cos(Math.toRadians(f11));
        float f13 = (float)Math.sin(Math.toRadians(f11));
        float f14 = -3.3f + (f8 + 3.3f) * f12 - (f9 - 22.4f) * f13;
        float f15 = 22.4f + (f8 + 3.3f) * f13 + (f9 - 22.4f) * f12;
        float f16 = f4 * f12 - f5 * f13;
        float f17 = f4 * f13 + f5 * f12;
        f8 = f14;
        f9 = f15;
        f4 = f16;
        f5 = f17;
        float[] fArray = Aoi.u(-4.15f, 12.75f, 0.45f, f, f2, f3);
        float f18 = -3.3f + (fArray[0] + 3.3f) * f12 - (fArray[1] - 22.4f) * f13;
        float f19 = 22.4f + (fArray[0] + 3.3f) * f13 + (fArray[1] - 22.4f) * f12;
        OutlineColorSet outlineColorSet = scaleMustBetween.T(RightArm.RIGHT_ARM).X(-3.3f, 22.4f, -0.1f).Y(f18, f19, fArray[2]).v(Paints.j(paint2, paint3, paint4).L(0.0f, 0.0f, f11, -3.3f, 22.4f, -0.1f)).W(-12959918, 0.12f).G(0.3f).L(0.8f).g(-3.78f, 18.41f, -0.1f, 0.55f);
        OutlineColorSet outlineColorSet2 = scaleMustBetween.T(RightArm.LEFT_ARM).F(outlineColorSet);
        outlineColorSet.D(DecalSizeMust.f(height2, f8, f9, f10, -f4, -f5, -f6, -1.0f, 0.0f, 0.3f, 250.0f, 0.4f).H(0.95f, 1.6f));
        outlineColorSet2.D(DecalSizeMust.f(height2, -f8, f9, f10, f4, -f5, -f6, 1.0f, 0.0f, 0.3f, 250.0f, 0.4f).H(0.95f, 1.6f));
        outlineColorSet2.D(DecalSizeMust.C(Aoi.t(), 4.45f, 20.3f, -0.1f, 1.05f, 1.05f).O(0.8f, 0.8f).u(65.0f));
        outlineColorSet.D(DecalSizeMust.h(Aoi.t1(), -4.5f, 20.2f, -0.1f, 0.62f, 1.75f).O(0.8f, 0.8f).u(65.0f));
        OutlineColorSet outlineColorSet3 = scaleMustBetween.d("hand_r", RightArm.RIGHT_ARM).v(Aoi.q().L(-13.0f, 0.0f, 0.0f, f, f2, f3).L(0.0f, 0.0f, f11, -3.3f, 22.4f, -0.1f)).E(0.45f).Z(0.5f).W(-6657438, 0.1f).i(1.0f).G(0.25f);
        scaleMustBetween.d("hand_l", RightArm.LEFT_ARM).F(outlineColorSet3);
        OutlineColorSet outlineColorSet4 = scaleMustBetween.d("wrist_r", RightArm.RIGHT_ARM).v(Paints.P(-3.97f, 14.12f, 0.16f, 0.31f, 0.5f, 0.37f).n(-9274).L(-13.0f, 0.0f, 0.0f, f, f2, f3).L(0.0f, 0.0f, f11, -3.3f, 22.4f, -0.1f)).E(0.6f).Z(1.4f).W(-6657438, 0.1f).i(1.0f).G(0.25f);
        scaleMustBetween.d("wrist_l", RightArm.LEFT_ARM).F(outlineColorSet4);
    }

    private static float[] u(float f, float f2, float f3, float f4, float f5, float f6) {
        double d = Math.toRadians(-13.0);
        float f7 = (float)Math.cos(d);
        float f8 = (float)Math.sin(d);
        float f9 = f2 - f5;
        float f10 = f3 - f6;
        return new float[]{f, f5 + f9 * f7 - f10 * f8, f6 + f9 * f8 + f10 * f7};
    }

    private static Paint q() {
        Paint paint = Paints.P(-4.0f, 13.2f, 0.14f, 0.3f, 0.68f, 0.54f);
        FlatMode flatMode = Paints.X(0.2f, 0.15f, -3.86f, 13.35f, 0.6f, -3.72f, 12.9f, 0.92f, -3.62f, 12.5f, 0.98f);
        Paint paint2 = Paints.j(Paints.X(0.17f, 0.15f, -3.98f, 12.72f, 0.56f, -3.92f, 12.1f, 0.72f, -3.8f, 11.66f, 0.8f), Paints.X(0.17f, 0.15f, -4.0f, 12.74f, 0.24f, -3.88f, 12.12f, 0.28f, -3.66f, 11.8f, 0.3f), Paints.X(0.165f, 0.145f, -4.0f, 12.72f, -0.08f, -3.88f, 12.18f, -0.08f, -3.66f, 11.88f, -0.06f), Paints.X(0.15f, 0.13f, -3.99f, 12.66f, -0.36f, -3.88f, 12.3f, -0.36f, -3.7f, 12.06f, -0.33f));
        return Paints.j(Paints.O(0.12f, paint, flatMode, paint2).n(-9274), Paints.Z(-3.95f, 14.22f, 0.18f, -3.93f, 14.9f, 0.15f, 0.5f, 0.1f).n(-13703425));
    }

    private static void N(ScaleMustBetween scaleMustBetween) {
        Paint paint = Paints.Q(-1.24f, 14.1f, 0.0f, 1.3f, -1.1f, 8.3f, 0.1f, 0.84f);
        Paint paint2 = Paints.e(-1.07f, 7.68f, 0.18f, 0.75f);
        Paint paint3 = Paints.e(-1.06f, 7.8f, 0.5f, 0.52f);
        Paint paint4 = Paints.Q(-1.07f, 7.3f, 0.06f, 0.78f, -1.12f, 2.6f, -0.1f, 0.5f);
        Paint paint5 = Paints.P(-1.12f, 5.8f, -0.2f, 0.72f, 1.5f, 0.74f);
        Paint paint6 = Paints.e(-1.1f, 14.4f, -0.05f, 1.32f);
        Fill sx2 = Fill.s(Aoi::lmbd$legs$0);
        Paint paint7 = Paints.j(Paints.O(0.5f, paint, paint2, paint4, paint5).E(0.3f, paint3), paint6).l(sx2);
        Paint paint8 = Paints.j(Paints.O(0.5f, paint4, paint5).C(0.1f).T(Paints.d(6.95f)), Paints.p(-1.075f, 6.9f, 0.0f, 0.86f, 0.15f)).n(-14012606);
        OutlineColorSet outlineColorSet = scaleMustBetween.T(RightArm.RIGHT_LEG).X(-1.2f, 14.3f, 0.0f).v(paint7).W(-11914188, 0.12f).i(0.7f).G(0.3f).q(0.55f, 30.0f).g(-1.07f, 7.68f, 0.18f, 0.75f);
        scaleMustBetween.T(RightArm.LEFT_LEG).F(outlineColorSet);
        OutlineColorSet outlineColorSet2 = scaleMustBetween.d("sock_r", RightArm.RIGHT_LEG).v(paint8).E(0.7f).Z(0.45f).W(-15460836, 0.12f);
        OutlineColorSet outlineColorSet3 = scaleMustBetween.d("sock_l", RightArm.LEFT_LEG).F(outlineColorSet2);
        Height2 height2 = Aoi.Y();
        outlineColorSet2.D(DecalSizeMust.f(height2, -1.1f, 6.42f, -0.05f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 360.0f, 0.3f).H(0.3f, 1.4f));
        outlineColorSet3.D(DecalSizeMust.f(height2, 1.1f, 6.42f, -0.05f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 360.0f, 0.3f).H(0.3f, 1.4f));
        float f = -1.14f;
        float f2 = -7.0f;
        OutlineColorSet outlineColorSet4 = scaleMustBetween.d("shoe_r", RightArm.RIGHT_LEG).v(Aoi.T(f).L(0.0f, f2, 0.0f, f, 1.0f, 0.3f)).E(0.8f).Z(0.55f).W(-12959664, 0.12f);
        OutlineColorSet outlineColorSet5 = scaleMustBetween.d("shoe_l", RightArm.LEFT_LEG).F(outlineColorSet4);
        Height2 height22 = Aoi.K();
        double d = Math.toRadians(f2);
        float f3 = (float)Math.cos(d);
        float f4 = (float)Math.sin(d);
        float f5 = f + 0.65f * f4;
        float f6 = 0.3f + 0.65f * f3;
        outlineColorSet4.D(DecalSizeMust.p(height22, f5, 2.1f, f6, 0.87f * f4, 0.5f, 0.87f * f3, -0.5f * f4, 0.87f, -0.5f * f3, 0.8f, 1.28f).O(0.7f, 0.7f).u(75.0f));
        outlineColorSet5.D(DecalSizeMust.p(height22, -f5, 2.1f, f6, -0.87f * f4, 0.5f, 0.87f * f3, 0.5f * f4, 0.87f, -0.5f * f3, 0.8f, 1.28f).O(0.7f, 0.7f).u(75.0f));
    }

    private static Paint T(float f) {
        Paint paint = Paints.O(0.35f, Paints.k(f, 0.42f, 0.4f, 0.88f, 0.42f, 1.45f, 0.36f), Paints.P(f, 0.44f, 1.62f, 0.88f, 0.44f, 0.95f), Paints.P(f, 0.44f, -0.85f, 0.84f, 0.44f, 0.7f));
        Paint paint2 = Paints.P(f, 1.12f, 1.35f, 0.76f, 0.58f, 1.1f);
        Paint paint3 = Paints.b(f, 1.3f, 0.85f, f, 2.05f, 0.1f, 0.7f);
        Paint paint4 = Paints.P(f, 1.45f, -0.62f, 0.8f, 0.82f, 0.82f);
        Paint paint5 = Paints.j(Paints.Q(f, 1.8f, -0.3f, 0.84f, f, 3.5f, -0.17f, 0.74f).T(Paints.d(3.2f)), Paints.p(f, 3.18f, -0.19f, 0.66f, 0.15f));
        Paint paint6 = Paints.P(f, 3.05f, 0.42f, 0.46f, 0.72f, 0.3f);
        Paint paint7 = Paints.O(0.4f, paint2, paint3, paint4, paint5).E(0.15f, paint6);
        Fill sx2 = Fill.s(Aoi::lmbd$shoe$0);
        return Paints.j(paint, paint7).l(sx2);
    }

    private static void Ii(ScaleMustBetween scaleMustBetween, Paint paint) {
        ArrayList<Paint> arrayList = new ArrayList<Paint>();
        Height2 height2 = Aoi.L();
        OutlineColorSet outlineColorSet = scaleMustBetween.d("gear", RightArm.BODY);
        for (int i = -1; i <= 1; i += 2) {
            float f = (float)i * 0.35f;
            float f2 = 0.45f;
            float f3 = 0.82f;
            float f4 = (float)Math.sqrt(f * f + f2 * f2 + f3 * f3);
            f /= f4;
            f2 /= f4;
            f3 /= f4;
            float f5 = (float)i * 1.55f;
            float f6 = 23.5f;
            float f7 = 1.12f;
            float f8 = f;
            float f9 = f2;
            float f10 = f3;
            float f11 = f5;
            float f12 = f6;
            float f13 = f7;
            Paint paint2 = Paints.Z(f5 - f * 0.1f, f6 - f2 * 0.1f, f7 - f3 * 0.1f, f5 + f * 0.16f, f6 + f2 * 0.16f, f7 + f3 * 0.16f, 0.86f, 0.12f).l(Fill.s((arg_0, arg_1, arg_2) -> Aoi.lmbd$gear$0(f11, f8, f12, f9, f13, f10, arg_0, arg_1, arg_2)));
            Paint paint3 = Paints.Z(f5 - f * 0.36f, f6 - f2 * 0.36f, f7 - f3 * 0.36f, f5 - f * 0.08f, f6 - f2 * 0.08f, f7 - f3 * 0.08f, 0.78f, 0.1f).n(-14210250);
            Paint paint4 = Paints.b(f5 - f * 0.1f - (float)i * 0.1f, f6 + 0.8f, f7 - f3 * 0.1f - 0.2f, (float)i * 1.3f, 24.4f, 0.5f, 0.2f).n(-14210250);
            arrayList.add(Paints.j(paint2, paint3, paint4));
            outlineColorSet.D(DecalSizeMust.p(height2, f5 + f * 0.17f, f6 + f2 * 0.17f, f7 + f3 * 0.17f, f, f2, f3, 0.0f, 1.0f, 0.0f, 1.3f, 1.3f).O(0.4f, 0.4f).u(70.0f).R());
        }
        arrayList.add(Paints.u(1.3f, 24.4f, 0.5f, 0.24f, 1.22f, 24.85f, -0.35f, 0.26f, 0.72f, 25.02f, -1.2f, 0.26f, 0.0f, 25.08f, -1.42f, 0.26f, -0.72f, 25.02f, -1.2f, 0.26f, -1.22f, 24.85f, -0.35f, 0.26f, -1.3f, 24.4f, 0.5f, 0.24f).d(1.8f, 0.0f, 24.9f, -0.2f).n(-14210250));
        arrayList.add(Paints.j(Aoi.U(paint, 1.0f, 23.3f, 17.5f), Aoi.U(paint, -1.0f, 23.3f, 17.5f)).n(-13703425));
        outlineColorSet.v(Paints.j(arrayList.toArray(new Paint[0]))).E(0.7f).Z(0.7f).W(-15065820, 0.1f).i(0.7f).G(0.15f);
        float[] fArray = new float[]{1.75f, 22.65f, 1.85f, 21.8f, 1.92f, 20.9f, 1.95f, 20.15f};
        float[] fArray2 = new float[12];
        for (int i = 0; i < 4; ++i) {
            fArray2[i * 3] = fArray[i * 2];
            fArray2[i * 3 + 1] = fArray[i * 2 + 1];
            fArray2[i * 3 + 2] = i == 0 ? 1.3f : Aoi.s(paint, fArray[i * 2], fArray[i * 2 + 1], 6.0f) + 0.16f;
        }
        float f = fArray2[11];
        Paint paint5 = Paints.j(Paints.X(0.13f, 0.13f, fArray2).n(-7563613), Paints.b(1.95f, 20.2f, f, 1.96f, 19.65f, f + 0.02f, 0.19f).n(-12959662), Paints.b(1.96f, 19.6f, f + 0.02f, 1.96f, 19.3f, f + 0.03f, 0.12f).n(-3550757));
        scaleMustBetween.d("cable", RightArm.BODY).X(1.75f, 22.65f, 1.3f).v(paint5).E(0.5f).Z(0.25f).J().K(FollowAmount.t().o(1.0f, 0.0f, 1.5f, 0.35f).F(4.0f, 0.0f, 5.0f, 2.0f).m(-2.0f).V(0.4f).e(45.0f, 5.0f).N(1.1f));
    }

    private static float A(float f) {
        return (f + 2.25f) * 80.0f;
    }

    private static float r(float f) {
        return (28.6f - f) * 80.0f;
    }

    private static DecalSizeMust Z(List<float[]> list) {
        int n;
        Height2 height2 = new Height2(Math.round(360.0f), Math.round(201.60004f));
        for (float[] fArray : list) {
            MinX minX = null;
            int n2 = 0;
            while (n2 + 7 < fArray.length) {
                if (!(fArray[n2 + 1] > 29.2f) || !(fArray[n2 + 5] > 29.2f)) {
                    MinX minX2 = MinX.D(Aoi.A(fArray[n2]), Aoi.r(fArray[n2 + 1] - 0.22f), fArray[n2 + 3] * 80.0f * 1.7f, Aoi.A(fArray[n2 + 4]), Aoi.r(fArray[n2 + 5] - 0.22f), Math.max(2.0f, fArray[n2 + 7] * 80.0f * 1.5f));
                    minX = minX == null ? minX2 : minX.j(minX2);
                }
                n2 += 4;
            }
            if (minX == null) continue;
            height2.a(minX, 2028380826, 3.0f);
        }
        for (n = -1; n <= 1; n += 2) {
            Aoi.rF(height2, n);
        }
        height2.a(MinX.D(Aoi.A(0.06f), Aoi.r(26.8f), 4.0f, Aoi.A(-0.02f), Aoi.r(26.64f), 2.0f), -1714123650, 0.0f);
        height2.a(MinX.h(Aoi.A(-0.22f), Aoi.r(26.2f), Aoi.A(0.0f), Aoi.r(26.1f), Aoi.A(0.2f), Aoi.r(26.23f), 3.4f, 2.2f), -7455931, 0.0f);
        for (n = -1; n <= 1; n += 2) {
            height2.a(MinX.f(Aoi.A((float)n * 1.25f), Aoi.r(26.42f), 32.0f, 11.0f), 1442807955, 10.0f);
        }
        float f = 27.34f;
        return DecalSizeMust.Z(height2, 0.0f, Aoi.g(f), 3.132f, 5.22f, 2.9232004f).O(3.0159998f, 0.8f).u(72.0f).V(1.0f).B(0.3f);
    }

    private static void rF(Height2 height2, int n) {
        float f = Aoi.A((float)n * 0.98f);
        float f2 = Aoi.r(27.2f);
        float f3 = f - (float)n * 2.0f;
        float f4 = f2 + 4.0f;
        float f5 = f - (float)n * 46.0f;
        float f6 = f + (float)n * 47.0f;
        float f7 = f2 - 40.0f;
        float f8 = f2 - 50.0f;
        float f9 = f - (float)n * 2.0f;
        float f10 = f2 - 49.0f;
        MinX minX = MinX.c(f5 - (float)n * 30.0f, f7 + 2.0f, f5, f7, f9, f10, f6, f8, f6 + (float)n * 30.0f, f8, f6 + (float)n * 30.0f, f2 + 90.0f, f5 - (float)n * 30.0f, f2 + 90.0f);
        MinX minX2 = MinX.f(f, f2 - 2.0f, 47.0f, 53.0f).m(minX);
        height2.h(minX2, GradientNeedsLeast.linear(f, f2 - 50.0f, f, f2 + 50.0f, -2498062, -1, -1));
        MinX minX3 = MinX.f(f3, f4, 32.0f, 43.0f);
        MinX minX4 = minX3.m(minX2);
        height2.h(minX4, GradientNeedsLeast.linear(f3, f4 - 43.0f, f3, f4 + 43.0f, -16050107, -15449954, -14711060, -10687489));
        height2.a(MinX.f(f3, f4 + 25.0f, 22.0f, 14.0f).m(minX4), -1871645953, 6.0f);
        height2.a(MinX.f(f3, f4 + 3.0f, 12.0f, 19.0f), -16315098, 0.0f);
        height2.a(minX3.l(4.5f).m(minX2), -536210893, 0.0f);
        height2.a(MinX.f(f, f2 - 44.0f, 62.0f, 20.0f).m(minX2), 1714438256, 8.0f);
        height2.a(MinX.J(f3 - 12.0f, f4 - 15.0f, 6.5f, 10.5f, 3.5f).s(-14.0f, f3 - 12.0f, f4 - 15.0f), -1, 0.0f);
        height2.a(MinX.J(f3 - 2.0f, f4 - 20.0f, 2.2f, 5.0f, 1.5f).s(-14.0f, f3 - 2.0f, f4 - 20.0f), -855638017, 0.0f);
        height2.a(MinX.R(f3 + 13.0f, f4 + 21.0f, 4.2f), -570425345, 0.0f);
        int n2 = -15724002;
        height2.a(MinX.i(5.0f, 9.0f, f5, f7 + 1.0f, f9, f10 - 1.0f, f6, f8), n2, 0.0f);
        height2.a(MinX.D(f6 - (float)n * 6.0f, f8 + 1.0f, 7.5f, f6 + (float)n * 12.0f, f8 - 7.0f, 1.5f), n2, 0.0f);
        height2.a(MinX.h(f + (float)n * 6.0f, f2 + 51.0f, f + (float)n * 32.0f, f2 + 46.0f, f6 - (float)n * 3.0f, f2 + 22.0f, 1.2f, 3.0f), -1072030672, 0.0f);
        height2.a(MinX.h(f - (float)n * 40.0f, f2 - 72.0f, f + (float)n * 2.0f, f2 - 80.0f, f + (float)n * 42.0f, f2 - 72.0f, 3.6f, 2.0f), -14011280, 0.0f);
    }

    private static Height2 M() {
        Height2 height2 = new Height2(64, 10);
        height2.H(MinX.J(32.0f, 3.3f, 40.0f, 2.8f, 0.0f), -13703425);
        height2.H(MinX.J(32.0f, 8.2f, 40.0f, 0.8f, 0.0f), -1);
        return height2;
    }

    private static Height2 E() {
        Height2 height2 = new Height2(64, 8);
        height2.H(MinX.J(32.0f, 4.0f, 40.0f, 3.0f, 0.0f), -13703425);
        return height2;
    }

    private static Height2 Y() {
        Height2 height2 = new Height2(64, 12);
        height2.H(MinX.J(32.0f, 2.5f, 40.0f, 2.0f, 0.0f), -13703425);
        height2.H(MinX.J(32.0f, 9.5f, 40.0f, 2.0f, 0.0f), -13703425);
        return height2;
    }

    private static Height2 L() {
        Height2 height2 = new Height2(96, 96);
        height2.H(MinX.R(48.0f, 48.0f, 33.0f).l(5.0f), -13703425);
        return height2;
    }

    private static DecalSizeMust w() {
        Height2 height2 = new Height2(152, 120);
        height2.H(MinX.R(76.0f, 60.0f, 42.0f).l(10.0f), -13703425);
        float[] fArray = new float[]{16.0f, 30.0f, 50.0f, 72.0f, 94.0f, 72.0f, 50.0f, 30.0f, 16.0f};
        for (int i = 0; i < fArray.length; ++i) {
            height2.H(MinX.J(76.0f + (float)(i - 4) * 15.0f, 60.0f, 4.6f, fArray[i] * 0.5f, 3.0f), -14932394);
        }
        return DecalSizeMust.Z(height2, 0.0f, 20.3f, 1.9f, 1.7f, 1.34f).O(0.75f, 0.45f).u(62.0f);
    }

    private static Height2 V() {
        Height2 height2 = new Height2(12, 80);
        height2.H(MinX.J(6.0f, 40.0f, 3.1f, 39.0f, 0.9f), -13703425);
        height2.H(MinX.J(0.9f, 40.0f, 0.7f, 39.0f, 0.35f), -1512206);
        height2.H(MinX.J(11.1f, 40.0f, 0.7f, 39.0f, 0.35f), -1512206);
        return height2;
    }

    private static Height2 tu() {
        Height2 height2 = new Height2(64, 48);
        height2.h(MinX.J(32.0f, 24.0f, 31.0f, 23.0f, 7.0f), GradientNeedsLeast.linear(0.0f, 2.0f, 0.0f, 46.0f, -1643535, -7563613));
        height2.H(MinX.J(32.0f, 24.0f, 21.0f, 12.0f, 4.0f), -14276045);
        height2.H(MinX.J(32.0f, 24.0f, 14.0f, 3.5f, 1.5f), -13703425);
        height2.H(MinX.J(8.5f, 24.0f, 2.0f, 9.0f, 1.0f), -14276045);
        height2.H(MinX.J(55.5f, 24.0f, 2.0f, 9.0f, 1.0f), -14276045);
        return height2;
    }

    private static Height2 f() {
        Height2 height2 = new Height2(64, 24);
        height2.H(MinX.J(32.0f, 12.0f, 28.0f, 3.4f, 3.0f), -15460837);
        height2.H(MinX.J(32.0f, 12.0f, 25.0f, 0.8f, 0.4f), -13703425);
        height2.H(MinX.J(54.0f, 15.5f, 2.2f, 5.0f, 1.2f), -3550757);
        return height2;
    }

    private static Height2 t1() {
        float f = 0.43f;
        Height2 height2 = new Height2(41, 117);
        MinX minX = MinX.K(MinX.B(26.0f, 86.0f, 48.0f, 14.0f, 13.0f), MinX.B(48.0f, 14.0f, 70.0f, 86.0f, 13.0f), MinX.B(36.0f, 62.0f, 60.0f, 62.0f, 10.0f));
        MinX minX2 = MinX.f(48.0f, 136.0f, 22.0f, 34.0f).l(13.0f);
        MinX minX3 = MinX.K(MinX.B(48.0f, 190.0f, 48.0f, 258.0f, 13.0f), MinX.B(32.0f, 190.0f, 64.0f, 190.0f, 9.0f), MinX.B(32.0f, 258.0f, 64.0f, 258.0f, 9.0f));
        MinX minX4 = MinX.K(minX, minX2, minX3);
        Aoi.n(height2, f, minX4.Y(3.0f, 3.0f), -13703425, 0.0f);
        Aoi.n(height2, f, minX4, -14932394, 0.0f);
        return height2;
    }

    private static Height2 t() {
        float f = 0.625f;
        Height2 height2 = new Height2(80, 80);
        Aoi.n(height2, f, MinX.R(64.0f, 64.0f, 60.0f), -14210250, 0.0f);
        Aoi.n(height2, f, MinX.R(64.0f, 64.0f, 52.0f).l(6.0f), -13703425, 0.0f);
        Aoi.n(height2, f, MinX.q(64.0f, 70.0f, 30.0f, 180.0f, 360.0f, 8.0f), -591621, 0.0f);
        Aoi.n(height2, f, MinX.J(36.0f, 78.0f, 8.0f, 14.0f, 5.0f), -591621, 0.0f);
        Aoi.n(height2, f, MinX.J(92.0f, 78.0f, 8.0f, 14.0f, 5.0f), -591621, 0.0f);
        return height2;
    }

    private static Height2 K() {
        float f = 0.5f;
        Height2 height2 = new Height2(48, 80);
        for (int i = 0; i < 4; ++i) {
            float f2 = 30.0f + (float)i * 32.0f;
            Aoi.n(height2, f, MinX.B(20.0f, f2, 76.0f, f2 + 16.0f, 9.0f), -13703425, 0.0f);
            Aoi.n(height2, f, MinX.B(76.0f, f2, 20.0f, f2 + 16.0f, 9.0f), -13703425, 0.0f);
            Aoi.n(height2, f, MinX.R(14.0f, f2, 5.0f), -3550757, 0.0f);
            Aoi.n(height2, f, MinX.R(82.0f, f2, 5.0f), -3550757, 0.0f);
        }
        return height2;
    }

    private static void n(Height2 height2, float f, MinX minX, int n, float f2) {
        height2.a(minX.U(f, 0.0f, 0.0f), n, f2 * f);
    }

    private static float s(Paint paint, float f, float f2, float f3) {
        float f4;
        float f5 = f3;
        for (int i = 0; i < 400 && f5 > -8.0f; f5 -= Math.max(0.005f, f4 * 0.7f), ++i) {
            f4 = paint.Q(f, f2, f5);
            if (!(f4 < 0.003f)) continue;
            return f5;
        }
        return f5;
    }

    private static Paint p(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
        float f9 = (float)Math.sqrt(f4 * f4 + f5 * f5 + f6 * f6);
        float f10 = f4 / f9;
        float f11 = f5 / f9;
        float f12 = f6 / f9;
        Paint paint = Paints.p(f, f2, f3, f7, f8);
        if (f10 * f10 + f12 * f12 < 1.0E-8f) {
            return paint;
        }
        float f13 = (float)Math.toDegrees(Math.acos(Math.max(-1.0f, Math.min(1.0f, f11))));
        return paint.b(f12, 0.0f, -f10, f13, f, f2, f3);
    }

    private static Paint l(float f, float f2, float f3, float f4, float f5, float f6, float f7) {
        float f8 = Math.max(f4, f6);
        float f9 = Math.max(f5, f7);
        return Paints.A((arg_0, arg_1, arg_2) -> Aoi.lmbd$oval$0(f2, f3, f, f4, f6, f5, f7, arg_0, arg_1, arg_2), -f8, f2, f - f9, f8, f3, f + f9);
    }

    private static Paint H(float f, float f2, float f3, float f4, float f5, float f6) {
        float f7 = Math.min(f6, f3) * 0.5f;
        return Paints.A((arg_0, arg_1, arg_2) -> Aoi.lmbd$ovalRing$0(f, f4, f5, f6, f7, f2, f3, arg_0, arg_1, arg_2), -f4 - f6, f2 - f3, f - f5 - f6, f4 + f6, f2 + f3, f + f5 + f6);
    }

    private static float W(float f, float f2, float f3, float f4) {
        float f5 = (float)Math.sqrt(f * f / (f3 * f3) + f2 * f2 / (f4 * f4));
        float f6 = (float)Math.sqrt(f * f / (f3 * f3 * f3 * f3) + f2 * f2 / (f4 * f4 * f4 * f4));
        return f6 < 1.0E-6f ? -Math.min(f3, f4) : f5 * (f5 - 1.0f) / f6;
    }

    private static float a(float f) {
        float f2 = Aoi.m(f);
        return f2 * (1.5f - 0.5f * f2 * f2);
    }

    private static float m(float f) {
        float f2 = f - (float)Math.floor(f);
        return 4.0f * Math.min(f2, 1.0f - f2) - 1.0f;
    }

    private static float e(float f) {
        if (f < 0.0f) {
            return 0.0f;
        }
        float f2 = Math.min(f, 1.0f);
        return f2;
    }

    private static float R(float f, float f2, float f3) {
        float f4 = Aoi.e((f3 - f) / (f2 - f));
        return f4 * f4 * (3.0f - 2.0f * f4);
    }

    private static float lmbd$ovalRing$0(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10) {
        float f11 = Math.abs(Aoi.W(f8, f10 - f, f2, f3)) - f4 + f5;
        float f12 = Math.abs(f9 - f6) - f7 + f5;
        float f13 = Math.max(f11, 0.0f);
        float f14 = Math.max(f12, 0.0f);
        return ((float)Math.sqrt(f13 * f13 + f14 * f14) + Math.min(Math.max(f11, f12), 0.0f) - f5) * 0.95f;
    }

    private static float lmbd$oval$0(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10) {
        float f11 = Aoi.e((f9 - f) / (f2 - f));
        float f12 = Aoi.W(f8, f10 - f3, f4 + (f5 - f4) * f11, f6 + (f7 - f6) * f11);
        return Math.max(f12 * 0.95f, Math.max(f - f9, f9 - f2));
    }

    private static int lmbd$gear$0(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9) {
        float f10 = (f7 - f) * f2 + (f8 - f3) * f4 + (f9 - f5) * f6;
        return Colors.S(-14210250, -723206, Aoi.R(0.03f, 0.1f, f10));
    }

    private static int lmbd$shoe$0(float f, float f2, float f3) {
        return f2 < 0.9f ? Colors.S(-14012872, -920586, Aoi.R(0.05f, 0.24f, f2)) : Colors.S(-591621, -14210250, Aoi.R(2.8f, 3.05f, f2));
    }

    private static int lmbd$legs$0(float f, float f2, float f3) {
        return Colors.S(Colors.S(-14012606, -9274, Aoi.R(6.7f, 6.95f, f2)), -15263457, Aoi.R(12.2f, 12.4f, f2));
    }

    private static int lmbd$arms$0(float f, float f2, float f3) {
        return Colors.S(-1446155, -3945254, Aoi.R(-3.2f, -2.6f, f) * 0.7f);
    }

    private static float lmbd$skirtPanel$0(float f, float f2, float f3, float f4, float f5, float f6) {
        float f7 = f6 - -0.05f;
        float f8 = (float)Math.atan2(f4, f7);
        float f9 = f8 - f;
        if ((double)f9 > Math.PI) {
            f9 -= (float)Math.PI * 2;
        }
        if ((double)f9 < -Math.PI) {
            f9 += (float)Math.PI * 2;
        }
        float f10 = Math.abs(f9) - f2;
        float f11 = (float)Math.sqrt(f4 * f4 + f7 * f7);
        float f12 = Aoi.i(f4, f7, f11, f8, f5) - 0.32f * Aoi.R(0.0f, 0.05f, f10);
        float f13 = Math.abs(f11 - f12) - 0.42f;
        float f14 = Math.max(f5 - 17.3f, 11.25f - f5);
        float f15 = Math.max(-1.2f, Math.min(1.2f, f10 - f3));
        float f16 = f11 * f15 * (1.0f - f15 * f15 / 6.0f);
        return Math.max(f13, Math.max(f14, f16)) * 0.8f;
    }

    private static int lmbd$skirt$0(float f, float f2, float f3) {
        float f4 = (float)Math.atan2(f, f3 - -0.05f);
        float f5 = Aoi.a(f4 * 18.0f / ((float)Math.PI * 2));
        return Colors.S(-14472632, -12892555, 0.4f + 0.6f * (0.5f + 0.5f * f5));
    }

    private static int lmbd$body$1(float f, float f2, float f3) {
        return Colors.S(-12959662, -1446155, Aoi.R(21.72f, 21.78f, f2));
    }

    private static int lmbd$body$0(float f, float f2, float f3) {
        return Colors.S(-9274, -1331558, Aoi.R(24.9f, 25.5f, f2));
    }

    private static int lmbd$ponytail$0(float f, float f2, float f3) {
        int n = Colors.S(-14140794, -12948262, Aoi.R(27.5f, 21.5f, f2));
        n = Colors.S(n, -13246209, Aoi.R(21.5f, 16.0f, f2));
        float f4 = Aoi.R(30.9f, 31.5f, f2) * Aoi.R(-2.4f, -3.2f, f3);
        return Colors.S(n, -7363350, f4 * 0.5f);
    }

    private static int lmbd$fringe$0(float f, float f2, float f3, float f4) {
        return Colors.p(Colors.S(Colors.S(-14140794, -12756032, Aoi.R(29.6f, 30.6f, f3) * 0.5f), -12948262, Aoi.R(28.9f, 27.4f, f3) * 0.85f), f);
    }

    private static int lmbd$capPaint$0(float f, float f2, float f3) {
        return Colors.S(Colors.S(-15063975, -14140794, Aoi.R(26.2f, 28.4f, f2)), -12756032, Aoi.R(29.4f, 31.2f, f2) * 0.8f);
    }

    private static int lmbd$hair$1(float f, float f2, float f3) {
        return Colors.S(-13646610, -13246209, Aoi.R(27.0f, 25.0f, f2));
    }

    private static int lmbd$hair$0(float f, float f2, float f3) {
        return Colors.S(Colors.S(-14140794, -12948262, Aoi.R(28.2f, 25.8f, f2)), -13246209, Aoi.R(26.2f, 24.4f, f2));
    }

    private static float lmbd$headShape$0(Paint paint, Paint paint2, float f, float f2, float f3) {
        float f4 = f2 > 28.8f ? paint.Q(f, f2, f3) : paint2.Q(f, f2, f3);
        return Math.max(f4, Math.max(-1.0f - f3, f2 - 30.1f));
    }

    static {
        b = new String[]{"sock_l", "lock_r", "lock_l", "hair", "shoe_r", "sock_r", "fringe", "skirt_s", "ponytail", "hand_r", "hand_l", "skirt_f", "_l", "aoi", "Aoi", "gear", "wrist_l", "_r", "skirt_b", "strap", "cable", "shoe_l", "wrist_r"};
        MAIN_LOCKS = new float[][]{{0.95f, -1.55f, 29.85f, -2.0f, 29.5f, -2.3f, 28.45f, -2.24f, 27.65f, -2.0f, 27.42f},new float[]{0.95f, -1.15f, 29.95f, -1.38f, 29.5f, -1.6f, 28.6f, -1.55f, 28.12f, -1.3f, 27.93f},new float[]{0.85f, -0.64f, 29.95f, -0.45f, 29.4f, -0.08f, 28.25f, 0.16f, 27.4f, 0.04f, 27.02f},new float[]{1.0f, -0.08f, 30.0f, 0.35f, 29.6f, 0.9f, 28.7f, 1.2f, 28.22f, 0.98f, 28.0f},new float[]{1.05f, 0.56f, 30.0f, 1.15f, 29.7f, 1.8f, 28.75f, 2.08f, 27.8f, 1.85f, 27.45f}};
        ACCENT_LOCKS = new float[][]{{0.55f, -0.95f, 29.85f, -1.0f, 29.3f, -0.9f, 28.5f, -0.76f, 28.3f},new float[]{0.55f, -0.22f, 29.85f, 0.14f, 29.35f, 0.52f, 28.72f, 0.44f, 28.55f},new float[]{0.5f, 0.5f, 29.85f, 1.02f, 29.4f, 1.5f, 28.5f, 1.44f, 28.2f}};
    }
}
