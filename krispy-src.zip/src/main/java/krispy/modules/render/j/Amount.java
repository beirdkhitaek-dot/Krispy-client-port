package krispy.modules.render.j;

import krispy.modules.render.j.OcclusionWeight;
import krispy.modules.render.j.Fill;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Amount
extends Fill {
    private final Fill base;
    private final float amount;

    Amount(Fill sx2, float f) {
        this.base = sx2;
        this.amount = f;
    }

    @Override
    public void B(float f, float f2, float f3, OcclusionWeight occlusionWeight) {
        this.base.B(f, f2, f3, occlusionWeight);
        occlusionWeight.glow = this.amount;
    }
}
