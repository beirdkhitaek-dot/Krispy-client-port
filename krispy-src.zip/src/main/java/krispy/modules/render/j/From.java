package krispy.modules.render.j;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
class From {
    public final int from;
    public final int to;
    public final float[] edge;

    public From(int from, int to, float[] edge) {
        this.from = from;
        this.to = to;
        this.edge = edge;
    }

    public int from() {
        return this.from;
    }

    public int to() {
        return this.to;
    }

    public float[] edge() {
        return this.edge;
    }
}
