package krispy.modules.render.j;

import krispy.modules.render.j.MinX;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Count
extends MinX {
    private final float[] seg;
    private final int count;
    private static final String a = Count.a(107, Count.a("(\u0003z\u0019\fMu=\u0006}QMW04\u0007o\u0002X\u0003d/\r.\u0001CJ~,\u0011.\u0016EUu6Bo\u0002\f[<!B~\u0010EQc"));

    Count(float[] fArray, float f, float f2, boolean bl) {
        float f3;
        float f4;
        float f5;
        int n;
        if (fArray.length < 4 || fArray.length % 2 != 0) throw new IllegalArgumentException(a);
        int n2 = fArray.length / 2;
        float[] fArray2 = new float[n2];
        for (int i = 1; i < n2; ++i) {
            float f6 = fArray[i * 2] - fArray[i * 2 - 2];
            float f7 = fArray[i * 2 + 1] - fArray[i * 2 - 1];
            fArray2[i] = fArray2[i - 1] + (float)Math.sqrt(f6 * f6 + f7 * f7);
        }
        float f8 = Math.max(1.0E-6f, fArray2[n2 - 1]);
        float[] fArray3 = new float[n2];
        for (n = 0; n < n2; ++n) {
            fArray3[n] = f + (f2 - f) * fArray2[n] / f8;
        }
        if (!bl && n2 != 2) {
            this.count = n2 - 2;
            this.seg = new float[this.count * 12];
            for (n = 1; n <= this.count; ++n) {
                f5 = n == 1 ? fArray[0] : (fArray[n * 2 - 2] + fArray[n * 2]) * 0.5f;
                f4 = n == 1 ? fArray[1] : (fArray[n * 2 - 1] + fArray[n * 2 + 1]) * 0.5f;
                f3 = n == 1 ? fArray3[0] : (fArray3[n - 1] + fArray3[n]) * 0.5f;
                float f9 = n == this.count ? fArray[n * 2 + 2] : (fArray[n * 2] + fArray[n * 2 + 2]) * 0.5f;
                float f10 = n == this.count ? fArray[n * 2 + 3] : (fArray[n * 2 + 1] + fArray[n * 2 + 3]) * 0.5f;
                float f11 = n == this.count ? fArray3[n + 1] : (fArray3[n] + fArray3[n + 1]) * 0.5f;
                Count.C(this.seg, (n - 1) * 12, f5, f4, f3, fArray[n * 2], fArray[n * 2 + 1], fArray3[n], f9, f10, f11);
            }
        } else {
            this.count = 1;
            this.seg = new float[12];
            if (n2 == 2) {
                Count.C(this.seg, 0, fArray[0], fArray[1], fArray3[0], (fArray[0] + fArray[2]) * 0.5f, (fArray[1] + fArray[3]) * 0.5f, (fArray3[0] + fArray3[1]) * 0.5f, fArray[2], fArray[3], fArray3[1]);
            } else {
                Count.C(this.seg, 0, fArray[0], fArray[1], f, fArray[2], fArray[3], (f + f2) * 0.5f, fArray[4], fArray[5], f2);
            }
        }
        float f12 = 100000.0f;
        f5 = 100000.0f;
        f4 = -100000.0f;
        f3 = -100000.0f;
        for (int i = 0; i < this.count; ++i) {
            int n3 = i * 12;
            f12 = Math.min(f12, this.seg[n3 + 8]);
            f5 = Math.min(f5, this.seg[n3 + 9]);
            f4 = Math.max(f4, this.seg[n3 + 10]);
            f3 = Math.max(f3, this.seg[n3 + 11]);
        }
        this.L(f12, f5, f4, f3);
    }

    private static void C(float[] fArray, int n, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9) {
        fArray[n] = f;
        fArray[n + 1] = f2;
        fArray[n + 2] = f4;
        fArray[n + 3] = f5;
        fArray[n + 4] = f7;
        fArray[n + 5] = f8;
        fArray[n + 6] = f3;
        fArray[n + 7] = f9;
        float f10 = Math.max(f3, Math.max(f6, f9));
        fArray[n + 8] = Math.min(f, Math.min(f4, f7)) - f10;
        fArray[n + 9] = Math.min(f2, Math.min(f5, f8)) - f10;
        fArray[n + 10] = Math.max(f, Math.max(f4, f7)) + f10;
        fArray[n + 11] = Math.max(f2, Math.max(f5, f8)) + f10;
    }

    @Override
    public float d(float f, float f2) {
        float f3 = Float.MAX_VALUE;
        for (int i = 0; i < this.count; ++i) {
            float f4;
            float f5 = 0.0f;
            float f6 = 0.0f;
            int n = i * 12;
            float f7 = f < this.seg[n + 8] ? this.seg[n + 8] - f : (f6 = f > this.seg[n + 10] ? f - this.seg[n + 10] : 0.0f);
            float f8 = f2 < this.seg[n + 9] ? this.seg[n + 9] - f2 : (f5 = f2 > this.seg[n + 11] ? f2 - this.seg[n + 11] : 0.0f);
            if (f3 > 0.0f && f3 != Float.MAX_VALUE && f6 * f6 + f5 * f5 >= f3 * f3 || !((f4 = this.G(n, f, f2)) < f3)) continue;
            f3 = f4;
        }
        return f3;
    }

    private float G(int n, float f, float f2) {
        float f3;
        float f4;
        float f5;
        float f6;
        float f7 = this.seg[n];
        float f8 = this.seg[n + 1];
        float f9 = this.seg[n + 2];
        float f10 = this.seg[n + 3];
        float f11 = this.seg[n + 4];
        float f12 = this.seg[n + 5];
        float f13 = f9 - f7;
        float f14 = f10 - f8;
        float f15 = f7 - 2.0f * f9 + f11;
        float f16 = f8 - 2.0f * f10 + f12;
        float f17 = f15 * f15 + f16 * f16;
        float f18 = f7 - f;
        float f19 = f8 - f2;
        float f20 = f11 - f7;
        float f21 = f12 - f8;
        float f22 = f20 * f20 + f21 * f21;
        if (f17 < 1.0E-5f * Math.max(f22, 1.0E-6f)) {
            f6 = f22 > 1.0E-12f ? Count.N(((f - f7) * f20 + (f2 - f8) * f21) / f22) : 0.0f;
        } else {
            f5 = 1.0f / f17;
            f4 = f5 * (f13 * f15 + f14 * f16);
            f3 = f5 * (2.0f * (f13 * f13 + f14 * f14) + f18 * f15 + f19 * f16) / 3.0f;
            float f23 = f5 * (f18 * f13 + f19 * f14);
            float f24 = f4 * (2.0f * f4 * f4 - 3.0f * f3) + f23;
            float f25 = f3 - f4 * f4;
            float f26 = f25 * f25 * f25;
            float f27 = f24 * f24 + 4.0f * f26;
            if (f27 >= 0.0f) {
                f27 = (float)Math.sqrt(f27);
                f6 = Count.N((float)(Math.cbrt((f27 - f24) * 0.5f) + Math.cbrt((-f27 - f24) * 0.5f)) - f4);
            } else {
                float f28 = (float)Math.sqrt(-f25);
                float f29 = f24 / (f25 * f28 * 2.0f);
                f29 = f29 < -1.0f ? -1.0f : Math.min(f29, 1.0f);
                float f30 = (float)Math.acos(f29) / 3.0f;
                float f31 = (float)Math.cos(f30);
                float f32 = (float)Math.sin(f30) * 1.7320508f;
                float f33 = Count.N((f31 + f31) * f28 - f4);
                float f34 = Count.N((-f32 - f31) * f28 - f4);
                float f35 = f18 + (2.0f * f13 + f15 * f33) * f33;
                float f36 = f19 + (2.0f * f14 + f16 * f33) * f33;
                float f37 = f18 + (2.0f * f13 + f15 * f34) * f34;
                float f38 = f19 + (2.0f * f14 + f16 * f34) * f34;
                f6 = f35 * f35 + f36 * f36 <= f37 * f37 + f38 * f38 ? f33 : f34;
            }
        }
        f5 = f18 + (2.0f * f13 + f15 * f6) * f6;
        f4 = f19 + (2.0f * f14 + f16 * f6) * f6;
        f3 = this.seg[n + 6] + (this.seg[n + 7] - this.seg[n + 6]) * f6;
        return (float)Math.sqrt(f5 * f5 + f4 * f4) - f3;
    }

    private static char[] a(String string) {
        char[] cArray = string.toCharArray();
        if (cArray.length >= 2) return cArray;
        cArray = cArray;
        cArray[0] = (char)(cArray[0] ^ 0x7B);
        return cArray;
    }

    private static String a(int n, char[] cArray) {
        char[] cArray2;
        block11: {
            int n2;
            int n3;
            int n4;
            block10: {
                n4 = n;
                cArray2 = cArray;
                n3 = cArray.length;
                n2 = 0;
                if (!true) break block10;
                n3 = n3;
                if (n3 <= n2) break block11;
            }
            do {
                n4 = n4;
                cArray2 = cArray2;
                int n5 = n2;
                cArray2[n5] = (char)(cArray2[n5] ^ (n4 ^ (switch (n2 % 7) {
                    case 0 -> 51;
                    case 1 -> 9;
                    case 2 -> 101;
                    case 3 -> 26;
                    case 4 -> 71;
                    case 5 -> 72;
                    default -> 123;
                })));
                ++n2;
                n3 = n3;
            } while (n3 > n2);
        }
        return new String(cArray2).intern();
    }
}
