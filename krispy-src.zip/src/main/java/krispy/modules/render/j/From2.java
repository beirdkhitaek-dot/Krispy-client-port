package krispy.modules.render.j;

import krispy.modules.render.j.OcclusionWeight;
import krispy.modules.render.j.Fill;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class From2
extends Fill {
    private final int from;
    private final int to;
    private final float ax;
    private final float ay;
    private final float az;
    private final float dx;
    private final float dy;
    private final float dz;
    private final float inv;

    From2(int n, float f, float f2, float f3, int n2, float f4, float f5, float f6) {
        this.from = n;
        this.to = n2;
        this.ax = f;
        this.ay = f2;
        this.az = f3;
        this.dx = f4 - f;
        this.dy = f5 - f2;
        this.dz = f6 - f3;
        float f7 = this.dx * this.dx + this.dy * this.dy + this.dz * this.dz;
        this.inv = f7 < 1.0E-8f ? 0.0f : 1.0f / f7;
    }

    @Override
    public void B(float f, float f2, float f3, OcclusionWeight occlusionWeight) {
        float f4 = ((f - this.ax) * this.dx + (f2 - this.ay) * this.dy + (f3 - this.az) * this.dz) * this.inv;
        f4 = f4 < 0.0f ? 0.0f : Math.min(f4, 1.0f);
        occlusionWeight.i(this.from);
        occlusionWeight.j(this.to, f4);
    }
}
