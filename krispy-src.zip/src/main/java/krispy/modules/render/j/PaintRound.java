package krispy.modules.render.j;

import krispy.modules.render.j.Paints;
import krispy.modules.render.j.Paint;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class PaintRound
extends Paint {
    private final float cx;
    private final float cy;
    private final float cz;
    private final float hx;
    private final float hy;
    private final float hz;
    private final float r;

    PaintRound(float f, float f2, float f3, float f4, float f5, float f6, float f7) {
        this.cx = f;
        this.cy = f2;
        this.cz = f3;
        this.r = Math.max(0.0f, Math.min(f7, Math.min(f4, Math.min(f5, f6))));
        this.hx = f4 - this.r;
        this.hy = f5 - this.r;
        this.hz = f6 - this.r;
        this.c(f - f4, f2 - f5, f3 - f6, f + f4, f2 + f5, f3 + f6);
    }

    @Override
    public float Q(float f, float f2, float f3) {
        float f4 = Math.abs(f - this.cx) - this.hx;
        float f5 = Math.abs(f2 - this.cy) - this.hy;
        float f6 = Math.abs(f3 - this.cz) - this.hz;
        float f7 = Math.max(f4, 0.0f);
        float f8 = Math.max(f5, 0.0f);
        float f9 = Math.max(f6, 0.0f);
        return Paints.f(f7, f8, f9) + Math.min(Math.max(f4, Math.max(f5, f6)), 0.0f) - this.r;
    }
}
