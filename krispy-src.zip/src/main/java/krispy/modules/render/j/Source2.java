package krispy.modules.render.j;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import krispy.modules.render.j.InputStreamProvider;
import krispy.modules.render.j.Name;
import krispy.modules.render.j.ScaleMustBetween;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class Source2
extends Name {
    private final InputStreamProvider source;
    private static final String b = Source2.b(33, Source2.b("@%\u00172\u0017?\u001e\u0005(Ds\u001b:U\b-\u00172\u001b1U\u0012%\u0003"));

    public Source2(String string, String string2, InputStreamProvider g_) {
        super(string, string2);
        this.source = g_;
    }

    public static Source2 E(String string, String string2, String string3) {
        return new Source2(string, string2, () -> Source2.lmbd$builtIn$0(string3));
    }

    InputStream J() throws IOException {
        return this.source.open();
    }

    @Override
    protected void D(ScaleMustBetween scaleMustBetween) {
        throw new UnsupportedOperationException(this.C() + b);
    }

    private static InputStream lmbd$builtIn$0(String string) throws IOException {
        InputStream inputStream = Source2.class.getResourceAsStream(string);
        if (inputStream != null) return inputStream;
        throw new FileNotFoundException(string);
    }

    private static char[] b(String string) {
        char[] cArray = string.toCharArray();
        if (cArray.length >= 2) return cArray;
        cArray = cArray;
        cArray[0] = (char)(cArray[0] ^ 0x54);
        return cArray;
    }

    private static String b(int n, char[] cArray) {
        char[] cArray2;
        block11: {
            int n2;
            int n3;
            int n4;
            block10: {
                n4 = n;
                cArray2 = cArray;
                n3 = cArray.length;
                n2 = 0;
                if (!true) break block10;
                n3 = n3;
                if (n3 <= n2) break block11;
            }
            do {
                n4 = n4;
                cArray2 = cArray2;
                int n5 = n2;
                cArray2[n5] = (char)(cArray2[n5] ^ (n4 ^ (switch (n2 % 7) {
                    case 0 -> 65;
                    case 1 -> 109;
                    case 2 -> 69;
                    case 3 -> 51;
                    case 4 -> 84;
                    case 5 -> 127;
                    default -> 84;
                })));
                ++n2;
                n3 = n3;
            } while (n3 > n2);
        }
        return new String(cArray2).intern();
    }
}
