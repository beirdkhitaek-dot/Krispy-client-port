package krispy.modules.render.j;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Depth {
    final float[][] pool = new float[64][];
    int depth;

    public Depth() {
    }

    float[] r(int n) {
        int n2;
        if ((n2 = this.depth++) >= this.pool.length) {
            return new float[n];
        }
        float[] fArray = this.pool[n2];
        if (fArray != null && fArray.length >= n) return fArray;
        fArray = new float[Math.max(n, 16)];
        this.pool[n2] = fArray;
        return fArray;
    }
}
