package krispy.modules.render.j;

import java.util.function.UnaryOperator;
import krispy.modules.render.j.OcclusionWeight;
import krispy.modules.render.j.Paint;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Child4
extends Paint {
    private final Paint child;
    private final float r;

    Child4(Paint paint, float f) {
        this.child = paint;
        this.r = f;
        this.i(paint, Math.max(0.0f, f));
    }

    @Override
    Paint N(float f, float f2, float f3, float f4, float f5, float f6) {
        Paint paint = this.child.N(f, f2, f3, f4, f5, f6);
        return paint == this.child ? this : new Child4(paint, this.r);
    }

    @Override
    Paint h(UnaryOperator<Paint> unaryOperator) {
        Paint paint = this.child.h(unaryOperator);
        return (Paint)unaryOperator.apply(paint == this.child ? this : new Child4(paint, this.r).t(this));
    }

    @Override
    public float Q(float f, float f2, float f3) {
        return this.child.Q(f, f2, f3) - this.r;
    }

    @Override
    float R(float f, float f2, float f3, OcclusionWeight occlusionWeight) {
        return this.child.I(f, f2, f3, occlusionWeight) - this.r;
    }
}
