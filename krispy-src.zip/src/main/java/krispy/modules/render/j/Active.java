package krispy.modules.render.j;

import java.util.Arrays;
import java.util.stream.IntStream;
import krispy.modules.render.j.Paint;
import krispy.modules.render.j.TriCount;
import krispy.modules.render.j.VertexCount;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class Active {
    private static final int BLOCK = 4;
    private static final int MAX_POINTS = 6000000;
    private static final int[] EDGE_A = new int[]{0, 2, 4, 6, 0, 1, 4, 5, 0, 1, 2, 3};
    private static final int[] EDGE_B = new int[]{1, 3, 5, 7, 2, 3, 6, 7, 4, 5, 6, 7};
    private final Paint shape;
    private final float ox;
    private final float oy;
    private final float oz;
    private final float h;
    private final int nx;
    private final int ny;
    private final int nz;
    private final int bx;
    private final int by;
    private final int bz;
    private final float[] field;
    private final boolean[] active;

    private Active(Paint paint, float f, float f2, float f3, int n, int n2, int n3, float f4) {
        this.shape = paint;
        this.ox = f;
        this.oy = f2;
        this.oz = f3;
        this.nx = n;
        this.ny = n2;
        this.nz = n3;
        this.h = f4;
        this.bx = (n + 4 - 1) / 4;
        this.by = (n2 + 4 - 1) / 4;
        this.bz = (n3 + 4 - 1) / 4;
        this.field = new float[n * n2 * n3];
        Arrays.fill(this.field, Float.NaN);
        this.active = new boolean[this.bx * this.by * this.bz];
    }

    static float B(float f, float f2, float f3, float f4) {
        float f5 = f4;
        while ((long)(f / f5 + 4.0f) * (long)(f2 / f5 + 4.0f) * (long)(f3 / f5 + 4.0f) > 6000000L) {
            f5 *= 1.12f;
        }
        return f5;
    }

    static VertexCount n(Paint paint, float f, float f2, float f3, float f4, float f5, float f6, float f7) {
        float f8 = f7 * 3.0f;
        float f9 = Active.B((f4 += f8) - (f -= f8), (f5 += f8) - (f2 -= f8), (f6 += f8) - (f3 -= f8), f7);
        int n = (int)Math.ceil((f4 - f) / f9) + 1;
        int n2 = (int)Math.ceil((f5 - f2) / f9) + 1;
        int n3 = (int)Math.ceil((f6 - f3) / f9) + 1;
        Active active = new Active(paint, f, f2, f3, n, n2, n3, f9);
        active.M();
        return active.Y();
    }

    private void M() {
        float f = 4.0f * this.h * 0.8660254f * 1.6f + this.h * 1.5f;
        float f2 = this.h * 2.5f;
        IntStream.range(0, this.bz).parallel().forEach(arg_0 -> this.lmbd$evaluate$0(f, f2, arg_0));
    }

    private void A(Paint paint, int n, int n2, int n3) {
        int n4 = Math.min(n + 4, this.nx);
        int n5 = Math.min(n2 + 4, this.ny);
        int n6 = Math.min(n3 + 4, this.nz);
        for (int i = n3; i < n6; ++i) {
            for (int j = n2; j < n5; ++j) {
                for (int k = n; k < n4; ++k) {
                    float f = paint.Q(this.ox + (float)k * this.h, this.oy + (float)j * this.h, this.oz + (float)i * this.h);
                    this.field[(i * this.ny + j) * this.nx + k] = f != f ? 1.0f : f;
                }
            }
        }
    }

    public static int[] EDGE_A() {
        return EDGE_A;
    }

    public static int[] EDGE_B() {
        return EDGE_B;
    }

    public float ox() {
        return this.ox;
    }

    public float oy() {
        return this.oy;
    }

    public float oz() {
        return this.oz;
    }

    public float h() {
        return this.h;
    }

    public int nx() {
        return this.nx;
    }

    public int ny() {
        return this.ny;
    }

    public int nz() {
        return this.nz;
    }

    public float v(int n, int n2, int n3) {
        int n4 = (n3 * this.ny + n2) * this.nx + n;
        float f = this.field[n4];
        if (f == f) return f;
        f = this.shape.Q(this.ox + (float)n * this.h, this.oy + (float)n2 * this.h, this.oz + (float)n3 * this.h);
        if (f != f) {
            f = 1.0f;
        }
        this.field[n4] = f;
        return f;
    }

    private VertexCount Y() {
        TriCount triCount = new TriCount(this);
        for (int i = 0; i < this.bz; ++i) {
            for (int j = 0; j < this.by; ++j) {
                for (int k = 0; k < this.bx; ++k) {
                    if (!this.active[(i * this.by + j) * this.bx + k]) continue;
                    triCount.b(k * 4, j * 4, i * 4);
                }
            }
        }
        return new VertexCount(Arrays.copyOf(triCount.pos, triCount.verts * 3), triCount.verts, Arrays.copyOf(triCount.tris, triCount.triCount * 3), triCount.triCount);
    }

    private void lmbd$evaluate$0(float f, float f2, int n) {
        for (int i = 0; i < this.by; ++i) {
            for (int j = 0; j < this.bx; ++j) {
                float f3 = this.ox + ((float)(j * 4) + 2.0f) * this.h;
                float f4 = this.oy + ((float)(i * 4) + 2.0f) * this.h;
                float f5 = this.oz + ((float)(n * 4) + 2.0f) * this.h;
                float f6 = this.shape.Q(f3, f4, f5);
                if (f6 < -f || f6 > f) continue;
                this.active[(n * this.by + i) * this.bx + j] = true;
                Paint paint = this.shape.N(this.ox + (float)(j * 4) * this.h - f2, this.oy + (float)(i * 4) * this.h - f2, this.oz + (float)(n * 4) * this.h - f2, this.ox + (float)((j + 1) * 4) * this.h + f2, this.oy + (float)((i + 1) * 4) * this.h + f2, this.oz + (float)((n + 1) * 4) * this.h + f2);
                this.A(paint, j * 4, i * 4, n * 4);
            }
        }
    }
}
