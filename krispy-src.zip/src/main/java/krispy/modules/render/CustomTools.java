package krispy.modules.render;

import krispy.fx.TotemUndying;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.CycleSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.Setting;
import krispy.modules.render.Ghost;
import krispy.util.SecureString;

public final class CustomTools
extends Module {
    public static CycleSetting<Ghost> style;
    public static BoolSetting animations;
    public static BoolSetting effects;
    public static NumberSetting strength;
    private static CustomTools instance;
    private static String[] a;

    public CustomTools() {
        super(SecureString.of("Custom Tools"), SecureString.of("Ghost pickaxes with flying skulls, or sculpted 3D tools"), -1, Category.RENDER);
        this.addSettings(new Setting[]{style, animations, effects, strength});
        instance = this;
    }

    public static boolean I() {
        if (instance == null) return false;
        if (!instance.isEnabled()) return false;
        return true;
    }

    public static int F() {
        return style.getModeIndex();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        TotemUndying.moduleOff();
    }

    static {
        String[] stringArray = a = new String[]{"Flying skulls, ghost wisps, sparkles and embers", "A slow sheen across metal heads and living glows", "Effects", "Custom Tools", "How bright the glows and particles are", "Ghost pickaxes with flying skulls, or sculpted 3D tools", "Style", "Ghost: see-through haunted diamond / netherite pickaxe. 3D: sculpted tools (all tools)", "Effect Strength", "Animations"};
        style = new CycleSetting<Ghost>(SecureString.of(stringArray[6]), Ghost.Ghost, Ghost.class).setDescription(SecureString.of(stringArray[7]));
        animations = new BoolSetting(SecureString.of(stringArray[9]), true).setDescription(SecureString.of(stringArray[1]));
        effects = new BoolSetting(SecureString.of(stringArray[2]), true).setDescription(SecureString.of(stringArray[0]));
        strength = new NumberSetting(SecureString.of(stringArray[8]), 0.0, 100.0, 70.0, 1.0).getValue(SecureString.of(stringArray[4]));
    }
}
