package krispy.modules.render;

import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.Setting;

public final class AntiLag
extends Module {
    public static AntiLag instance;
    private final BoolSetting tnt;
    private final BoolSetting tntBlocks;
    private final BoolSetting minecarts;
    private final BoolSetting explosions;
    private final BoolSetting particles;
    private final BoolSetting fireworks;
    private final BoolSetting items;
    private final BoolSetting xp;
    private final BoolSetting decorations;
    private final BoolSetting falling;
    private final BoolSetting projectiles;
    private final BoolSetting mobs;
    private final BoolSetting weather;
    private final BoolSetting clouds;
    private final BoolSetting sounds;
    private volatile int activeMask;
    public AntiLag() {
        super("Anti Lag", "Hides heavy world visuals before rendering. Explosions still affect the world.", -1, Category.RENDER);
        this.tnt = new BoolSetting("Primed TNT", true);
        this.tntBlocks = new BoolSetting("TNT Blocks", true);
        this.minecarts = new BoolSetting("Minecarts", true);
        this.explosions = new BoolSetting("Explosions", true);
        this.particles = new BoolSetting("All Particles", true);
        this.fireworks = new BoolSetting("Fireworks", true);
        this.items = new BoolSetting("Dropped Items", true);
        this.xp = new BoolSetting("XP Orbs", true);
        this.decorations = new BoolSetting("Decoration Entities", true);
        this.falling = new BoolSetting("Falling Blocks", true);
        this.projectiles = new BoolSetting("Projectiles", false);
        this.mobs = new BoolSetting("Mobs", false);
        this.weather = new BoolSetting("Weather", true);
        this.clouds = new BoolSetting("Clouds", true);
        this.sounds = new BoolSetting("Explosion Sounds", true);
        this.addSettings(new Setting[]{this.tnt, this.tntBlocks, this.minecarts, this.explosions, this.particles, this.fireworks, this.items, this.xp, this.decorations, this.falling, this.projectiles, this.mobs, this.weather, this.clouds, this.sounds});
        instance = this;
    }

    public static int O() {
        AntiLag antiLag = instance;
        if (antiLag == null) return 0;
        if (!antiLag.isEnabled()) return 0;
        int n = antiLag.activeMask;
        return n;
    }

    @Override
    public void onEnable() {
        this.H(this.i());
    }

    @Override
    public void onDisable() {
        this.H(0);
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        this.H(this.isEnabled() ? this.i() : 0);
    }

    private int i() {
        return (this.tnt.getValue() ? 1 : 0) | (this.tntBlocks.getValue() ? 2 : 0) | (this.minecarts.getValue() ? 4 : 0) | (this.explosions.getValue() ? 8 : 0) | (this.particles.getValue() ? 16 : 0) | (this.fireworks.getValue() ? 32 : 0) | (this.items.getValue() ? 64 : 0) | (this.xp.getValue() ? 128 : 0) | (this.decorations.getValue() ? 256 : 0) | (this.falling.getValue() ? 512 : 0) | (this.projectiles.getValue() ? 1024 : 0) | (this.mobs.getValue() ? 2048 : 0) | (this.weather.getValue() ? 4096 : 0) | (this.clouds.getValue() ? 8192 : 0) | (this.sounds.getValue() ? 16384 : 0);
    }

    private void H(int n) {
        int n2 = this.activeMask;
        if (n2 == n) {
            return;
        }
        this.activeMask = n;
        if (this.mc == null) {
            return;
        }
        int n3 = n2 ^ n;
        if (this.mc.field_1713 != null && (n3 & n & 0x38) != 0) {
            this.mc.field_1713.method_48015();
        }
        if (this.mc.field_1687 == null || this.mc.field_1769 == null || (n3 & 2) == 0) return;
        this.mc.field_1769.method_3279();
    }

    static {
    }
}
