package krispy.modules.render;

public class Bottom {
    public final int x;
    public final int z;
    public final int bottom;
    public final int top;
    public final int width;
    public final int length;

    public Bottom(int x, int z, int bottom, int top, int width, int length) {
        this.x = x;
        this.z = z;
        this.bottom = bottom;
        this.top = top;
        this.width = width;
        this.length = length;
    }

    public int x() {
        return this.x;
    }

    public int z() {
        return this.z;
    }

    public int bottom() {
        return this.bottom;
    }

    public int top() {
        return this.top;
    }

    public int width() {
        return this.width;
    }

    public int length() {
        return this.length;
    }
}
