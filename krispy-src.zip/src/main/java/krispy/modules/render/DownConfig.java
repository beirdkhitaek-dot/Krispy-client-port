package krispy.modules.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.nio.ByteBuffer;
import java.util.OptionalInt;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10789;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_6367;
import org.lwjgl.BufferUtils;

@Environment(value=EnvType.CLIENT)
final class DownConfig {
    private static RenderPipeline PIPELINE;
    private static final int CONFIG_SIZE = 16;
    private static final float TAPS = 6.0f;
    private final String name;
    private final Supplier<String> passLabel;
    private class_6367 across;
    private class_6367 down;
    private GpuBuffer acrossConfig;
    private GpuBuffer downConfig;
    private GpuBufferSlice acrossSlice;
    private GpuBufferSlice downSlice;
    private ByteBuffer configData;
    private static String[] a;

    DownConfig(String string) {
        this.name = string;
        this.passLabel = () -> DownConfig.lmbd$new$0(string);
    }

    static boolean A(GpuDevice gpuDevice) {
        return gpuDevice.precompilePipeline(PIPELINE).isValid();
    }

    GpuTextureView L(CommandEncoder commandEncoder, GpuTextureView gpuTextureView, int n, int n2, float f) {
        int n3 = Math.max(1, (n + 1) / 2);
        int n4 = Math.max(1, (n2 + 1) / 2);
        if (this.across == null) {
            this.O(n3, n4);
        } else if (this.across.field_1482 != n3 || this.across.field_1481 != n4) {
            this.across.method_1234(n3, n4);
            this.down.method_1234(n3, n4);
        }
        float f2 = Math.max(0.75f, f / 6.0f);
        this.e(commandEncoder, gpuTextureView, this.across, this.acrossSlice, f2 / (float)n, 0.0f);
        this.e(commandEncoder, this.across.method_71639(), this.down, this.downSlice, 0.0f, f2 / (float)n2);
        return this.down.method_71639();
    }

    private void e(CommandEncoder commandEncoder, GpuTextureView gpuTextureView, class_6367 class_63672, GpuBufferSlice gpuBufferSlice, float f, float f2) {
        this.configData.putFloat(0, f);
        this.configData.putFloat(4, f2);
        commandEncoder.writeToBuffer(gpuBufferSlice, this.configData);
        try (RenderPass renderPass = commandEncoder.createRenderPass(this.passLabel, class_63672.method_71639(), OptionalInt.empty());){
            renderPass.setPipeline(PIPELINE);
            renderPass.setUniform("AuraSpread", gpuBufferSlice);
            renderPass.bindTexture("InSampler", gpuTextureView, RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR));
            renderPass.draw(0, 3);
            return;
        }
    }

    private void O(int n, int n2) {
        GpuDevice gpuDevice = RenderSystem.getDevice();
        this.across = new class_6367(this.name + " across", n, n2, false);
        this.down = new class_6367(this.name + " down", n, n2, false);
        this.acrossConfig = gpuDevice.createBuffer(this::lmbd$allocate$0, 136, 16L);
        this.downConfig = gpuDevice.createBuffer(this::lmbd$allocate$1, 136, 16L);
        this.acrossSlice = this.acrossConfig.slice();
        this.downSlice = this.downConfig.slice();
        this.configData = BufferUtils.createByteBuffer(16);
    }

    void I() {
        if (this.across != null) {
            this.across.method_1238();
            this.across = null;
        }
        if (this.down != null) {
            this.down.method_1238();
            this.down = null;
        }
        if (this.acrossConfig != null) {
            this.acrossConfig.close();
            this.acrossConfig = null;
        }
        if (this.downConfig != null) {
            this.downConfig.close();
            this.downConfig = null;
        }
        this.acrossSlice = null;
        this.downSlice = null;
        this.configData = null;
    }

    private String lmbd$allocate$1() {
        return this.name + " down config";
    }

    private String lmbd$allocate$0() {
        return this.name + " across config";
    }

    private static String lmbd$new$0(String string) {
        return string + " spread";
    }

    static {
        String[] stringArray = a = new String[]{"core/aura_spread", " down config", "core/screenquad", "InSampler", "r87f4560b4c09f4", " down", "AuraSpread", "InSampler", " across", "AuraSpread", "pipeline/aura_spread", "r87f4560b4c09f4", " spread", " across config"};
        PIPELINE = RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)stringArray[4], (String)stringArray[10])).withVertexShader(stringArray[2]).withFragmentShader(class_2960.method_60655((String)stringArray[11], (String)stringArray[0])).withSampler(stringArray[3]).withUniform(stringArray[9], class_10789.field_60031).withoutBlend().withDepthWrite(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withVertexFormat(class_290.field_60033, VertexFormat.class_5596.field_27379).build();
    }
}
