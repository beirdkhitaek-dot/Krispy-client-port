package krispy.modules.render;

public enum NotifyMode {
    CHAT,
    TOAST,
    BOTH;

}
