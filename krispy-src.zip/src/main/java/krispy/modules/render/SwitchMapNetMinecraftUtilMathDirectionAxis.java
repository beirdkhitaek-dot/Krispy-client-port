package krispy.modules.render;

import net.minecraft.class_2350;

class SwitchMapNetMinecraftUtilMathDirectionAxis {
    static final int[] $SwitchMap$net$minecraft$util$math$Direction;
    static final int[] $SwitchMap$net$minecraft$util$math$Direction$Axis;

    static {
        $SwitchMap$net$minecraft$util$math$Direction$Axis = new int[class_2350.class_2351.values().length];
        try {
            SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction$Axis[class_2350.class_2351.field_11048.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction$Axis[class_2350.class_2351.field_11052.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction$Axis[class_2350.class_2351.field_11051.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        $SwitchMap$net$minecraft$util$math$Direction = new int[class_2350.values().length];
        try {
            SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction[class_2350.field_11034.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction[class_2350.field_11039.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction[class_2350.field_11036.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction[class_2350.field_11033.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction[class_2350.field_11035.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction[class_2350.field_11043.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
    }
}
