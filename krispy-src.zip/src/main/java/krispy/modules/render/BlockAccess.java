package krispy.modules.render;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1922;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2841;
import net.minecraft.class_3610;

final class BlockAccess
implements class_1922 {
    final long key;
    final int bottom;
    final int height;
    int next;
    final Map<Long, class_2841<class_2680>[]> sections = new HashMap<Long, class_2841<class_2680>[]>();
    private static int Xgu1TSlkNzGvbwYdUKz;

    BlockAccess(long l, int n, int n2) {
        this.key = l;
        this.bottom = n;
        this.height = n2;
    }

    public int method_31607() {
        return this.bottom;
    }

    public int method_31605() {
        return this.height;
    }

    public class_2586 method_8321(class_2338 class_23382) {
        return null;
    }

    public class_2680 method_8320(class_2338 class_23382) {
        if (class_23382.method_10264() < this.bottom || class_23382.method_10264() >= this.bottom + this.height) {
            return class_2246.field_10124.method_9564();
        }
        class_2841<class_2680>[] class_2841Array = this.sections.get(class_1923.method_8331((int)(class_23382.method_10263() >> 4), (int)(class_23382.method_10260() >> 4)));
        if (class_2841Array != null) {
            int n;
            class_2841<class_2680> class_28412;
            return (class_28412 = class_2841Array[n = (class_23382.method_10264() >> 4) - (this.bottom >> 4)]) == null ? class_2246.field_10124.method_9564() : (class_2680)class_28412.method_12321(class_23382.method_10263() & 0xF, class_23382.method_10264() & 0xF, class_23382.method_10260() & 0xF);
        }
        return class_2246.field_10124.method_9564();
    }

    public class_3610 method_8316(class_2338 class_23382) {
        return this.method_8320(class_23382).method_26227();
    }
}
