package krispy.modules.donut;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
class HasUngrown {
    public final int selfHeat;
    public final boolean hasUngrown;

    public HasUngrown(int selfHeat, boolean hasUngrown) {
        this.selfHeat = selfHeat;
        this.hasUngrown = hasUngrown;
    }

    public int selfHeat() {
        return this.selfHeat;
    }

    public boolean hasUngrown() {
        return this.hasUngrown;
    }
}
