package krispy.modules.donut;

import net.minecraft.class_1923;

class Chunk {
    public final class_1923 chunk;
    public final int y;
    public final int x;
    public final int z;

    public Chunk(class_1923 chunk, int y, int x, int z) {
        this.chunk = chunk;
        this.y = y;
        this.x = x;
        this.z = z;
    }

    public class_1923 chunk() {
        return this.chunk;
    }

    public int y() {
        return this.y;
    }

    public int x() {
        return this.x;
    }

    public int z() {
        return this.z;
    }
}
