package krispy.modules.donut;

enum InventoryCheck {
    INVENTORY_CHECK,
    SCANNING,
    MOVING,
    OPENING,
    DROPPING,
    OPENING_SELL,
    DEPOSITING,
    WAITING_CYCLE;

}
