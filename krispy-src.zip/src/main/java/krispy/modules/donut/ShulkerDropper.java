package krispy.modules.donut;

import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.Setting;
import krispy.util.SecureString;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1802;

public final class ShulkerDropper
extends Module {
    private static String[] a;
    private final NumberSetting delay = new NumberSetting(SecureString.of("Delay"), 0.0, 20.0, 1.0, 1.0);
    private final NumberSetting clicksPerBuy = new NumberSetting(SecureString.of("Clicks Per Buy"), 1.0, 32.0, 8.0, 1.0);
    private final NumberSetting reopenDelay = new NumberSetting(SecureString.of("Reopen Delay"), 1.0, 60.0, 20.0, 1.0);
    private final BoolSetting dropBought = new BoolSetting(SecureString.of("Drop Bought"), true);
    private int delayCounter;

    public ShulkerDropper() {
        super(SecureString.of("Shulker Dropper"), SecureString.of("Automatically buys and drops shulker boxes from /shop"), -1, Category.MISC);
        this.addSettings(new Setting[]{this.delay, this.clicksPerBuy, this.reopenDelay, this.dropBought});
    }

    @Override
    public void onEnable() {
        this.delayCounter = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.delayCounter = 0;
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        int n;
        if (this.mc.field_1724 == null || this.mc.field_1761 == null || this.mc.method_1562() == null) {
            return;
        }
        if (this.delayCounter-- > 0) {
            return;
        }
        class_1703 class_17032 = this.mc.field_1724.field_7512;
        if (!(class_17032 instanceof class_1707)) {
            this.mc.method_1562().method_45730("shop");
            this.delayCounter = this.reopenDelay.getIntValue();
            return;
        }
        class_1707 class_17072 = (class_1707)class_17032;
        int n2 = class_17072.method_17388() * 9;
        int n3 = -1;
        for (n = 0; n < n2; ++n) {
            if (!class_17072.method_7611(n).method_7677().method_31574(class_1802.field_8545)) continue;
            n3 = n;
            break;
        }
        if (n3 < 0) {
            this.delayCounter = Math.max(1, this.delay.getIntValue());
            return;
        }
        for (n = 0; n < this.clicksPerBuy.getIntValue(); ++n) {
            this.mc.field_1761.method_2906(class_17072.field_7763, n3, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
        }
        if (this.dropBought.getValue()) {
            for (n = n2; n < class_17072.field_7761.size(); ++n) {
                if (!class_17072.method_7611(n).method_7677().method_31574(class_1802.field_8545)) continue;
                this.mc.field_1761.method_2906(class_17072.field_7763, n, 1, class_1713.field_7795, (class_1657)this.mc.field_1724);
            }
        }
        this.delayCounter = Math.max(1, this.delay.getIntValue());
    }

    static {
        a = new String[]{"Clicks Per Buy", "Automatically buys and drops shulker boxes from /shop", "Drop Bought", "Delay", "Reopen Delay", "Shulker Dropper"};
    }
}
