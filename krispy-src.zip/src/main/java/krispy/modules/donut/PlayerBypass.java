package krispy.modules.donut;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import krispy.client.KrispyClient;
import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.event.WorldRenderEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.Setting;
import krispy.modules.donut.AutoRTP;
import krispy.util.FlaggedSnapshot;
import krispy.util.InverseProjectionScratch;
import krispy.util.OriginX;
import krispy.util.RemainingBeats;
import krispy.util.SecureString;
import krispy.util.Start;
import net.minecraft.class_1923;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5250;

public final class PlayerBypass
extends Module {
    private static final int RENDER_DISTANCE_CHUNKS = 16;
    private final NumberSetting plateSize = new NumberSetting(SecureString.of("Plate Size"), 8.0, 64.0, 15.0, 1.0);
    private final NumberSetting alpha = new NumberSetting(SecureString.of("Alpha"), 10.0, 255.0, 180.0, 1.0);
    private final BoolSetting tracers = new BoolSetting(SecureString.of("Tracers"), false);
    private final BoolSetting kickOnFlag = new BoolSetting(SecureString.of("Kick On Flag"), false).setDescription(SecureString.of("Disconnects once, then automatically turns itself off"));
    private final BoolSetting flagSound = new BoolSetting(SecureString.of("Flag Sound"), true).setDescription(SecureString.of("Plays an alarm that continues on the disconnect and menu screens"));
    private final Set<Long> handledFlags = new HashSet<Long>();
    private final List<krispy.util.Color> renderBoxes = new ArrayList<krispy.util.Color>();
    private final List<Start> renderLines = new ArrayList<Start>();
    private Object trackedWorld;
    private static final String[] a = new String[]{"Flag Sound", "Alpha", "\u00a7e[Player Bypass] \u00a7fFlagged chunk at X: ", " Z: ", " Z: ", "Plate Size", "Disconnects once, then automatically turns itself off", "Highlights suspicious light-signal chunks with a yellow through-wall plate", "Kicked - Player Bypass flagged X: ", "Plays an alarm that continues on the disconnect and menu screens", "Player Bypass", "Tracers", "\nKick On Flag was automatically turned OFF.", "Kick On Flag"};

    public PlayerBypass() {
        super(SecureString.of("Player Bypass"), SecureString.of("Highlights suspicious light-signal chunks with a yellow through-wall plate"), -1, Category.DONUT);
        this.addSettings(new Setting[]{this.plateSize, this.alpha, this.tracers, this.kickOnFlag, this.flagSound});
    }

    @Override
    public void onEnable() {
        this.handledFlags.clear();
        this.trackedWorld = this.mc.field_1687;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.handledFlags.clear();
        this.trackedWorld = null;
        this.renderBoxes.clear();
        this.renderLines.clear();
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) return;
        if (this.trackedWorld != this.mc.field_1687) {
            this.handledFlags.clear();
            this.trackedWorld = this.mc.field_1687;
        }
        int n = this.mc.field_1724.method_24515().method_10263() >> 4;
        int n2 = this.mc.field_1724.method_24515().method_10260() >> 4;
        for (long l : FlaggedSnapshot.getFlaggedChunks()) {
            int n3 = class_1923.method_8325((long)l);
            int n4 = class_1923.method_8332((long)l);
            if (Math.abs(n3 - n) > 16 || Math.abs(n4 - n2) > 16 || !this.handledFlags.add(l)) continue;
            this.J(n3, n4);
        }
    }

    private void J(int n, int n2) {
        int n3 = (n << 4) + 8;
        int n4 = (n2 << 4) + 8;
        if (this.flagSound.getValue()) {
            RemainingBeats.trigger(this.mc);
        }
        String[] stringArray = a;
        this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)("\u00a7e[Player Bypass] \u00a7fFlagged chunk at X: " + n3 + " Z: " + n4)), false);
        AutoRTP autoRTP = (AutoRTP)KrispyClient.INSTANCE.getModuleManager().getModuleByClass(AutoRTP.class);
        if (autoRTP != null) {
            autoRTP.e();
        }
        if (!this.kickOnFlag.getValue() || this.mc.method_1562() == null) return;
        this.kickOnFlag.setValue(false);
        class_5250 class_52502 = class_2561.method_43470((String)("Kicked - Player Bypass flagged X: " + n3 + " Z: " + n4 + "\nKick On Flag was automatically turned OFF."));
        this.mc.method_1562().method_48296().method_10747((class_2561)class_52502);
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent worldRenderEvent) {
        class_4184 class_41842;
        if (this.mc.field_1687 == null || this.mc.field_1724 == null || (class_41842 = InverseProjectionScratch.getCamera()) == null || !class_41842.method_19332()) return;
        int n = this.mc.field_1724.method_24515().method_10263() >> 4;
        int n2 = this.mc.field_1724.method_24515().method_10260() >> 4;
        long l = System.currentTimeMillis();
        double d = 0.72 + Math.sin((double)l / 260.0) * 0.18;
        int n3 = Math.max(1, Math.min(255, (int)((double)this.alpha.getIntValue() * 0.42 * d)));
        Color color = new Color(255, 210, 25, n3);
        Color color2 = new Color(255, 225, 55, this.alpha.getIntValue());
        this.renderBoxes.clear();
        this.renderLines.clear();
        class_243 class_2432 = InverseProjectionScratch.getTracerStart(class_41842);
        double d2 = this.plateSize.getValue() * 0.5;
        java.util.Iterator<Long> iterator2 = FlaggedSnapshot.getFlaggedChunks().iterator();
        while (iterator2.hasNext()) {
            long l2 = iterator2.next();
            int n4 = class_1923.method_8325((long)l2);
            int n5 = class_1923.method_8332((long)l2);
            if (Math.abs(n4 - n) > 16 || Math.abs(n5 - n2) > 16) continue;
            double d3 = (double)(n4 << 4) + 8.0;
            double d4 = (double)(n5 << 4) + 8.0;
            double d5 = 64.25 + Math.sin((double)(l + l2) / 420.0) * 0.12;
            double d6 = d5 + 0.16;
            if (!this.tracers.getValue() && !OriginX.box(d3 - d2, d5, d4 - d2, d3 + d2, d6, d4 + d2)) continue;
            this.renderBoxes.add(new krispy.util.Color(d3 - d2, d5, d4 - d2, d3 + d2, d6, d4 + d2, color));
            InverseProjectionScratch.addBoxOutline(this.renderLines, d3 - d2, d5, d4 - d2, d3 + d2, d6, d4 + d2, color2, 2.5f);
            if (!this.tracers.getValue()) continue;
            this.renderLines.add(new Start(class_2432, new class_243(d3, d6, d4), color2, 2.0f));
        }
        if (this.renderBoxes.isEmpty()) return;
        class_4587 class_45872 = worldRenderEvent.matrixStack;
        class_45872.method_22903();
        InverseProjectionScratch.applyCameraTransform(class_45872, class_41842);
        InverseProjectionScratch.renderFilledBoxes(class_45872, this.renderBoxes);
        InverseProjectionScratch.renderLines(class_45872, this.renderLines);
        class_45872.method_22909();
    }
}
