package krispy.modules.donut;

import krispy.event.MacroTickEvent;
import krispy.module.MacroCategories;
import krispy.module.MacroSubscribe;
import krispy.module.settings.MacroItemSetting;
import krispy.modules.macros.h.Sell;
import krispy.modules.misc.MacroModule;
import krispy.util.KrispyClient;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_746;

@Environment(value=EnvType.CLIENT)
public final class AutoSell
extends MacroModule {
    private static String[] a;
    private static final int INVENTORY_SLOTS = 36;
    private static final int CONFIRM_SLOT = 53;
    private static final long POLL_MS = 350L;
    private static final long COMMAND_COOLDOWN_MS = 4000L;
    private static final long OPEN_TIMEOUT_MS = 10000L;
    private static final long CONFIRM_COOLDOWN_MS = 900L;
    private static final long POST_CONFIRM_MS = 250L;
    private static final int STUCK_CONFIRMS = 3;
    private final MacroItemSetting neverSell = this.addSetting("never-sell", new MacroItemSetting("Never Sell", "minecraft:netherite_sword", "golden_apple", "minecraft:totem_of_undying").itemPicker());
    private int menuId = -1;
    private long openingUntil;
    private long lastCommandAt;
    private long lastConfirmAt;
    private long nextPollAt;
    private boolean confirmPending;
    private String lastFingerprint = "";
    private int sameAfterConfirm;
    private int sold;
    private int confirmedCount;
    private boolean warnedNoOpen;

    public AutoSell() {
        super("auto-sell", "Auto Sell", "Keeps the /sell menu open and keeps selling everything that is not on your Never Sell list.", MacroCategories.DONUT_MACROS);
        this.usesNotifications();
    }

    @Override
    public boolean persistEnabled() {
        return false;
    }

    @Override
    public void onEnable() {
        this.menuId = -1;
        this.openingUntil = 0L;
        this.lastCommandAt = 0L;
        this.lastConfirmAt = 0L;
        this.nextPollAt = 0L;
        this.confirmPending = false;
        this.lastFingerprint = "";
        this.sameAfterConfirm = 0;
        this.sold = 0;
        this.confirmedCount = 0;
        this.warnedNoOpen = false;
    }

    @Override
    public void onDisable() {
        class_746 class_7462 = class_310.method_1551().field_1724;
        if (class_7462 != null && this.D(class_7462)) {
            class_7462.method_7346();
        }
        this.menuId = -1;
        if (this.sold <= 0) return;
        KrispyClient.send((MacroModule)this, KrispyClient.body().text("Sold ").value(this.sold).text(this.sold == 1 ? " item." : " items."));
    }

    @MacroSubscribe
    public void onMacroTick(MacroTickEvent macroTickEvent) {
        class_310 class_3102 = class_310.method_1551();
        class_746 class_7462 = class_3102.field_1724;
        if (class_7462 != null && class_3102.method_1562() != null && class_3102.field_1761 != null && !class_7462.method_29504()) {
            long l = System.currentTimeMillis();
            if (this.menuId < 0 && this.openingUntil > 0L) {
                if (class_7462.field_7512 != class_7462.field_7498 && class_3102.field_1755 instanceof class_465 && AutoSell.Y(class_7462.field_7512) > 53) {
                    this.menuId = class_7462.field_7512.field_7763;
                    this.openingUntil = 0L;
                    this.nextPollAt = l + 150L;
                    this.warnedNoOpen = false;
                    return;
                } else {
                    if (l <= this.openingUntil) return;
                    this.openingUntil = 0L;
                    if (!this.warnedNoOpen) {
                        KrispyClient.send((MacroModule)this, KrispyClient.body().warn("The sell menu did not open").text(", retrying."));
                    }
                    this.warnedNoOpen = true;
                }
                return;
            } else if (!this.D(class_7462)) {
                this.menuId = -1;
                if (class_3102.field_1755 != null || l - this.lastCommandAt < 4000L) return;
                class_7462.field_3944.method_45730("sell");
                this.lastCommandAt = l;
                this.openingUntil = l + 10000L;
                return;
            } else {
                int n;
                if (l < this.nextPollAt) return;
                this.nextPollAt = l + 350L;
                class_1703 class_17032 = class_7462.field_7512;
                if (this.confirmedCount > 0) {
                    n = this.confirmedCount - AutoSell.r(class_17032);
                    this.confirmedCount = 0;
                    if (n > 0) {
                        this.sold += n;
                        KrispyClient.actionBar(this, KrispyClient.body().text("Sold ").value(this.sold).text(" items this session"));
                    }
                }
                if (this.confirmPending) {
                    this.confirmPending = false;
                    if (!AutoSell.T(class_17032) || l - this.lastConfirmAt < 900L || this.sameAfterConfirm >= 3) return;
                    n = AutoSell.r(class_17032);
                    class_3102.field_1761.method_2906(class_17032.field_7763, 53, 0, class_1713.field_7790, (class_1657)class_7462);
                    this.lastConfirmAt = l;
                    this.lastFingerprint = AutoSell.F(class_17032);
                    this.confirmedCount = n;
                    this.nextPollAt = l + 250L;
                    return;
                } else {
                    n = 0;
                    for (class_1735 class_17352 : class_17032.field_7761) {
                        if (!(class_17352.field_7871 instanceof class_1661) || !class_17352.method_7681() || class_17352.method_34266() >= 36 || Sell.e(class_17352.method_7677(), this.neverSell.get())) continue;
                        class_3102.field_1761.method_2906(class_17032.field_7763, class_17352.field_7874, 0, class_1713.field_7794, (class_1657)class_7462);
                        ++n;
                    }
                    String string = AutoSell.F(class_17032);
                    if (n > 0 || !string.equals(this.lastFingerprint)) {
                        this.sameAfterConfirm = 0;
                    } else if (AutoSell.T(class_17032)) {
                        ++this.sameAfterConfirm;
                    }
                    if (n <= 0 && !AutoSell.T(class_17032)) return;
                    this.confirmPending = true;
                    this.nextPollAt = l + 50L;
                }
            }
            return;
        } else {
            this.menuId = -1;
        }
    }

    private boolean D(class_746 class_7462) {
        if (this.menuId < 0) return false;
        if (class_7462.field_7512 == class_7462.field_7498) return false;
        if (class_7462.field_7512.field_7763 != this.menuId) return false;
        return true;
    }

    private static boolean T(class_1703 class_17032) {
        if (AutoSell.r(class_17032) <= 0) return false;
        return true;
    }

    private static int r(class_1703 class_17032) {
        int n = 0;
        for (class_1735 class_17352 : class_17032.field_7761) {
            if (class_17352.field_7871 instanceof class_1661 || class_17352.field_7874 == 53 || !class_17352.method_7681()) continue;
            n += class_17352.method_7677().method_7947();
        }
        return n;
    }

    private static int Y(class_1703 class_17032) {
        int n = 0;
        for (class_1735 class_17352 : class_17032.field_7761) {
            if (class_17352.field_7871 instanceof class_1661) continue;
            ++n;
        }
        return n;
    }

    private static String F(class_1703 class_17032) {
        StringBuilder stringBuilder = new StringBuilder();
        for (class_1735 class_17352 : class_17032.field_7761) {
            if (class_17352.field_7871 instanceof class_1661) return stringBuilder.toString();
            class_1799 class_17992 = class_17352.method_7677();
            if (class_17992.method_7960()) continue;
            stringBuilder.append(class_17352.field_7874).append(':').append(class_17992.method_7909()).append('x').append(class_17992.method_7947()).append(';');
        }
        return stringBuilder.toString();
    }

    static {
        a = new String[]{"minecraft:netherite_sword", "auto-sell", "Sold ", " items.", "minecraft:totem_of_undying", "golden_apple", "never-sell", "Never Sell", "Auto Sell", "Keeps the /sell menu open and keeps selling everything that is not on your Never Sell list.", " item."};
    }
}
