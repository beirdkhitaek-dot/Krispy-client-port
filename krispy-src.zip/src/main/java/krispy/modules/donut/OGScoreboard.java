package krispy.modules.donut;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import krispy.event.HudRenderEvent;
import krispy.event.Subscribe;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.Setting;
import krispy.modules.donut.Playtime;
import krispy.util.SecureString;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5250;
import net.minecraft.class_5348;
import net.minecraft.class_640;
import net.minecraft.class_8646;
import net.minecraft.class_9011;

public final class OGScoreboard
extends Module {
    private static OGScoreboard instance;
    private final BoolSetting hideVanilla = new BoolSetting(SecureString.of("Hide Vanilla"), true);
    private final NumberSetting scale = new NumberSetting(SecureString.of("Scale"), 0.5, 3.0, 1.0, 0.1);
    private final NumberSetting x = new NumberSetting(SecureString.of("X"), -1.0, 3000.0, -1.0, 1.0);
    private final NumberSetting y = new NumberSetting(SecureString.of("Y"), -1.0, 3000.0, -1.0, 1.0);
    private int lastKnownPing;
    private long lastPingUpdateMs;
    private static String[] a;

    public OGScoreboard() {
        super(SecureString.of("OG Scoreboard"), SecureString.of("Recreates the old Donut SMP sidebar from live scoreboard data"), -1, Category.DONUT);
        this.addSettings(new Setting[]{this.hideVanilla, this.scale, this.x, this.y});
        instance = this;
    }

    public static boolean j() {
        if (instance == null) return false;
        if (!instance.isEnabled()) return false;
        if (!OGScoreboard.instance.hideVanilla.getValue()) return false;
        return true;
    }

    @Subscribe
    private void onHudRender(HudRenderEvent hudRenderEvent) {
        this.R(hudRenderEvent.context);
    }

    private void R(class_332 class_3322) {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1724 == null || class_3102.field_1687 == null || class_3102.field_1772 == null) {
            return;
        }
        Playtime playtime = this.M(class_3102);
        ArrayList<class_5250> arrayList = new ArrayList<class_5250>(8);
        arrayList.add(class_2561.method_43473());
        arrayList.add(OGScoreboard.f("$", "Money", OGScoreboard.w(playtime.money), 65280, true));
        arrayList.add(OGScoreboard.f("\u2605", "Shards", OGScoreboard.w(playtime.shards), 10813692, false));
        arrayList.add(OGScoreboard.f("\u2694", "Kills", OGScoreboard.w(playtime.kills), 0xFF0000, false));
        arrayList.add(OGScoreboard.f("\u2620", "Deaths", OGScoreboard.w(playtime.deaths), 16546163, false));
        arrayList.add(OGScoreboard.f("\u231a", "Playtime", OGScoreboard.w(playtime.playtime), 16766464, false));
        arrayList.add(class_2561.method_43473());
        arrayList.add(OGScoreboard.b(OGScoreboard.w(playtime.ping)));
        class_5250 class_52502 = OGScoreboard.A();
        int n = class_3102.field_1772.method_27525((class_5348)class_52502);
        for (class_2561 class_25612 : arrayList) {
            n = Math.max(n, class_3102.field_1772.method_27525((class_5348)class_25612));
        }
        int n2 = 3;
        int n3 = 9;
        int n4 = n + n2 * 2;
        int n5 = n3 + 2;
        int n6 = n5 + arrayList.size() * n3 + 2;
        float f = Math.max(0.5f, Math.min(3.0f, this.scale.getFloatValue()));
        int n7 = Math.round((float)n4 * f);
        int n8 = Math.round((float)n6 * f);
        int n9 = this.x.getValue() < 0.0 ? class_3322.method_51421() - n7 - 2 : this.x.getIntValue();
        int n10 = this.y.getValue() < 0.0 ? (class_3322.method_51443() - n8) / 2 : this.y.getIntValue();
        class_3322.method_51448().pushMatrix();
        class_3322.method_51448().translate((float)n9, (float)n10);
        class_3322.method_51448().scale(f, f);
        class_3322.method_25294(0, 0, n4, n5, Integer.MIN_VALUE);
        class_3322.method_25294(0, n5, n4, n6, 0x60000000);
        class_3322.method_51439(class_3102.field_1772, (class_2561)class_52502, (n4 - class_3102.field_1772.method_27525((class_5348)class_52502)) / 2, 2, -1, false);
        int n11 = n5 + 1;
        for (class_2561 class_25613 : arrayList) {
            class_3322.method_51439(class_3102.field_1772, class_25613, n2, n11, -1, false);
            n11 += n3;
        }
        class_3322.method_51448().popMatrix();
    }

    private Playtime M(class_310 class_3102) {
        Playtime playtime = new Playtime();
        try {
            class_269 class_2692 = class_3102.field_1687.method_8428();
            class_266 class_2662 = class_2692.method_1189(class_8646.field_45157);
            if (class_2662 == null) {
                playtime.ping = String.valueOf(this.L(class_3102));
                return playtime;
            }
            Collection collection = class_2692.method_1184(class_2662);
            ArrayList<class_9011> arrayList = new ArrayList<class_9011>(collection);
            arrayList.sort(Comparator.comparingInt(class_9011::comp_2128).reversed());
            boolean[] blArray = new boolean[5];
            int n = 0;
            for (class_9011 class_90112 : arrayList) {
                String[] stringArray;
                String string = this.m(class_2692, class_90112);
                if (string.isEmpty()) continue;
                String string2 = string.toLowerCase(Locale.ROOT);
                if (!blArray[0]) {
                    String[] stringArray2 = new String[5];
                    stringArray2[0] = "$";
                    stringArray = a;
                    stringArray2[1] = "money";
                    stringArray2[2] = "balance";
                    stringArray2[3] = "coins";
                    stringArray2[4] = "bal";
                    if (OGScoreboard.i(string, string2, stringArray2)) {
                        playtime.money = OGScoreboard.a(string);
                        blArray[0] = true;
                        ++n;
                        continue;
                    }
                }
                if (!blArray[1]) {
                    String[] stringArray3 = new String[4];
                    stringArray3[0] = "*";
                    stringArray = a;
                    stringArray3[1] = "shard";
                    stringArray3[2] = "nirmata";
                    stringArray3[3] = "gem";
                    if (OGScoreboard.i(string, string2, stringArray3)) {
                        playtime.shards = OGScoreboard.a(string);
                        blArray[1] = true;
                        ++n;
                        continue;
                    }
                }
                if (!blArray[2]) {
                    String[] stringArray4 = new String[1];
                    stringArray = a;
                    stringArray4[0] = "kill";
                    if (OGScoreboard.i(string, string2, stringArray4)) {
                        playtime.kills = OGScoreboard.a(string);
                        blArray[2] = true;
                        ++n;
                        continue;
                    }
                }
                if (!blArray[3]) {
                    String[] stringArray5 = new String[1];
                    stringArray = a;
                    stringArray5[0] = "death";
                    if (OGScoreboard.i(string, string2, stringArray5)) {
                        playtime.deaths = OGScoreboard.a(string);
                        blArray[3] = true;
                        ++n;
                        continue;
                    }
                }
                if (blArray[4] || !OGScoreboard.i(string, string2, "playtime", "play time", "time played", "uptime")) continue;
                playtime.playtime = OGScoreboard.H(string);
                blArray[4] = true;
                ++n;
            }
            if (n < 3) {
                this.u(class_2692, arrayList, playtime, blArray);
            }
            playtime.ping = String.valueOf(this.L(class_3102));
            return playtime;
        }
        catch (Throwable throwable) {
            playtime.ping = String.valueOf(this.L(class_3102));
        }
        return playtime;
    }

    private void u(class_269 class_2692, List<class_9011> list, Playtime playtime, boolean[] blArray) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (class_9011 stringArray2 : list) {
            String i = this.m(class_2692, stringArray2);
            if (i.isEmpty() || OGScoreboard.T(i)) continue;
            arrayList.add(i);
        }
        int n = !arrayList.isEmpty() && !OGScoreboard.n((String)arrayList.getFirst()) ? 1 : 0;
        String[] stringArray = new String[5];
        for (int i = 0; i + n < arrayList.size() && i < stringArray.length; ++i) {
            stringArray[i] = (String)arrayList.get(i + n);
        }
        if (!blArray[0] && stringArray[0] != null) {
            playtime.money = OGScoreboard.a(stringArray[0]);
        }
        if (!blArray[1] && stringArray[1] != null) {
            playtime.shards = OGScoreboard.a(stringArray[1]);
        }
        if (!blArray[2] && stringArray[2] != null) {
            playtime.kills = OGScoreboard.a(stringArray[2]);
        }
        if (!blArray[3] && stringArray[3] != null) {
            playtime.deaths = OGScoreboard.a(stringArray[3]);
        }
        if (blArray[4] || stringArray[4] == null) return;
        playtime.playtime = OGScoreboard.H(stringArray[4]);
    }

    private String m(class_269 class_2692, class_9011 class_90112) {
        class_2561 class_25612 = class_90112.method_55387();
        if (class_25612 == null) {
            class_25612 = class_2561.method_43470((String)(class_90112.comp_2127() == null ? "" : class_90112.comp_2127()));
        }
        class_2561 class_25613 = class_25612;
        try {
            class_268 class_2682 = class_2692.method_1164(class_90112.comp_2127());
            if (class_2682 == null) return OGScoreboard.V(class_25613.getString());
            class_25613 = class_2682.method_1198(class_25612);
            return OGScoreboard.V(class_25613.getString());
        }
        catch (Throwable throwable) {

        }
        return OGScoreboard.V(class_25613.getString());
    }

    private int L(class_310 class_3102) {
        int n = this.N(class_3102);
        long l = System.currentTimeMillis();
        if (n > 0) {
            this.lastKnownPing = n;
            this.lastPingUpdateMs = l;
            return n;
        }
        if (this.lastKnownPing <= 0) return 0;
        if (l - this.lastPingUpdateMs >= 60000L) return 0;
        int n2 = this.lastKnownPing;
        return n2;
    }

    private int N(class_310 class_3102) {
        if (class_3102.field_1724 == null || class_3102.method_1562() == null) {
            return 0;
        }
        try {
            UUID uUID = class_3102.field_1724.method_5667();
            String string = class_3102.field_1724.method_5477().getString();
            class_640 class_6402 = class_3102.method_1562().method_2871(uUID);
            if (class_6402 != null && class_6402.method_2959() > 0) {
                return class_6402.method_2959();
            }
            for (class_640 class_6403 : class_3102.method_1562().method_2880()) {
                if (class_6403 == null || class_6403.method_2966() == null) continue;
                if (uUID.equals(class_6403.method_2966().id()) && class_6403.method_2959() > 0) {
                    return class_6403.method_2959();
                }
                if (!string.equals(class_6403.method_2966().name()) || class_6403.method_2959() <= 0) continue;
                return class_6403.method_2959();
            }
            for (class_640 class_6403 : class_3102.method_1562().method_2880()) {
                if (class_6403 == null || class_6403.method_2959() <= 0) continue;
                return class_6403.method_2959();
            }
            return 0;
        }
        catch (Throwable throwable) {

        }
        return 0;
    }

    private static class_5250 f(String string, String string2, String string3, int n, boolean bl) {
        return class_2561.method_43473().method_10852((class_2561)class_2561.method_43470((String)string).method_10862(class_2583.field_24360.method_36139(n).method_10982(Boolean.valueOf(bl)))).method_10852((class_2561)class_2561.method_43470((String)(" " + string2 + " ")).method_27692(class_124.field_1080)).method_10852((class_2561)class_2561.method_43470((String)string3).method_27694(arg_0 -> OGScoreboard.lmbd$statRow$0(n, arg_0)));
    }

    private static class_5250 b(String string) {
        return class_2561.method_43473().method_10852((class_2561)class_2561.method_43470((String)"EU Central ").method_27694(OGScoreboard::lmbd$footerRow$1)).method_10852((class_2561)class_2561.method_43470((String)("(" + string + "ms)")).method_27694(OGScoreboard::lmbd$footerRow$2));
    }

    private static class_5250 A() {
        String string = "Donut SMP";
        int[] nArray = new int[]{32252, 35068, 37628, 40444, 43260, 46076, 48892, 51708, 54524};
        class_5250 class_52502 = class_2561.method_43473();
        for (int i = 0; i < string.length(); ++i) {
            int n = nArray[Math.min(i, nArray.length - 1)];
            class_52502.method_10852((class_2561)class_2561.method_43470((String)String.valueOf(string.charAt(i))).method_27694(arg_0 -> OGScoreboard.lmbd$donutTitle$3(n, arg_0)));
        }
        return class_52502;
    }

    private static boolean i(String string, String string2, String ... stringArray) {
        for (String string3 : stringArray) {
            if (string3 == null || string3.isEmpty() || !string.contains(string3) && (!OGScoreboard.B(string3) || !string2.contains(string3.toLowerCase(Locale.ROOT)))) continue;
            return true;
        }
        return false;
    }

    private static boolean B(String string) {
        for (int i = 0; i < string.length(); ++i) {
            if (!Character.isLetter(string.charAt(i))) continue;
            return true;
        }
        return false;
    }

    private static boolean T(String string) {
        String string2 = OGScoreboard.V(string);
        if (string2.isEmpty()) return true;
        if (!string2.chars().allMatch(OGScoreboard::lmbd$looksLikeSeparator$4)) return false;
        return true;
    }

    private static boolean n(String string) {
        for (int i = 0; i < string.length(); ++i) {
            if (!Character.isDigit(string.charAt(i))) continue;
            return true;
        }
        return false;
    }

    private static String a(String string) {
        int n;
        String string2 = OGScoreboard.V(string);
        if (string2.isEmpty()) {
            return "0";
        }
        String[] stringArray = string2.split("\\s+");
        for (n = stringArray.length - 1; n >= 0; --n) {
            if (!OGScoreboard.n(stringArray[n])) continue;
            return stringArray[n];
        }
        for (n = stringArray.length - 1; n >= 0; --n) {
            if (stringArray[n].isEmpty()) continue;
            return stringArray[n];
        }
        return "0";
    }

    private static String H(String string) {
        String string2;
        String string3 = OGScoreboard.V(string);
        if (string3.isEmpty()) {
            return "0";
        }
        String[] stringArray = a;
        String[] stringArray2 = string3.split("\\s+");
        ArrayList<String> arrayList = new ArrayList<String>();
        for (int i = stringArray2.length - 1; i >= 0 && ((string2 = stringArray2[i]).matches("\\d+[dhmsy]") || string2.matches("\\d+")); --i) {
            arrayList.addFirst(string2);
        }
        return !arrayList.isEmpty() ? String.join((CharSequence)" ", arrayList) : OGScoreboard.a(string3);
    }

    private static String V(String string) {
        if (string == null) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder(string.length());
        for (int i = 0; i < string.length(); ++i) {
            char c = string.charAt(i);
            if (c == '\u00a7') {
                ++i;
                continue;
            }
            int n = Character.getType(c);
            if (n != 15 && n != 16 && n != 19 && c != '\u200b' && c != '\u200c' && c != '\u200d' && c != '\ufeff') {
                stringBuilder.append(c);
                continue;
            }
            stringBuilder.append(' ');
        }
        return stringBuilder.toString().trim();
    }

    private static String w(String string) {
        if (string == null) return "0";
        if (string.isEmpty()) return "0";
        String string2 = string;
        return string2;
    }

    private static boolean lmbd$looksLikeSeparator$4(int n) {
        if (n == 32) return true;
        if (n == 45) return true;
        if (n == 95) return true;
        if (n == 46) return true;
        if (n != 42) return false;
        return true;
    }

    private static class_2583 lmbd$donutTitle$3(int n, class_2583 class_25832) {
        return class_25832.method_36139(n).method_10982(Boolean.valueOf(true));
    }

    private static class_2583 lmbd$footerRow$2(class_2583 class_25832) {
        return class_25832.method_36139(42751);
    }

    private static class_2583 lmbd$footerRow$1(class_2583 class_25832) {
        return class_25832.method_36139(0xAAAAAA);
    }

    private static class_2583 lmbd$statRow$0(int n, class_2583 class_25832) {
        return class_25832.method_36139(n);
    }

    static {
        a = new String[]{"EU Central ", "gem", "OG Scoreboard", "\\s+", "kill", "uptime", "\\s+", "death", "Hide Vanilla", "money", "time played", "nirmata", "shard", "Recreates the old Donut SMP sidebar from live scoreboard data", "ms)", "balance", "\\d+[dhmsy]", "play time", "Donut SMP", "playtime", "\\d+", "Scale", "coins", "bal"};
    }
}
