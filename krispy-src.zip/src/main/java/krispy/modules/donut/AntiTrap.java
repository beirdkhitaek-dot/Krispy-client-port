package krispy.modules.donut;

import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.util.SecureString;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_238;

public final class AntiTrap
extends Module {
    private static String[] a;
    public AntiTrap() {
        super(SecureString.of("Anti Trap"), SecureString.of("Clears nearby armor stands and chest minecarts blocking your movement"), -1, Category.DONUT);
    }

    @Override
    public void onEnable() {
        this.A();
        super.onEnable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        this.A();
    }

    private void A() {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        class_238 class_2382 = this.mc.field_1724.method_5829().method_1014(0.35);
        for (class_1297 class_12972 : this.mc.field_1687.method_8333((class_1297)this.mc.field_1724, class_2382, arg_0 -> AntiTrap.lmbd$clearBlockingEntities$0(class_2382, arg_0))) {
            if (class_12972.method_31481()) continue;
            class_12972.method_5650(class_1297.class_5529.field_26999);
        }
    }

    private static boolean k(class_1297 class_12972) {
        if (class_12972 == null) return false;
        if (class_12972.method_5864() == class_1299.field_6131) return true;
        if (class_12972.method_5864() != class_1299.field_6126) return false;
        return true;
    }

    private static boolean lmbd$clearBlockingEntities$0(class_238 class_2382, class_1297 class_12972) {
        if (!AntiTrap.k(class_12972)) return false;
        if (!class_12972.method_5829().method_994(class_2382)) return false;
        return true;
    }

    static {
        a = new String[]{"Anti Trap", "Clears nearby armor stands and chest minecarts blocking your movement"};
    }
}
