package krispy.modules.donut;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.PrintStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.CycleSetting;
import krispy.module.settings.ItemSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.Setting;
import krispy.module.settings.StringSetting;
import krispy.modules.donut.AuctionMode;
import krispy.util.SecureString;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_746;

public final class AuctionSniper
extends Module {
    private final ItemSetting snipingItem = new ItemSetting(SecureString.of("Sniping Item"), class_1802.field_8162);
    private final StringSetting price = new StringSetting(SecureString.of("Price"), "1k");
    private final CycleSetting<AuctionMode> mode = new CycleSetting<AuctionMode>(SecureString.of("Mode"), AuctionMode.MANUAL, AuctionMode.class).setDescription(SecureString.of("Manual is faster but api doesnt require auction gui opened all the time"));
    private final StringSetting apiKey = new StringSetting(SecureString.of("Api Key"), "").setDescription(SecureString.of("You can get it by typing /api in chat"));
    private final NumberSetting refreshDelay = new NumberSetting(SecureString.of("Refresh Delay"), 0.0, 100.0, 2.0, 1.0);
    private final NumberSetting buyDelay = new NumberSetting(SecureString.of("Buy Delay"), 0.0, 100.0, 2.0, 1.0);
    private final NumberSetting apiRefreshRate = new NumberSetting(SecureString.of("API Refresh Rate"), 10.0, 5000.0, 250.0, 10.0).getValue(SecureString.of("How often to query the API (in milliseconds)"));
    private final BoolSetting showApiNotifications = new BoolSetting(SecureString.of("Show API Notifications"), true).setDescription(SecureString.of("Show chat notifications for API actions"));
    private int delayCounter;
    private boolean isProcessing;
    private final HttpClient httpClient;
    private final Gson gson;
    private long lastApiCallTimestamp = 0L;
    private final Map<String, Double> snipingItems = new HashMap<String, Double>();
    private boolean isApiQueryInProgress = false;
    private boolean isAuctionSniping = false;
    private int auctionPageCounter = -1;
    private String currentSellerName = "";
    private static final String[] a = new String[]{"Show API Notifications", "item", ") \u00a7afrom seller: ", "\u00a7cError processing auction: ", "ah ", "Snipes items on auction house for cheap", "1k", "Recently Listed", "([\\d]+(?:\\.[\\d]+)?)\\s*([KMB])?", "Buy Delay", "{\"sort\": \"recently_listed\"}", "seller", "Sniping Item", "result", "API Refresh Rate", "price", " for ", "Show chat notifications for API actions", "white", "Invalid Auction Item Price", "Invalid Price", "Price", "white", "Manual is faster but api doesnt require auction gui opened all the time", "[,$]", "Refresh Delay", "Page", "Auction Sniper", "\u00a7aFound ", "%.2fB", "application/json", "Mode", "%.2fM", "\u00a7cAPI Error: ", "Content-Type", "Authorization", "name", "(?i).*price\\s*:\\s*\\$.*", ". ", "https://api.donutsmp.net/v1/auction/list/1", "Bearer ", "%.2fK", "\u00a7cAPI key is not set. Set it using /api in-game.", " \u00a7r(threshold: ", "%.2f", "Api Key", "You can get it by typing /api in chat", "How often to query the API (in milliseconds)", "id", "Invalid Price"};

    public AuctionSniper() {
        super(SecureString.of("Auction Sniper"), SecureString.of("Snipes items on auction house for cheap"), -1, Category.MISC);
        this.httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5L)).build();
        this.gson = new Gson();
        Setting[] settingArray = new Setting[]{this.snipingItem, this.price, this.mode, this.apiKey, this.refreshDelay, this.buyDelay, this.apiRefreshRate, this.showApiNotifications};
        this.addSettings(settingArray);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        double d = this.K(this.price.getValue());
        if (d == -1.0) {
            if (this.mc.field_1724 != null) {
                class_746 class_7462 = this.mc.field_1724;
                class_7462.method_7353(class_2561.method_30163((String)"Invalid Price"), true);
            }
            this.toggle();
            return;
        } else {
            if (this.snipingItem.getItem() != class_1802.field_8162) {
                Map<String, Double> map = this.snipingItems;
                map.put(this.snipingItem.getItem().toString(), d);
            }
            this.lastApiCallTimestamp = 0L;
            this.isApiQueryInProgress = false;
            this.isAuctionSniping = false;
            this.currentSellerName = "";
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.isAuctionSniping = false;
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1724 == null) return;
        if (this.delayCounter > 0) {
            --this.delayCounter;
            return;
        } else if (this.mode.isMode(AuctionMode.API)) {
            this.F();
            return;
        } else {
            if (!this.mode.isMode(AuctionMode.MANUAL)) return;
            class_1703 class_17032 = this.mc.field_1724.field_7512;
            if (!(this.mc.field_1724.field_7512 instanceof class_1707)) {
                String[] stringArray = this.snipingItem.getItem().method_7876().split("\\.");
                String string = stringArray[stringArray.length - 1];
                String string2 = Arrays.stream(string.replace("_", " ").split(" ")).map(AuctionSniper::lmbd$onTick$0).collect(Collectors.joining(" "));
                this.mc.method_1562().method_45730("ah " + string2);
                this.delayCounter = 20;
                return;
            }
            if (((class_1707)class_17032).method_17388() == 6) {
                this.E((class_1707)class_17032);
                return;
            } else {
                if (((class_1707)class_17032).method_17388() != 3) return;
                this.U((class_1707)class_17032);
            }
        }
    }

    private void F() {
        if (!this.isAuctionSniping) {
            if (this.mc.field_1724.field_7512 instanceof class_1707) {
                String[] stringArray = a;
                if (this.mc.field_1755.method_25440().getString().contains("Page")) {
                    this.mc.field_1724.method_7346();
                    this.delayCounter = 20;
                    return;
                }
            }
            if (this.isApiQueryInProgress) return;
            long l = System.currentTimeMillis();
            long l2 = l - this.lastApiCallTimestamp;
            if (l2 <= (long)this.apiRefreshRate.getIntValue()) return;
            this.lastApiCallTimestamp = l;
            if (this.apiKey.getValue().isEmpty()) {
                if (!this.showApiNotifications.getValue()) return;
                class_746 class_7462 = this.mc.field_1724;
                class_7462.method_7353(class_2561.method_30163((String)"\u00a7cAPI key is not set. Set it using /api in-game."), false);
                return;
            }
            this.isApiQueryInProgress = true;
            this.V().thenAccept(this::N);
            return;
        }
        class_1703 class_17032 = this.mc.field_1724.field_7512;
        if (!(this.mc.field_1724.field_7512 instanceof class_1707)) {
            if (this.auctionPageCounter == -1) {
                this.mc.method_1562().method_45730("ah " + this.currentSellerName);
                this.auctionPageCounter = 0;
                return;
            }
            if (this.auctionPageCounter <= 40) {
                ++this.auctionPageCounter;
                return;
            }
            this.isAuctionSniping = false;
            this.currentSellerName = "";
            return;
        }
        this.auctionPageCounter = -1;
        if (((class_1707)class_17032).method_17388() == 6) {
            this.E((class_1707)class_17032);
            return;
        }
        if (((class_1707)class_17032).method_17388() != 3) return;
        this.U((class_1707)class_17032);
    }

    private CompletableFuture<List<?>> V() {
        return CompletableFuture.supplyAsync(this::lmbd$queryApi$1);
    }

    private void N(List list) {
        for (Object e : list) {
            try {
                String[] stringArray = a;
                String string = ((JsonObject)e).getAsJsonObject("item").get("id").getAsString();
                long l = ((JsonObject)e).get("price").getAsLong();
                String string2 = ((JsonObject)e).getAsJsonObject("seller").get("name").getAsString();
                for (Map.Entry<String, Double> entry : this.snipingItems.entrySet()) {
                    String string3 = entry.getKey();
                    double d = entry.getValue();
                    if (!string.contains(string3) || !((double)l <= d)) continue;
                    if (this.showApiNotifications.getValue() && this.mc.field_1724 != null) {
                        class_746 class_7462 = this.mc.field_1724;
                        String string4 = string2;
                        String string5 = this.u(d);
                        String string6 = this.u(l);
                        String string7 = string;
                        class_7462.method_7353(class_2561.method_30163((String)("\u00a7aFound " + string7 + " for " + string6 + " \u00a7r(threshold: " + string5 + ") \u00a7afrom seller: " + string4)), false);
                    }
                    this.isAuctionSniping = true;
                    this.currentSellerName = string2;
                    return;
                }
            }
            catch (Exception exception) {
                if (!this.showApiNotifications.getValue() || this.mc.field_1724 == null) continue;
                class_746 class_7463 = this.mc.field_1724;
                class_7463.method_7353(class_2561.method_30163((String)("\u00a7cError processing auction: " + exception.getMessage())), false);
            }
        }
    }

    private void E(class_1707 class_17072) {
        class_1799 class_17992 = class_17072.method_7611(47).method_7677();
        if (class_17992.method_31574(class_1802.field_8162)) {
            this.delayCounter = 2;
            return;
        } else {
            for (Object object : class_17992.method_7950(class_1792.class_9635.field_51353, (class_1657)this.mc.field_1724, (class_1836)class_1836.field_41070)) {
                String string = object.toString();
                if (!string.contains("Recently Listed") || !((class_2561)object).method_10866().toString().contains("white") && !string.contains("white")) continue;
                this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 47, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
                this.delayCounter = 5;
                return;
            }
            for (int i = 0; i < 44; ++i) {
                class_1799 object;
                object = class_17072.method_7611(i).method_7677();
                if (!object.method_31574(this.snipingItem.getItem()) || !this.t(object)) continue;
                if (this.isProcessing) {
                    this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, i, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
                    this.isProcessing = false;
                    return;
                }
                this.isProcessing = true;
                this.delayCounter = this.buyDelay.getIntValue();
                return;
            }
            if (this.isAuctionSniping) {
                this.isAuctionSniping = false;
                this.currentSellerName = "";
                this.mc.field_1724.method_7346();
                return;
            } else {
                this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 49, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
                this.delayCounter = this.refreshDelay.getIntValue();
            }
        }
    }

    private void U(class_1707 class_17072) {
        if (this.t(class_17072.method_7611(13).method_7677())) {
            this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 15, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
            this.delayCounter = 20;
        }
        if (!this.isAuctionSniping) return;
        this.isAuctionSniping = false;
        this.currentSellerName = "";
    }

    private double J(List list) {
        if (list == null || list.isEmpty()) return -1.0;
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            String string = ((class_2561)iterator.next()).getString();
            if (!string.matches("(?i).*price\\s*:\\s*\\$.*")) continue;
            String string2 = string.replaceAll("[,$]", "");
            Matcher matcher = Pattern.compile("([\\d]+(?:\\.[\\d]+)?)\\s*([KMB])?", 2).matcher(string2);
            if (!matcher.find()) continue;
            String string3 = matcher.group(1);
            String string4 = matcher.group(2) != null ? matcher.group(2).toUpperCase() : "";
            return this.K(string3 + string4);
        }
        return -1.0;
    }

    private boolean t(class_1799 class_17992) {
        List list = class_17992.method_7950(class_1792.class_9635.field_51353, (class_1657)this.mc.field_1724, (class_1836)class_1836.field_41070);
        double d = this.J(list) / (double)class_17992.method_7947();
        double d2 = this.K(this.price.getValue());
        if (d2 == -1.0) {
            if (this.mc.field_1724 != null) {
                class_746 class_7462 = this.mc.field_1724;
                String[] stringArray = a;
                class_7462.method_7353(class_2561.method_30163((String)"Invalid Price"), true);
            }
            this.toggle();
            return false;
        }
        if (d != -1.0) {
            if (!(d <= d2)) return false;
            return true;
        }
        if (this.mc.field_1724 != null) {
            class_746 class_7463 = this.mc.field_1724;
            class_7463.method_7353(class_2561.method_30163((String)"Invalid Auction Item Price"), true);
            for (int i = 0; i < list.size() - 1; ++i) {
                PrintStream printStream = System.out;
                printStream.println(i + ". " + ((class_2561)list.get(i)).getString());
            }
        }
        this.toggle();
        return false;
    }

    private double K(String string) {
        if (string == null) {
            return -1.0;
        }
        if (string.isEmpty()) {
            return -1.0;
        }
        String string2 = string.trim().toUpperCase();
        double d = 1.0;
        if (string2.endsWith("B")) {
            d = 1.0E9;
            string2 = string2.substring(0, string2.length() - 1);
        } else if (string2.endsWith("M")) {
            d = 1000000.0;
            string2 = string2.substring(0, string2.length() - 1);
        } else if (string2.endsWith("K")) {
            d = 1000.0;
            string2 = string2.substring(0, string2.length() - 1);
        }
        try {
            return Double.parseDouble(string2) * d;
        }
        catch (NumberFormatException numberFormatException) {
            return -1.0;
        }
    }

    private String u(double d) {
        if (d >= 1.0E9) {
            Object[] objectArray = new Object[]{d / 1.0E9};
            String[] stringArray = a;
            return String.format("%.2fB", objectArray);
        }
        if (d >= 1000000.0) {
            Object[] objectArray = new Object[]{d / 1000000.0};
            String[] stringArray = a;
            return String.format("%.2fM", objectArray);
        }
        if (d >= 1000.0) {
            Object[] objectArray = new Object[]{d / 1000.0};
            return String.format("%.2fK", objectArray);
        }
        Object[] objectArray = new Object[]{d};
        return String.format("%.2f", objectArray);
    }

    private List lmbd$queryApi$1() {
        try {
            String string = "https://api.donutsmp.net/v1/auction/list/1";
            HttpResponse<String> httpResponse = this.httpClient.send(HttpRequest.newBuilder().uri(URI.create(string)).header("Authorization", "Bearer " + this.apiKey.getValue()).header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString("{\"sort\": \"recently_listed\"}")).build(), HttpResponse.BodyHandlers.ofString());
            if (httpResponse.statusCode() != 200) {
                class_746 class_7462;
                if (this.showApiNotifications.getValue() && this.mc.field_1724 != null) {
                    class_7462 = this.mc.field_1724;
                    class_7462.method_7353(class_2561.method_30163((String)("\u00a7cAPI Error: " + httpResponse.statusCode())), false);
                }
                this.isApiQueryInProgress = false;
                return new ArrayList();
            }
            Gson gson = this.gson;
            JsonArray jsonArray = gson.fromJson(httpResponse.body(), JsonObject.class).getAsJsonArray("result");
            ArrayList<JsonObject> arrayList = new ArrayList<JsonObject>();
            for (JsonElement jsonElement : jsonArray) {
                arrayList.add(jsonElement.getAsJsonObject());
            }
            this.isApiQueryInProgress = false;
            return arrayList;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace(System.err);
            return List.of();
        }
    }

    private static String lmbd$onTick$0(String string) {
        return string.substring(0, 1).toUpperCase() + string.substring(1);
    }
}
