package krispy.modules.donut;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
class Budding {
    public final long[] lining;
    public final long[] budding;

    public Budding(long[] lining, long[] budding) {
        this.lining = lining;
        this.budding = budding;
    }

    public long[] lining() {
        return this.lining;
    }

    public long[] budding() {
        return this.budding;
    }
}
