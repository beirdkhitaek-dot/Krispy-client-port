package krispy.modules.donut;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import krispy.client.KrispyClient;
import krispy.event.ScreenOpenEvent;
import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.Setting;
import krispy.module.settings.StringSetting;
import krispy.util.SecureString;
import net.minecraft.class_2561;
import net.minecraft.class_419;

public final class AutoRTP
extends Module {
    private static List<String> REGIONS;
    private final StringSetting command = new StringSetting(SecureString.of("Command"), "/rtp").setDescription(SecureString.of("Command sent on each interval when Random Region is off"));
    private final NumberSetting delay = new NumberSetting(SecureString.of("Delay"), 0.05, 10.0, 1.0, 0.05).getValue(SecureString.of("Seconds between RTP commands"));
    private final BoolSetting randomRegion = new BoolSetting(SecureString.of("Random Region"), false).setDescription(SecureString.of("Cycles through every Donut RTP region in a shuffled order"));
    private final BoolSetting disableOnBypassFlag = new BoolSetting(SecureString.of("Disable On Bypass Flag"), true).setDescription(SecureString.of("Turns Auto RTP off on Player Bypass flags; any kick also disables Auto RTP"));
    private final List<String> queue = new ArrayList<String>();
    private long lastSent;
    private static String[] a;
    private static final long CNLp8iAqgCcfpDLjN9 = 6669667889167344122L;

    public AutoRTP() {
        super(SecureString.of("Auto RTP"), SecureString.of("Runs /rtp on a timer and cooperates with Player Bypass"), -1, Category.DONUT);
        this.addSettings(new Setting[]{this.command, this.delay, this.randomRegion, this.disableOnBypassFlag});
    }

    @Override
    public void onEnable() {
        this.lastSent = 0L;
        this.queue.clear();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.queue.clear();
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        String string;
        if (this.mc.field_1724 == null || this.mc.method_1562() == null) {
            return;
        }
        long l = System.currentTimeMillis();
        if (l - this.lastSent < (long)(this.delay.getValue() * 1000.0)) {
            return;
        }
        if (this.randomRegion.getValue()) {
            if (this.queue.isEmpty()) {
                this.queue.addAll(REGIONS);
                Collections.shuffle(this.queue);
            }
            string = this.queue.removeFirst();
        } else {
            string = AutoRTP.n(this.command.getValue());
        }
        if (string.isBlank()) {
            return;
        }
        this.lastSent = l;
        this.mc.method_1562().method_45730(string);
    }

    public void e() {
        if (!this.isEnabled() || !this.disableOnBypassFlag.getValue()) {
            return;
        }
        this.toggle(false);
        if (this.mc.field_1724 != null) {
            this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)"\u00a7e[Auto RTP] \u00a7fDisabled because Player Bypass detected a flag."), false);
        }
        KrispyClient.INSTANCE.getSettingsManager().saveNow();
    }

    @Subscribe
    public void onScreenOpen(ScreenOpenEvent screenOpenEvent) {
        if (!(screenOpenEvent.screen instanceof class_419)) {
            return;
        }
        this.toggle(false);
        KrispyClient.INSTANCE.getSettingsManager().saveNow();
    }

    private static String n(String string) {
        if (string == null) {
            return "";
        }
        String string2 = string.trim();
        while (string2.startsWith("/")) {
            string2 = string2.substring(1).trim();
        }
        return string2;
    }

    static {
        String[] stringArray = a = new String[]{"rtp asia", "Disable On Bypass Flag", "rtp eu oceania", "/rtp", "Auto RTP", "Delay", "\u00a7e[Auto RTP] \u00a7fDisabled because Player Bypass detected a flag.", "rtp east", "Turns Auto RTP off on Player Bypass flags; any kick also disables Auto RTP", "rtp west", "Seconds between RTP commands", "rtp eu central", "Random Region", "Cycles through every Donut RTP region in a shuffled order", "Command", "Runs /rtp on a timer and cooperates with Player Bypass", "rtp eu west", "Command sent on each interval when Random Region is off"};
        REGIONS = List.of(stringArray[0], stringArray[11], stringArray[16], stringArray[2], stringArray[7], stringArray[9]);
    }
}
