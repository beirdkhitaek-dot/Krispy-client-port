package krispy.modules.donut;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import krispy.event.MacroRender3DEvent;
import krispy.event.PacketReceiveEvent;
import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.MacroCategories;
import krispy.module.MacroSubscribe;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.Setting;
import krispy.modules.donut.Source;
import krispy.modules.misc.MacroModule;
import krispy.util.InverseProjectionScratch;
import krispy.util.PixelPerDepth;
import net.minecraft.class_12179;
import net.minecraft.class_12180;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2622;
import net.minecraft.class_2672;
import net.minecraft.class_2678;
import net.minecraft.class_2960;
import net.minecraft.class_638;
import net.minecraft.class_7923;

public final class BlockEntityDebug
extends MacroModule {
    private final BoolSetting showNbt = new BoolSetting("Show NBT", true);
    private final BoolSetting deduplicate = new BoolSetting("Deduplicate", true);
    private final BoolSetting tracers = new BoolSetting("Tracers", true);
    private final Map<class_2338, String> positions = new LinkedHashMap<class_2338, String>();
    private final ArrayBlockingQueue<Source> pending = new ArrayBlockingQueue(2048);
    private class_638 world;
    private int ticks;
    private static final String[] a = new String[]{"Displays received block entity data below Y -10.", "minecraft:barrel", "minecraft:ender_chest", "block-entity-debug", "unknown", "minecraft:enchanting_table", "Show NBT", "Deduplicate", "Tracers", "minecraft:furnace", "minecraft:chest", "Update", "minecraft:piston", "minecraft:spawner", "minecraft:shulker_box", "minecraft:trapped_chest", "Block Entity Debug", "minecraft:mob_spawner", "Chunk"};

    public BlockEntityDebug() {
        super("block-entity-debug", "Block Entity Debug", "Displays received block entity data below Y -10.", MacroCategories.DONUT);
        super.addSettings(new Setting[]{this.showNbt, this.deduplicate, this.tracers});
    }

    @Override
    public void onEnable() {
        this.positions.clear();
        this.pending.clear();
        this.world = this.mc.field_1687;
    }

    @Override
    public void onDisable() {
        this.positions.clear();
        this.pending.clear();
        this.world = null;
    }

    @Subscribe
    public void onPacketReceive(PacketReceiveEvent packetReceiveEvent) {
        if (packetReceiveEvent.packet instanceof class_2678) {
            this.pending.clear();
            return;
        }
        class_2596<?> class_25962 = packetReceiveEvent.packet;
        if (class_25962 instanceof class_2622) {
            class_2622 class_26222 = (class_2622)class_25962;
            this.u("Update", class_26222.method_11293(), class_26222.method_11291(), class_26222.method_11290());
            return;
        } else {
            class_25962 = packetReceiveEvent.packet;
            if (!(class_25962 instanceof class_2672)) return;
            class_2672 class_26722 = (class_2672)class_25962;
            class_26722.method_38598().method_38587(class_26722.method_11523(), class_26722.method_11524()).accept(this::lmbd$onPacket$0);
        }
    }

    private void u(String string, class_2338 class_23382, class_2591<?> class_25912, class_2487 class_24872) {
        if (class_23382.method_10264() >= -10) {
            return;
        }
        class_2960 class_29602 = class_25912 == null ? null : class_7923.field_41181.method_10221(class_25912);
        this.pending.offer(new Source(string, class_23382.method_10062(), class_29602 == null ? "unknown" : class_29602.toString(), class_24872, this.mc.field_1687));
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        int n;
        Source source;
        int n2;
        if (this.world != this.mc.field_1687) {
            this.positions.clear();
            this.world = this.mc.field_1687;
        }
        if (this.world == null || this.mc.field_1724 == null) {
            this.pending.clear();
            return;
        }
        for (n2 = 0; n2 < 12 && (source = this.pending.poll()) != null; ++n2) {
            if (source.world() != this.world) continue;
            n = this.positions.containsKey(source.pos()) ? 1 : 0;
            this.positions.put(source.pos(), source.type());
            if (this.deduplicate.getValue() && n != 0) continue;
            if (this.positions.size() > 8192) {
                this.positions.remove(this.positions.keySet().iterator().next());
            }
            Object object = "";
            if (this.showNbt.getValue() && source.nbt() != null && ((String)(object = " nbt=" + String.valueOf(source.nbt()))).length() > 2048) {
                object = ((String)object).substring(0, 2048) + "\u2026";
            }
            this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)("[" + source.source() + "] " + source.type() + " at (" + source.pos().method_10263() + ", " + source.pos().method_10264() + ", " + source.pos().method_10260() + ")" + (String)object)), false);
        }
        if (++this.ticks % 20 != 0) return;
        n2 = this.mc.field_1690.method_38521() + 2;
        int n3 = this.mc.field_1724.method_31477() >> 4;
        n = this.mc.field_1724.method_31479() >> 4;
        final int cxFinal = n3;
        final int radiusFinal = n2;
        final int czFinal = n;
        this.positions.keySet().removeIf(arg_0 -> BlockEntityDebug.lmbd$onTick$0(cxFinal, radiusFinal, czFinal, arg_0));
    }

    private static int b(String string) {
        String string2 = string;
        int n = -1;
        switch (string2.hashCode()) {
            case -314099657: {
                String[] stringArray = a;
                if (!string2.equals("minecraft:trapped_chest")) break;
                n = 0;
                break;
            }
            case -1149092108: {
                String[] stringArray = a;
                if (!string2.equals("minecraft:chest")) break;
                n = 1;
                break;
            }
            case -1632816003: {
                String[] stringArray = a;
                if (!string2.equals("minecraft:ender_chest")) break;
                n = 2;
                break;
            }
            case -199249700: {
                String[] stringArray = a;
                if (!string2.equals("minecraft:mob_spawner")) break;
                n = 3;
                break;
            }
            case 1069692059: {
                String[] stringArray = a;
                if (!string2.equals("minecraft:spawner")) break;
                n = 4;
                break;
            }
            case 1374330859: {
                String[] stringArray = a;
                if (!string2.equals("minecraft:shulker_box")) break;
                n = 5;
                break;
            }
            case -1719356277: {
                String[] stringArray = a;
                if (!string2.equals("minecraft:furnace")) break;
                n = 6;
                break;
            }
            case -1296824813: {
                String[] stringArray = a;
                if (!string2.equals("minecraft:barrel")) break;
                n = 7;
                break;
            }
            case 319164197: {
                if (!string2.equals("minecraft:enchanting_table")) break;
                n = 8;
                break;
            }
            case -888596506: {
                if (!string2.equals("minecraft:piston")) break;
                n = 9;
            }
        }
        switch (n) {
            case 0: {
                return 13130496;
            }
            case 1: {
                return 10246912;
            }
            case 2: {
                return 7667967;
            }
            case 3:
            case 4: {
                return 9076390;
            }
            case 5: {
                return 8781982;
            }
            case 6: {
                return 0x7D7D7D;
            }
            case 7: {
                return 0xFF8C8C;
            }
            case 8: {
                return 0x5050FF;
            }
            case 9: {
                return 2351616;
            }
            default: {
                return 0xFFFFFF;
            }
        }
    }

    @MacroSubscribe
    public void onMacroRender3D(MacroRender3DEvent macroRender3DEvent) {
        if (this.mc.field_1724 == null || this.world == null) {
            return;
        }
        int n = this.mc.field_1690.method_38521();
        int n2 = this.mc.field_1724.method_31477() >> 4;
        int n3 = this.mc.field_1724.method_31479() >> 4;
        PixelPerDepth pixelPerDepth = PixelPerDepth.forFrame(macroRender3DEvent.partialTick);
        for (Map.Entry<class_2338, String> entry : this.positions.entrySet()) {
            class_2338 class_23382 = entry.getKey();
            if (Math.abs((class_23382.method_10263() >> 4) - n2) > n || Math.abs((class_23382.method_10260() >> 4) - n3) > n) continue;
            class_238 class_2382 = new class_238(class_23382);
            if (macroRender3DEvent.frustum != null && !macroRender3DEvent.frustum.method_23093(class_2382)) continue;
            int n4 = BlockEntityDebug.b(entry.getValue());
            class_12180.method_75541((class_238)class_2382, (class_12179)class_12179.method_75539((int)(0x7D000000 | n4))).method_75533();
            if (!this.tracers.getValue()) continue;
            pixelPerDepth.line(InverseProjectionScratch.getTracerStart(this.mc.field_1773.method_19418()), class_23382.method_46558(), 0xFF000000 | n4, 1.0f);
        }
    }

    private static boolean lmbd$onTick$0(int n, int n2, int n3, class_2338 class_23382) {
        if (Math.abs((class_23382.method_10263() >> 4) - n) > n2) return true;
        if (Math.abs((class_23382.method_10260() >> 4) - n3) <= n2) return false;
        return true;
    }

    private void lmbd$onPacket$0(class_2338 class_23382, class_2591 class_25912, class_2487 class_24872) {
        this.u("Chunk", class_23382, class_25912, class_24872);
    }
}
