package krispy.modules.donut;

import java.util.regex.Pattern;

public final class Drdonutt {
    private static final Pattern FORMATTING = Pattern.compile("(?i)\u00a7[0-9a-fk-or]");
    private static final Pattern ROLE = Pattern.compile("(?i)\\b(helper|sr\\.?\\s*helper|srhelper|mod|moderator|sr\\.?\\s*mod|srmod|admin|administrator|sr\\.?\\s*admin|sradmin|manager|dev|developer|owner|founder|staff)\\b");
    private static final Pattern BRACKET = Pattern.compile("(?i)\\[.*?(helper|mod|admin|manager|dev|staff|owner).*?\\]");

    private Drdonutt() {
    }

    public static boolean b(String string) {
        return "DrDonutt".equalsIgnoreCase(string);
    }

    public static boolean L(String string) {
        if (string == null) return false;
        if (string.isEmpty()) {
            return false;
        }
        String string2 = FORMATTING.matcher(string).replaceAll("").trim();
        if (ROLE.matcher(string2).find()) return true;
        if (BRACKET.matcher(string2).find()) return true;
        if (!string2.codePoints().anyMatch(Drdonutt::lmbd$marked$0)) return false;
        return true;
    }

    public static boolean n(String string, String string2, String string3, String string4, String string5) {
        if (Drdonutt.b(string)) return true;
        if (Drdonutt.L(string2)) return true;
        if (Drdonutt.L(string3)) return true;
        if (Drdonutt.L(string4)) return true;
        if (!Drdonutt.L(string5)) return false;
        return true;
    }

    private static boolean lmbd$marked$0(int n) {
        if ("\u2605\u2606\u2b50\u272a\u2726\u2727\u272f\u2730\u272c\u272d".indexOf(n) < 0) return false;
        return true;
    }
}
