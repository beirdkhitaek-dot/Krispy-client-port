package krispy.modules.donut;

import it.unimi.dsi.fastutil.longs.Long2IntMap;
import it.unimi.dsi.fastutil.longs.Long2IntMaps;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayFIFOQueue;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongCollection;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.awt.Color;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import krispy.event.ChunkDataEvent;
import krispy.event.MacroBlockUpdateEvent;
import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.event.WorldRenderEvent;
import krispy.gui.IconToast;
import krispy.module.MacroCategories;
import krispy.module.MacroSubscribe;
import krispy.module.settings.MacroBoolSetting;
import krispy.module.settings.MacroColorSetting;
import krispy.module.settings.MacroModeSetting;
import krispy.module.settings.MacroNumberSetting;
import krispy.modules.donut.Height;
import krispy.modules.donut.StackHeight;
import krispy.modules.misc.MacroModule;
import krispy.util.CachedThickness;
import krispy.util.WorldUtil2;
import krispy.util.Stacks;
import krispy.util.ChunkCandidates;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_638;

@Environment(value=EnvType.CLIENT)
public final class ChunkFinderBetter
extends MacroModule {
    private static final int PROBE_CHUNKS = 48;
    private static final byte OTHER = 0;
    private static final byte STONE = 1;
    private static final byte BLOB = 2;
    private static final byte AIR = 3;
    private static final byte MISSING = 4;
    private static int[] SIDE_X;
    private static int[] SIDE_Z;
    private static int[] CORNER_X;
    private static int[] CORNER_Z;
    private static final int MIN_Y = 0;
    private static final int MAX_Y = 32;
    private static final int CHUNK_COLOR = 0x60FFFFFF;
    private static final int OLD_CHUNK_COLOR = 1614011733;
    private final MacroModeSetting detection;
    private final MacroNumberSetting spreadRadius;
    private final MacroNumberSetting alpha;
    private final MacroColorSetting chunkColor;
    private final MacroBoolSetting outline;
    private final MacroBoolSetting rainbow;
    private final MacroBoolSetting baseMarker;
    private final MacroBoolSetting sound;
    private final CachedThickness plates;
    private final CachedThickness basePlates;
    private LongOpenHashSet baseChunks;
    private final LongOpenHashSet coloredChunks;
    private LongOpenHashSet visualSource;
    private boolean visualMarkerEnabled;
    private static Height UNDECIDED;
    private final Long2ObjectOpenHashMap<Height> flagged;
    private final LongArrayFIFOQueue queue;
    private final LongOpenHashSet queued;
    private final List<Height> fresh;
    private final Long2IntOpenHashMap heat;
    private int appliedRadius;
    private LongOpenHashSet shown;
    private boolean shownDirty;
    private int shownAge;
    private class_638 lastLevel;
    private boolean scanning;
    private StackHeight appliedConfig;
    private WeakReference<class_634> probeServer;
    private boolean probing;
    private final LongOpenHashSet probed;
    private final class_2818[] around;
    private final int[] groupX;
    private final int[] groupZ;
    private int groupSize;
    private boolean guessed;
    private class_2248 wall;
    private class_2248 lastBlock;
    private final int[] stackTop;
    private final int[] stackShape;
    private final int[] stackAreas;
    private final boolean[] stackGuessed;
    private final class_2248[] stackWall;
    private boolean sawBlob;
    private int scanX;
    private int scanZ;
    private int keepHeight;
    private long[] keptStacks;
    private int keptStackCount;
    private int tallest;
    private long bottom;
    private boolean unsure;
    public ChunkFinderBetter() {
        super("chunk-finder-better", "Chunk Finder Better", "Scans suspicious underground shafts with Calm or Aggressive detection.", MacroCategories.DONUT);
        this.detection = this.addSetting("detection", new MacroModeSetting("Detection", "Calm", "Calm", "Aggressive"));
        this.spreadRadius = this.addSetting("spread-radius", new MacroNumberSetting("Spread Radius", 1.0f, 0.0f, 16.0f).step(1.0f));
        this.alpha = this.addSetting("alpha", new MacroNumberSetting("Alpha", 96.0f, 0.0f, 255.0f).step(1.0f));
        this.chunkColor = this.addSetting("chunk-color", new MacroColorSetting("Chunk Color", 0x60FFFFFF));
        this.outline = this.addSetting("outline", new MacroBoolSetting("Outline", true));
        this.rainbow = this.addSetting("rainbow", new MacroBoolSetting("Rainbow", false));
        this.baseMarker = this.addSetting("base-marker", new MacroBoolSetting("Base Marker", true));
        this.sound = this.addSetting("sound", new MacroBoolSetting("Sound", true));
        this.plates = new CachedThickness();
        this.basePlates = new CachedThickness();
        this.baseChunks = new LongOpenHashSet();
        this.coloredChunks = new LongOpenHashSet();
        this.flagged = new Long2ObjectOpenHashMap();
        this.queue = new LongArrayFIFOQueue();
        this.queued = new LongOpenHashSet();
        this.fresh = new ArrayList<Height>();
        this.heat = new Long2IntOpenHashMap();
        this.shown = new LongOpenHashSet();
        this.shownDirty = true;
        this.probeServer = new WeakReference<class_634>(null);
        this.probed = new LongOpenHashSet();
        this.around = new class_2818[9];
        this.groupX = new int[4];
        this.groupZ = new int[4];
        this.stackTop = new int[256];
        this.stackShape = new int[256];
        this.stackAreas = new int[256];
        this.stackGuessed = new boolean[256];
        this.stackWall = new class_2248[256];
        this.keptStacks = new long[16];
        MacroBoolSetting macroBoolSetting = this.usesNotifications();
        this.sound.visibleWhen(macroBoolSetting::get);
    }

    private void N(class_638 class_6382) {
        this.baseChunks.clear();
        this.coloredChunks.clear();
        this.visualSource = null;
        this.flagged.clear();
        this.heat.clear();
        this.appliedRadius = this.spreadRadius.getInt();
        this.queue.clear();
        this.queued.clear();
        this.fresh.clear();
        this.shown = new LongOpenHashSet();
        this.shownDirty = true;
        this.shownAge = 0;
        this.lastLevel = class_6382;
        boolean bl = this.scanning = class_6382 != null && class_6382.method_27983() != class_1937.field_25180 && class_6382.method_27983() != class_1937.field_25181;
        if (!this.scanning) return;
        class_634 class_6342 = class_310.method_1551().method_1562();
        if (class_6342 != this.probeServer.get()) {
            this.probeServer = new WeakReference<class_634>(class_6342);
            this.probing = true;
            this.probed.clear();
        }
        this.appliedConfig = this.v(class_6382);
        this.j(class_6382);
    }

    private LongOpenHashSet U(class_638 class_6382) {
        Long2IntOpenHashMap long2IntOpenHashMap = new Long2IntOpenHashMap();
        for (Long2IntMap.Entry entry2 : Long2IntMaps.fastIterable((Long2IntMap)this.heat)) {
            long l = entry2.getLongKey();
            if (!WorldUtil2.isLoaded(class_6382, class_1923.method_8325((long)l), class_1923.method_8332((long)l))) continue;
            long2IntOpenHashMap.put(l, entry2.getIntValue());
        }
        Long2ObjectOpenHashMap<Stacks> stacksMap = new Long2ObjectOpenHashMap<Stacks>();
        for (Long2ObjectMap.Entry entry3 : this.flagged.long2ObjectEntrySet()) {
            Height height = (Height)entry3.getValue();
            if (!long2IntOpenHashMap.containsKey(entry3.getLongKey()) || height == null || height == UNDECIDED) continue;
            stacksMap.put(entry3.getLongKey(), new Stacks(height.stacks().length, height.height()));
        }
        this.baseChunks = ChunkCandidates.candidates((Long2IntMap)long2IntOpenHashMap, (Long2ObjectMap<Stacks>)stacksMap);
        return this.appliedRadius == 0 ? new LongOpenHashSet((LongCollection)long2IntOpenHashMap.keySet()) : ChunkFinderBetter.e(long2IntOpenHashMap);
    }

    @Subscribe
    public void onWorldRender(WorldRenderEvent worldRenderEvent) {
        if (class_310.method_1551().field_1687 == null) return;
        int n = this.alpha.getInt();
        if (n <= 0) {
            return;
        }
        boolean bl = this.baseMarker.get();
        if (this.visualSource != this.shown || this.visualMarkerEnabled != bl) {
            this.coloredChunks.clear();
            this.coloredChunks.addAll((LongCollection)this.shown);
            if (bl) {
                this.coloredChunks.removeAll((LongCollection)this.baseChunks);
            }
            this.visualSource = this.shown;
            this.visualMarkerEnabled = bl;
        }
        int n2 = this.rainbow.get() ? ChunkCandidates.rainbowRgb(System.nanoTime()) : this.chunkColor.argb() & 0xFFFFFF;
        Color color = this.outline.get() ? new Color(Math.min(220, n + 45) << 24 | n2, true) : null;
        this.plates.draw(worldRenderEvent, (LongSet)this.coloredChunks, new Color(n << 24 | n2, true), color, 1.5f);
        if (!bl) return;
        Color color2 = this.outline.get() ? new Color(255, 92, 92, Math.min(220, n + 45)) : null;
        this.basePlates.draw(worldRenderEvent, (LongSet)this.baseChunks, new Color(255, 48, 55, n), color2, 1.5f);
    }

    @Override
    public void onEnable() {
        this.N(class_310.method_1551().field_1687);
    }

    @Override
    public void onDisable() {
        this.N(null);
    }

    private StackHeight v(class_638 class_6382) {
        return new StackHeight(Math.max(0, class_6382.method_31607()), Math.min(32, class_6382.method_31600()), this.detection.is("Aggressive") ? 3 : 2);
    }

    private void j(class_638 class_6382) {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1724 == null) return;
        int n = (Integer)class_3102.field_1690.method_42503().method_41753() + 1;
        class_1923 class_19232 = class_3102.field_1724.method_31476();
        for (int i = class_19232.field_9181 - n; i <= class_19232.field_9181 + n; ++i) {
            for (int j = class_19232.field_9180 - n; j <= class_19232.field_9180 + n; ++j) {
                if (!WorldUtil2.isLoaded(class_6382, i, j)) continue;
                this.u(class_1923.method_8331((int)i, (int)j));
            }
        }
    }

    private void u(long l) {
        if (!this.scanning || !this.queued.add(l)) return;
        this.queue.enqueue(l);
    }

    @Subscribe
    public void onChunkData(ChunkDataEvent chunkDataEvent) {
        this.shownDirty = true;
        int n = chunkDataEvent.packet.method_11523();
        int n2 = chunkDataEvent.packet.method_11524();
        for (int i = -1; i <= 1; ++i) {
            for (int j = -1; j <= 1; ++j) {
                this.u(class_1923.method_8331((int)(n + i), (int)(n2 + j)));
            }
        }
    }

    @MacroSubscribe
    public void onMacroBlockUpdate(MacroBlockUpdateEvent macroBlockUpdateEvent) {
        int n;
        if (!this.scanning || macroBlockUpdateEvent.pos == null || (n = macroBlockUpdateEvent.pos.method_10264()) < this.appliedConfig.minY() - 1 || n > this.appliedConfig.maxY() + 1 || !ChunkFinderBetter.O(macroBlockUpdateEvent.oldState) && !ChunkFinderBetter.O(macroBlockUpdateEvent.newState)) return;
        int n2 = macroBlockUpdateEvent.pos.method_10263();
        int n3 = macroBlockUpdateEvent.pos.method_10260();
        for (int i = n2 - 2 >> 4; i <= n2 + 1 >> 4; ++i) {
            for (int j = n3 - 2 >> 4; j <= n3 + 2 >> 4; ++j) {
                this.u(class_1923.method_8331((int)i, (int)j));
            }
        }
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        int n;
        class_638 class_6382 = class_310.method_1551().field_1687;
        if (class_6382 != this.lastLevel) {
            this.N(class_6382);
        }
        if (!this.scanning) return;
        StackHeight stackHeight = this.v(class_6382);
        if (!stackHeight.equals(this.appliedConfig)) {
            this.appliedConfig = stackHeight;
            this.j(class_6382);
        }
        if ((n = this.spreadRadius.getInt()) != this.appliedRadius) {
            this.appliedRadius = n;
            this.shownDirty = true;
            this.heat.clear();
            ObjectIterator objectIterator = this.flagged.long2ObjectEntrySet().fastIterator();
            while (objectIterator.hasNext()) {
                Long2ObjectMap.Entry entry = (Long2ObjectMap.Entry)objectIterator.next();
                this.I(entry.getLongKey(), (Height)entry.getValue(), 1);
            }
        }
        long l = System.nanoTime() + 3000000L;
        while (!this.queue.isEmpty() && System.nanoTime() < l) {
            int n2;
            long l2 = this.queue.dequeueLong();
            this.queued.remove(l2);
            int n3 = class_1923.method_8325((long)l2);
            if (!WorldUtil2.isLoaded(class_6382, n3, n2 = class_1923.method_8332((long)l2))) continue;
            Height height = this.t(class_6382, n3, n2, stackHeight);
            if (this.sawBlob) {
                this.X(l2);
            }
            if (height == UNDECIDED) continue;
            Height height2 = (Height)this.flagged.get(l2);
            if (!(height == null ? height2 != null : height2 == null || !height2.sameAs(height))) continue;
            this.d(l2, height2, height);
            if (height2 != null) continue;
            this.fresh.add(height);
        }
        this.K(this.fresh);
        this.fresh.clear();
        if (!this.shownDirty && ++this.shownAge < 20) return;
        this.shown = this.U(class_6382);
        this.shownDirty = false;
        this.shownAge = 0;
    }

    private void d(long l, Height height, Height height2) {
        this.shownDirty = true;
        if (height != null) {
            this.I(l, height, -1);
        }
        if (height2 == null) {
            this.flagged.remove(l);
            return;
        } else {
            this.flagged.put(l, height2);
            this.I(l, height2, 1);
        }
    }

    private void I(long l, Height height, int n) {
        int n2 = n * height.stacks().length;
        int n3 = this.appliedRadius;
        int n4 = class_1923.method_8325((long)l);
        int n5 = class_1923.method_8332((long)l);
        for (int i = n4 - n3; i <= n4 + n3; ++i) {
            for (int j = n5 - n3; j <= n5 + n3; ++j) {
                long l2 = class_1923.method_8331((int)i, (int)j);
                if (this.heat.addTo(l2, n2) + n2 != 0) continue;
                this.heat.remove(l2);
            }
        }
    }

    private static LongOpenHashSet e(Long2IntOpenHashMap long2IntOpenHashMap) {
        LongOpenHashSet longOpenHashSet = new LongOpenHashSet();
        LongOpenHashSet longOpenHashSet2 = new LongOpenHashSet();
        LongArrayList longArrayList = new LongArrayList();
        LongArrayFIFOQueue longArrayFIFOQueue = new LongArrayFIFOQueue();
        LongIterator longIterator = long2IntOpenHashMap.keySet().iterator();
        while (longIterator.hasNext()) {
            long l = longIterator.next();
            if (!longOpenHashSet2.add(l)) continue;
            longArrayList.clear();
            longArrayFIFOQueue.enqueue(l);
            int n = 0;
            while (!longArrayFIFOQueue.isEmpty()) {
                long l2 = longArrayFIFOQueue.dequeueLong();
                longArrayList.add(l2);
                n = Math.max(n, long2IntOpenHashMap.get(l2));
                int n2 = class_1923.method_8325((long)l2);
                int n3 = class_1923.method_8332((long)l2);
                for (int i = 0; i < 4; ++i) {
                    long l3 = class_1923.method_8331((int)(n2 + SIDE_X[i]), (int)(n3 + SIDE_Z[i]));
                    if (!long2IntOpenHashMap.containsKey(l3) || !longOpenHashSet2.add(l3)) continue;
                    longArrayFIFOQueue.enqueue(l3);
                }
            }
            for (int i = 0; i < longArrayList.size(); ++i) {
                if (long2IntOpenHashMap.get(longArrayList.getLong(i)) != n) continue;
                longOpenHashSet.add(longArrayList.getLong(i));
            }
        }
        return longOpenHashSet;
    }

    private Height t(class_638 class_6382, int n, int n2, StackHeight stackHeight) {
        for (int i = -1; i <= 1; ++i) {
            for (int j = -1; j <= 1; ++j) {
                this.around[(i + 1) * 3 + j + 1] = class_6382.method_2935().method_21730(n + i, n2 + j);
            }
        }
        this.sawBlob = false;
        this.scanX = n << 4;
        this.scanZ = n2 << 4;
        this.keepHeight = stackHeight.stackHeight();
        this.keptStackCount = 0;
        this.tallest = 0;
        this.bottom = 0L;
        this.unsure = false;
        try {
            int n3;
            class_2818 class_28182 = this.around[4];
            class_2826[] class_2826Array = class_28182.method_12006();
            int n4 = class_28182.method_32891();
            Arrays.fill(this.stackTop, Integer.MIN_VALUE);
            boolean bl = true;
            for (n3 = 0; n3 < class_2826Array.length; ++n3) {
                int n5;
                class_2826 class_28262 = class_2826Array[n3];
                if (class_28262 == null || class_28262.method_38292() || (n5 = n4 + n3 << 4) + 15 < stackHeight.minY() || n5 > stackHeight.maxY()) continue;
                int n6 = Math.max(stackHeight.minY() - n5, 0);
                int n7 = Math.min(stackHeight.maxY() - n5, 15);
                if (bl) {
                    boolean bl2 = bl = !ChunkFinderBetter.m(class_28262, n6, n7);
                }
                if (!class_28262.method_19523(ChunkFinderBetter::lmbd$scan$0) || !class_28262.method_19523(ChunkFinderBetter::lmbd$scan$1)) continue;
                for (int i = n6; i <= n7; ++i) {
                    for (int j = 0; j < 16; ++j) {
                        boolean bl3 = false;
                        for (int k = 0; k < 16; ++k) {
                            boolean bl4;
                            class_2248 class_22482 = class_28262.method_12254(k, i, j).method_26204();
                            boolean bl5 = bl4 = class_22482 == class_2246.field_10340;
                            if (bl4) {
                                if (!bl3 && this.P(k, n5 + i, j)) {
                                    this.p(k, n5 + i, j);
                                }
                            } else if (this.probing && ChunkFinderBetter.g(class_22482)) {
                                this.sawBlob = true;
                                if (this.q(k, n5 + i, j)) {
                                    this.probing = false;
                                    this.probed.clear();
                                }
                            }
                            bl3 = bl4;
                        }
                    }
                }
            }
            for (n3 = 0; n3 < 256; ++n3) {
                this.Q(n3);
            }
            if (this.tallest >= stackHeight.stackHeight()) {
                Height height = new Height(this.bottom, this.tallest, Arrays.copyOf(this.keptStacks, this.keptStackCount));
                return height;
            }
            Height height = !this.unsure && !bl ? null : UNDECIDED;
            return height;
        }
        finally {
            Arrays.fill(this.around, null);
        }
    }

    private void p(int n, int n2, int n3) {
        boolean bl;
        int n4 = n3 << 4 | n;
        int n5 = this.B(n, n3);
        boolean bl2 = bl = this.stackTop[n4] == n2 - 1 && this.stackShape[n4] == n5 && this.stackWall[n4] == this.wall;
        if (!bl) {
            this.Q(n4);
        }
        this.stackTop[n4] = n2;
        this.stackShape[n4] = n5;
        this.stackWall[n4] = this.wall;
        this.stackAreas[n4] = bl ? this.stackAreas[n4] + 1 : 1;
        this.stackGuessed[n4] = this.guessed || bl && this.stackGuessed[n4];
    }

    private void Q(int n) {
        int n2;
        int n3 = this.stackAreas[n];
        int n4 = this.stackTop[n];
        if (n4 == Integer.MIN_VALUE || n3 < this.keepHeight || !this.J(n & 0xF, n4 + 1, n >> 4, n2 = this.stackShape[n]) || !this.J(n & 0xF, n4 - n3, n >> 4, n2)) return;
        if (this.stackGuessed[n]) {
            this.unsure = true;
            return;
        } else {
            int n5 = this.scanX + (n & 0xF);
            int n6 = this.scanZ + (n >> 4);
            long l = class_2338.method_10064((int)n5, (int)(n4 - n3 + 1), (int)n6);
            if (n3 > this.tallest || n3 == this.tallest && ChunkFinderBetter.b(l, this.bottom)) {
                this.tallest = n3;
                this.bottom = l;
            }
            if (this.keptStackCount == this.keptStacks.length) {
                this.keptStacks = Arrays.copyOf(this.keptStacks, this.keptStacks.length * 2);
            }
            this.keptStacks[this.keptStackCount++] = l;
        }
    }

    private boolean J(int n, int n2, int n3, int n4) {
        for (int i = 0; i < 6; ++i) {
            if ((n4 >> i & 1) == 0) continue;
            this.i(n + i / 3, n2, n3 + i % 3 - 1);
            if (ChunkFinderBetter.f(this.lastBlock)) continue;
            return false;
        }
        return true;
    }

    private static boolean b(long l, long l2) {
        if (class_2338.method_10071((long)l) != class_2338.method_10071((long)l2)) {
            if (class_2338.method_10071((long)l) >= class_2338.method_10071((long)l2)) return false;
            return true;
        }
        if (class_2338.method_10083((long)l) != class_2338.method_10083((long)l2)) {
            if (class_2338.method_10083((long)l) >= class_2338.method_10083((long)l2)) return false;
            return true;
        }
        if (class_2338.method_10061((long)l) >= class_2338.method_10061((long)l2)) return false;
        return true;
    }

    private int B(int n, int n2) {
        int n3 = 0;
        for (int i = 0; i < this.groupSize; ++i) {
            n3 |= 1 << (this.groupX[i] - n) * 3 + this.groupZ[i] - n2 + 1;
        }
        return n3;
    }

    private boolean P(int n, int n2, int n3) {
        int n4;
        int n5;
        int n6;
        int n7;
        this.guessed = false;
        this.wall = null;
        if (this.F(n - 1, n2, n3) != 2 || !this.w() || this.F(n, n2, n3 - 1) != 2 || !this.w()) return false;
        this.groupX[0] = n;
        this.groupZ[0] = n3;
        int n8 = 1;
        int n9 = n;
        int n10 = n3;
        int n11 = n3;
        for (n7 = 0; n7 < n8; ++n7) {
            for (n6 = 0; n6 < 4; ++n6) {
                n5 = this.groupX[n7] + SIDE_X[n6];
                n4 = this.groupZ[n7] + SIDE_Z[n6];
                if (this.E(n5, n4, n8)) continue;
                byte by = this.F(n5, n2, n4);
                if (by == 2) {
                    if (this.w()) continue;
                    return false;
                }
                if (by != 1) {
                    return false;
                }
                if (n5 < n || n5 == n && n4 < n3) {
                    return false;
                }
                n9 = Math.max(n9, n5);
                n10 = Math.min(n10, n4);
                n11 = Math.max(n11, n4);
                if (n9 - n > 1 || n11 - n10 > 1) {
                    return false;
                }
                this.groupX[n8] = n5;
                this.groupZ[n8] = n4;
                ++n8;
            }
        }
        for (n7 = 0; n7 < n8; ++n7) {
            for (n6 = 0; n6 < 4; ++n6) {
                n5 = this.groupX[n7] + CORNER_X[n6];
                n4 = this.groupZ[n7] + CORNER_Z[n6];
                if (this.E(n5, n4, n8) || this.F(n5, n2, n4) == 2 && this.w()) continue;
                return false;
            }
        }
        for (n7 = 0; n7 < n8; ++n7) {
            if (this.i(this.groupX[n7], n2 + 1, this.groupZ[n7]) != 3 && this.i(this.groupX[n7], n2 - 1, this.groupZ[n7]) != 3) continue;
            return false;
        }
        this.groupSize = n8;
        return true;
    }

    private boolean E(int n, int n2, int n3) {
        for (int i = 0; i < n3; ++i) {
            if (this.groupX[i] != n || this.groupZ[i] != n2) continue;
            return true;
        }
        return false;
    }

    private byte F(int n, int n2, int n3) {
        byte by = this.i(n, n2, n3);
        if (by != 4) {
            return by;
        }
        this.guessed = true;
        return 2;
    }

    private boolean w() {
        if (this.lastBlock == null) {
            return true;
        }
        if (this.wall == null) {
            this.wall = this.lastBlock;
        }
        if (this.lastBlock != this.wall) return false;
        return true;
    }

    private byte i(int n, int n2, int n3) {
        class_2818 class_28182 = this.around[((n >> 4) + 1) * 3 + (n3 >> 4) + 1];
        this.lastBlock = null;
        if (class_28182 == null) {
            return 4;
        }
        int n4 = class_28182.method_31602(n2);
        if (n4 < 0 || n4 >= class_28182.method_32890()) return 0;
        class_2680 class_26802 = class_28182.method_38259(n4).method_12254(n & 0xF, n2 & 0xF, n3 & 0xF);
        this.lastBlock = class_26802.method_26204();
        return ChunkFinderBetter.a(class_26802);
    }

    private boolean q(int n, int n2, int n3) {
        if (!this.s(n + 1, n2, n3)) return false;
        if (!this.s(n - 1, n2, n3)) return false;
        if (!this.s(n, n2, n3 + 1)) return false;
        if (!this.s(n, n2, n3 - 1)) return false;
        if (!this.s(n, n2 + 1, n3)) return false;
        if (!this.s(n, n2 - 1, n3)) return false;
        return true;
    }

    private boolean s(int n, int n2, int n3) {
        class_2818 class_28182 = this.around[((n >> 4) + 1) * 3 + (n3 >> 4) + 1];
        if (class_28182 == null) {
            return false;
        }
        int n4 = class_28182.method_31602(n2);
        if (n4 < 0) return false;
        if (n4 >= class_28182.method_32890()) return false;
        if (!class_28182.method_38259(n4).method_12254(n & 0xF, n2 & 0xF, n3 & 0xF).method_26216()) return false;
        return true;
    }

    private static boolean m(class_2826 class_28262, int n, int n2) {
        if (!class_28262.method_19523(ChunkFinderBetter::lmbd$hasBlocks$0)) {
            return false;
        }
        for (int i = n; i <= n2; ++i) {
            for (int j = 0; j < 16; ++j) {
                for (int k = 0; k < 16; ++k) {
                    if (class_28262.method_12254(k, i, j).method_26215()) continue;
                    return true;
                }
            }
        }
        return false;
    }

    private static byte a(class_2680 class_26802) {
        class_2248 class_22482 = class_26802.method_26204();
        if (class_22482 == class_2246.field_10340) {
            return 1;
        }
        if (ChunkFinderBetter.g(class_22482)) {
            return 2;
        }
        if (!class_26802.method_26215()) return 0;
        return 3;
    }

    private static boolean g(class_2248 class_22482) {
        if (class_22482 == class_2246.field_10508) return true;
        if (class_22482 == class_2246.field_10115) return true;
        if (class_22482 == class_2246.field_10474) return true;
        if (class_22482 != class_2246.field_10255) return false;
        return true;
    }

    private static boolean f(class_2248 class_22482) {
        if (class_22482 == class_2246.field_10340) return true;
        if (class_22482 != class_2246.field_28888) return false;
        return true;
    }

    private static boolean O(class_2680 class_26802) {
        if (class_26802 == null) return false;
        if (ChunkFinderBetter.a(class_26802) != 0) return true;
        if (!ChunkFinderBetter.f(class_26802.method_26204())) return false;
        return true;
    }

    private void X(long l) {
        if (!this.probing || !this.probed.add(l) || this.probed.size() < 48) return;
        this.probing = false;
        this.probed.clear();
        class_638 class_6382 = class_310.method_1551().field_1687;
        if (class_6382 == null || class_310.method_1551().field_1724 == null) return;
        class_310.method_1551().field_1724.method_7353((class_2561)class_2561.method_43470((String)"Krispy: This server hides ores with anti-xray; patched shafts may not be visible."), false);
    }

    private void K(List<Height> list) {
        if (!this.notificationsOn() || list.isEmpty()) return;
        Height height = list.get(0);
        IconToast.show(class_2338.method_10061((long)height.pos()), class_2338.method_10083((long)height.pos()), this.sound.get());
    }

    private static boolean lmbd$hasBlocks$0(class_2680 class_26802) {
        if (class_26802.method_26215()) return false;
        return true;
    }

    private static boolean lmbd$scan$1(class_2680 class_26802) {
        return ChunkFinderBetter.g(class_26802.method_26204());
    }

    private static boolean lmbd$scan$0(class_2680 class_26802) {
        return class_26802.method_27852(class_2246.field_10340);
    }

    static {
        SIDE_X = new int[]{1, -1, 0, 0};
        SIDE_Z = new int[]{0, 0, 1, -1};
        CORNER_X = new int[]{1, 1, -1, -1};
        CORNER_Z = new int[]{1, -1, 1, -1};
        UNDECIDED = new Height(0L, 0, new long[0]);
    }
}
