package krispy.modules.combat;

import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.NumberSetting;
import krispy.util.SecureString;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

public final class AutoTotem
extends Module {
    private static String[] a;
    private final NumberSetting delay = new NumberSetting(SecureString.of("Delay"), 0.0, 5.0, 1.0, 1.0);
    private int delayCounter;

    public AutoTotem() {
        super(SecureString.of("Auto Totem"), SecureString.of("Automatically holds totem in your off hand"), -1, Category.COMBAT);
        this.addSettings(this.delay);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1724 == null || this.mc.field_1761 == null) return;
        if (this.mc.field_1724.method_31548().method_5438(40).method_7909() == class_1802.field_8288) {
            this.delayCounter = this.delay.getIntValue();
            return;
        } else if (this.delayCounter > 0) {
            --this.delayCounter;
            return;
        } else {
            int n = this.l(class_1802.field_8288);
            if (n == -1) return;
            this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, AutoTotem.H(n), 40, class_1713.field_7791, (class_1657)this.mc.field_1724);
            this.delayCounter = this.delay.getIntValue();
        }
    }

    public int l(class_1792 class_17922) {
        if (this.mc.field_1724 == null) {
            return -1;
        }
        for (int i = 0; i < 36; ++i) {
            if (!this.mc.field_1724.method_31548().method_5438(i).method_31574(class_17922)) continue;
            return i;
        }
        return -1;
    }

    private static int H(int n) {
        return n < 9 ? 36 + n : n;
    }

    static {
        a = new String[]{"Automatically holds totem in your off hand", "Delay", "Auto Totem"};
    }
}
