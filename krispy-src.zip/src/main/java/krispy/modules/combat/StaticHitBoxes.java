package krispy.modules.combat;

import krispy.event.GetPoseEvent;
import krispy.event.Subscribe;
import krispy.module.Category;
import krispy.module.Module;
import krispy.util.SecureString;
import net.minecraft.class_1657;
import net.minecraft.class_4050;

public final class StaticHitBoxes
extends Module {
    private static String[] a;
    public StaticHitBoxes() {
        super(SecureString.of("Static HitBoxes"), SecureString.of("Expands a Player's Hitbox"), -1, Category.COMBAT);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onGetPose(GetPoseEvent getPoseEvent) {
        if (!this.isEnabled() || !(getPoseEvent.entity instanceof class_1657) || ((class_1657)getPoseEvent.entity).method_7340()) return;
        getPoseEvent.cir.setReturnValue(class_4050.field_18076);
    }

    static {
        a = new String[]{"Expands a Player's Hitbox", "Static HitBoxes"};
    }
}
