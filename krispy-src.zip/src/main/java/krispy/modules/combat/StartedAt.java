package krispy.modules.combat;

class StartedAt {
    public final long startedAt;
    public final long duration;

    public StartedAt(long startedAt, long duration) {
        this.startedAt = startedAt;
        this.duration = duration;
    }

    public long startedAt() {
        return this.startedAt;
    }

    public long duration() {
        return this.duration;
    }
}
