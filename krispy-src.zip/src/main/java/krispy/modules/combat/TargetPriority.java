package krispy.modules.combat;

import java.util.Comparator;
import java.util.List;
import krispy.client.KrispyClient;
import krispy.module.Module;
import krispy.modules.combat.KillAura;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_634;
import net.minecraft.class_746;

final class TargetPriority {
    private static String[] a;
    private TargetPriority() {
    }

    static float X() {
        class_746 class_7462 = class_310.method_1551().field_1724;
        if (class_7462 == null) {
            return 0.0f;
        }
        float f = class_7462.method_36454();
        return f;
    }

    static float D() {
        class_746 class_7462 = class_310.method_1551().field_1724;
        if (class_7462 == null) {
            return 0.0f;
        }
        float f = class_7462.method_36455();
        return f;
    }

    static void j(float f, float f2) {
        class_746 class_7462 = class_310.method_1551().field_1724;
        if (class_7462 == null || !Float.isFinite(f) || !Float.isFinite(f2)) return;
        class_7462.method_36456(f);
        class_7462.method_36457(class_3532.method_15363((float)f2, -90.0f, 90.0f));
    }

    static class_243 k(float f, float f2) {
        return class_243.method_1030((float)f, (float)f2);
    }

    static boolean E(class_1297 class_12972) {
        if (class_12972 != class_310.method_1551().field_1724) return false;
        return true;
    }

    static boolean L(class_1309 class_13092) {
        class_634 class_6342 = class_310.method_1551().method_1562();
        if (!(class_13092 instanceof class_1657)) return false;
        class_1657 class_16572 = (class_1657)class_13092;
        if (class_6342 == null) return false;
        if (class_6342.method_2871(class_16572.method_5667()) != null) return false;
        return true;
    }

    static class_1309 u(List<class_1309> list, class_1657 class_16572) {
        KillAura maxTurnSpeed;
        Module module;
        boolean bl = KrispyClient.INSTANCE.getModuleManager() != null && (module = KrispyClient.INSTANCE.getModuleManager().getModuleByClass(KillAura.class)) instanceof KillAura && (maxTurnSpeed = (KillAura)module).getSetting("Target Priority", "Nearest").equals("Lowest Health");
        return list.stream().min(bl ? Comparator.comparingDouble(class_1309::method_6032).thenComparingDouble(arg_0 -> ((class_1657)class_16572).method_5858(arg_0)) : Comparator.comparingDouble(arg_0 -> ((class_1657)class_16572).method_5858(arg_0))).orElse(null);
    }

    static {
        a = new String[]{"Target Priority", "Lowest Health", "Nearest"};
    }
}
