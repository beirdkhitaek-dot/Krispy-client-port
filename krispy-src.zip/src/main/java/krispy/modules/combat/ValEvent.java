package krispy.modules.combat;

import krispy.event.PacketSendEvent;
import krispy.modules.combat.AutoCrystal;
import net.minecraft.class_1268;
import net.minecraft.class_243;
import net.minecraft.class_2824;

class ValEvent
implements class_2824.class_5908 {
    final PacketSendEvent val$event;

    ValEvent(AutoCrystal autoCrystal, PacketSendEvent packetSendEvent) {
        this.val$event = packetSendEvent;
    }

    public void method_34219(class_1268 class_12682) {
    }

    public void method_34220(class_1268 class_12682, class_243 class_2432) {
    }

    public void method_34218() {
        this.val$event.cancel();
    }
}
