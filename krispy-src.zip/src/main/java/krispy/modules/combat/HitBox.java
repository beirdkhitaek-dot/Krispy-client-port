package krispy.modules.combat;

import krispy.event.LookEvent;
import krispy.event.Subscribe;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.Setting;
import net.minecraft.class_1657;

public final class HitBox
extends Module {
    private static String[] a;
    private final NumberSetting expansion = new NumberSetting("Expansion", 0.0, 2.0, 0.5, 0.05);
    private final BoolSetting renderExpansion = new BoolSetting("Render Expansion", true);

    public HitBox() {
        super("HitBox", "Expands a player's targeting hitbox.", -1, Category.COMBAT);
        this.addSettings(new Setting[]{this.expansion, this.renderExpansion});
    }

    @Subscribe
    public void onLook(LookEvent lookEvent) {
        if (!(lookEvent.entity instanceof class_1657)) return;
        lookEvent.cir.setReturnValue(Float.valueOf((float)this.expansion.getValue()));
    }

    public double m() {
        if (!this.renderExpansion.getValue()) return 0.0;
        double d = this.expansion.getValue();
        return d;
    }

    public double q(Object[] objectArray) {
        return this.m();
    }

    static {
        a = new String[]{"Expansion", "HitBox", "Expands a player's targeting hitbox.", "Render Expansion"};
    }
}
