package krispy.modules.combat;

public enum Nearest {
    Nearest,
    Named;

}
