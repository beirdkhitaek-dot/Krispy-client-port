package krispy.modules.combat;

import krispy.event.EntityStatusEvent;
import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.CycleSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.Setting;
import krispy.module.settings.SettingGroup;
import krispy.modules.combat.Always;
import krispy.util.HotbarUtil;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2596;
import net.minecraft.class_2846;

public final class TotemOffhand
extends Module {
    private static String[] a;
    private final CycleSetting<Always> equipMode = new CycleSetting<Always>("Equip Mode", Always.ALWAYS, Always.class);
    private boolean pendingPop;
    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0.0, 5.0, 0.0, 1.0);
    private final NumberSetting equipDelay = new NumberSetting("Equip Delay", 1.0, 5.0, 1.0, 1.0);
    private final NumberSetting healthThreshold;
    private final BoolSetting switchBack = new BoolSetting("Switch Back", false);
    private final BoolSetting healthCheck = new BoolSetting("Health Check", false);
    private int remainingTicks;
    private int previousSlot = -1;
    private boolean active;
    private boolean equipWaiting;
    private boolean swapped;

    @Subscribe
    public void onEntityStatus(EntityStatusEvent entityStatusEvent) {
        this.pendingPop = true;
    }

    public TotemOffhand() {
        super("Totem Offhand", "Equips a hotbar totem in your offhand with configurable delays.", -1, Category.COMBAT);
        this.healthThreshold = new NumberSetting("Health Threshold", 2.0, 20.0, 2.0, 0.5);
        this.addSettings(new Setting[]{this.equipMode, this.switchDelay, this.equipDelay, this.switchBack, this.healthCheck, this.healthThreshold});
        SettingGroup.set(this.healthThreshold, this.healthCheck::getValue);
    }

    @Override
    public void onEnable() {
        this.B();
        this.pendingPop = false;
    }

    private void B() {
        this.remainingTicks = 0;
        this.previousSlot = -1;
        this.swapped = false;
        this.equipWaiting = false;
        this.active = false;
    }

    @Override
    public void onDisable() {
        this.B();
        this.pendingPop = false;
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1724 == null || this.mc.method_1562() == null) {
            this.B();
            this.pendingPop = false;
            return;
        }
        if (this.mc.field_1755 != null) {
            return;
        }
        if (this.remainingTicks > 0) {
            --this.remainingTicks;
            return;
        }
        if (!this.active) {
            if (this.equipMode.getValue() == Always.ON_POP && !this.pendingPop) {
                return;
            }
            if (this.mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {
                return;
            }
            if (this.healthCheck.getValue() && (double)this.mc.field_1724.method_6032() > this.healthThreshold.getValue()) {
                return;
            }
            this.B();
            this.active = true;
            this.remainingTicks = this.switchDelay.getIntValue();
            return;
        }
        if (this.previousSlot == -1) {
            this.previousSlot = this.mc.field_1724.method_31548().method_67532();
        }
        if (!this.swapped && !HotbarUtil.selectHotbarItem(class_1802.field_8288)) {
            this.B();
            return;
        }
        if (!this.equipWaiting) {
            this.remainingTicks = this.equipDelay.getIntValue();
            this.equipWaiting = true;
            return;
        }
        if (!this.swapped) {
            this.mc.method_1562().method_48296().method_10743((class_2596)new class_2846(class_2846.class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
            this.swapped = true;
            this.pendingPop = false;
            if (this.switchBack.getValue()) {
                this.remainingTicks = this.switchDelay.getIntValue();
                return;
            }
            this.B();
            return;
        }
        if (this.previousSlot != -1) {
            HotbarUtil.selectHotbarSlot(this.previousSlot);
        }
        this.B();
    }

    static {
        a = new String[]{"Health Check", "Switch Back", "Totem Offhand", "Equips a hotbar totem in your offhand with configurable delays.", "Equip Delay", "Switch Delay", "Health Threshold", "Equip Mode"};
    }
}
