package krispy.modules.combat;

import java.util.LinkedHashMap;
import java.util.UUID;
import java.util.function.LongSupplier;
import krispy.modules.combat.StartedAt;

public final class Generation {
    private static final long DAMAGE_WINDOW = 10000000000L;
    private final LongSupplier clock;
    private final LinkedHashMap<UUID, Long> ownDamage = new LinkedHashMap();
    private static final StartedAt INACTIVE = new StartedAt(0L, 0L);
    private volatile StartedAt window = INACTIVE;
    private long generation;

    public Generation() {
        this(System::nanoTime);
    }

    public Generation(LongSupplier longSupplier) {
        this.clock = longSupplier;
    }

    public synchronized void E(UUID uUID, boolean bl) {
        this.B(this.generation, uUID, bl);
    }

    public synchronized long c() {
        return this.generation;
    }

    public synchronized void B(long l, UUID uUID, boolean bl) {
        if (l != this.generation) {
            return;
        }
        long l2 = this.clock.getAsLong();
        this.ownDamage.remove(uUID);
        if (bl) {
            this.ownDamage.put(uUID, l2);
        }
        if (this.ownDamage.size() <= 64) return;
        this.ownDamage.remove(this.ownDamage.keySet().iterator().next());
    }

    public synchronized boolean D(UUID uUID, double d) {
        return this.u(this.generation, uUID, d);
    }

    public synchronized boolean u(long l, UUID uUID, double d) {
        if (l != this.generation) {
            return false;
        }
        Long l2 = (Long)this.ownDamage.remove(uUID);
        long l3 = this.clock.getAsLong();
        if (l2 == null || l3 - l2 > 10000000000L || !Double.isFinite(d) || d <= 0.0) {
            return false;
        }
        this.window = new StartedAt(l3, (long)(Math.min(30.0, d) * 1.0E9));
        return true;
    }

    public boolean k() {
        StartedAt startedAt = this.window;
        if (startedAt.duration <= 0L) return false;
        if (this.clock.getAsLong() - startedAt.startedAt >= startedAt.duration) return false;
        return true;
    }

    public synchronized void m() {
        ++this.generation;
        this.ownDamage.clear();
        this.window = INACTIVE;
    }

    public synchronized void r(long l) {
        if (this.generation != l) return;
        this.m();
    }
}
