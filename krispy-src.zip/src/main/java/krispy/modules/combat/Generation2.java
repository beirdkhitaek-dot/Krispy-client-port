package krispy.modules.combat;

import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_638;

class Generation2 {
    public final class_638 world;
    public final class_1657 player;
    public final int localId;
    public final Map<Integer, UUID> opponents;
    public final long generation;
    public final double seconds;

    public Generation2(class_638 world, class_1657 player, int localId, Map<Integer, UUID> opponents, long generation, double seconds) {
        this.world = world;
        this.player = player;
        this.localId = localId;
        this.opponents = opponents;
        this.generation = generation;
        this.seconds = seconds;
    }

    public class_638 world() {
        return this.world;
    }

    public class_1657 player() {
        return this.player;
    }

    public int localId() {
        return this.localId;
    }

    public Map<Integer, UUID> opponents() {
        return this.opponents;
    }

    public long generation() {
        return this.generation;
    }

    public double seconds() {
        return this.seconds;
    }
}
