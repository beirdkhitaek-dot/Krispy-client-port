package krispy.modules.combat;

import krispy.modules.combat.CrystalOptimizer;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_310;
import net.minecraft.class_638;

final class EntityID
implements class_2824.class_5908 {
    private final CrystalOptimizer owner;
    private final int entityId;

    EntityID(CrystalOptimizer crystalOptimizer, int n) {
        this.owner = crystalOptimizer;
        this.entityId = n;
    }

    public void method_34219(class_1268 class_12682) {
    }

    public void method_34220(class_1268 class_12682, class_243 class_2432) {
    }

    public void method_34218() {
        class_310 class_3102 = this.owner.I();
        class_638 class_6382 = class_3102.field_1687;
        if (class_6382 == null) {
            return;
        }
        class_3102.execute(() -> this.lmbd$attack$0(class_3102, class_6382));
    }

    private void lmbd$attack$0(class_310 class_3102, class_638 class_6382) {
        class_1297 class_12972;
        if (!this.owner.isEnabled() || class_3102.field_1687 != class_6382 || !((class_12972 = class_6382.method_8469(this.entityId)) instanceof class_1511)) return;
        class_1511 class_15112 = (class_1511)class_12972;
        class_15112.method_31472();
    }
}
