package krispy.modules.combat;

import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.KeybindSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.Setting;
import krispy.util.PressedState;
import krispy.util.HotbarUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_3965;

public final class DoubleAnchor
extends Module {
    private static String[] a;
    private final KeybindSetting activateKey = new KeybindSetting("Activate Key", 71, false);
    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0.0, 20.0, 0.0, 1.0);
    private final NumberSetting totemSlot = new NumberSetting("Totem Slot", 1.0, 9.0, 1.0, 1.0);
    private int delayTicks;
    private int stage;
    private boolean active;
    private boolean keyHeld;

    private void e() {
        this.active = false;
        this.stage = 0;
        this.delayTicks = 0;
    }

    @Override
    public void onEnable() {
        this.e();
        this.keyHeld = false;
    }

    public DoubleAnchor() {
        super("Double Anchor", "Performs a configurable double-anchor sequence.", -1, Category.COMBAT);
        this.addSettings(new Setting[]{this.activateKey, this.switchDelay, this.totemSlot});
    }

    @Override
    public void onDisable() {
        this.e();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        class_3965 class_39652;
        class_239 class_2392;
        if (this.mc.field_1755 != null || this.mc.field_1724 == null || this.mc.field_1687 == null || this.mc.field_1761 == null || !this.J()) {
            this.e();
            return;
        }
        boolean bl = this.activateKey.getValue() != -1 && PressedState.isPressed(this.activateKey.getValue());
        boolean bl2 = bl && !this.keyHeld;
        this.keyHeld = bl;
        if (!this.active) {
            if (!bl2) {
                this.delayTicks = 0;
                return;
            }
            this.active = true;
        }
        if (!((class_2392 = this.mc.field_1765) instanceof class_3965) || this.mc.field_1687.method_8320((class_39652 = (class_3965)class_2392).method_17777()).method_27852(class_2246.field_10124)) {
            this.e();
            return;
        }
        if (this.delayTicks < this.switchDelay.getIntValue()) {
            ++this.delayTicks;
            return;
        }
        switch (this.stage) {
            case 0:
            case 4: {
                HotbarUtil.selectHotbarItem(class_1802.field_23141);
                break;
            }
            case 2:
            case 6: {
                HotbarUtil.selectHotbarItem(class_1802.field_8801);
                break;
            }
            case 1:
            case 3:
            case 7:
            case 9: {
                this.Y(class_39652);
                break;
            }
            case 5: {
                this.Y(class_39652);
                this.Y(class_39652);
                break;
            }
            case 8: {
                HotbarUtil.selectHotbarSlot(this.totemSlot.getIntValue() - 1);
                break;
            }
            case 10: {
                this.active = false;
                this.stage = 0;
                this.delayTicks = 0;
                return;
            }
        }
        ++this.stage;
        this.delayTicks = 0;
    }

    private boolean J() {
        boolean bl = false;
        boolean bl2 = false;
        for (int i = 0; i < 9; ++i) {
            class_1799 class_17992 = this.mc.field_1724.method_31548().method_5438(i);
            bl |= class_17992.method_31574(class_1802.field_23141);
            bl2 |= class_17992.method_31574(class_1802.field_8801);
        }
        if (!bl) return false;
        if (!bl2) return false;
        return true;
    }

    private void Y(class_3965 class_39652) {
        class_1269 class_12692 = this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, class_39652);
        if (!class_12692.method_23665()) return;
        this.mc.field_1724.method_6104(class_1268.field_5808);
    }

    static {
        a = new String[]{"Totem Slot", "Double Anchor", "Performs a configurable double-anchor sequence.", "Activate Key", "Switch Delay"};
    }
}
