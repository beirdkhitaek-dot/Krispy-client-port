package krispy.modules.combat;

import krispy.event.AttackEvent;
import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.ItemSetting;
import krispy.module.settings.RangeSetting;
import krispy.module.settings.Setting;
import krispy.module.settings.SettingGroup;
import krispy.util.FriendUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3966;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

public final class TriggerBot
extends Module {
    private static String[] a;
    private final BoolSetting onLeftClick = new BoolSetting("On Left Click", false);
    private final BoolSetting checkShield;
    private final BoolSetting onlyCrit;
    private final BoolSetting whileAscending;
    private final BoolSetting allEntities;
    private final BoolSetting samePlayer;
    private final BoolSetting onlyItem;
    private final RangeSetting hitDelay;
    private final ItemSetting item;
    private int cooldown;
    private final BoolSetting ignoreFriends = new BoolSetting("Ignore Friends", true).setDescription("Skip names entered in the Friends module.");

    private boolean w(int n) {
        if (GLFW.glfwGetMouseButton((long)this.mc.method_22683().method_4490(), (int)n) != 1) return false;
        return true;
    }

    private static boolean J(class_1799 class_17992) {
        if (class_17992.method_7909().method_57347().method_57832(class_9334.field_50075)) return true;
        if (!(class_17992.method_7909() instanceof class_1819)) return false;
        return true;
    }

    private boolean k(class_1657 class_16572) {
        class_243 class_2432 = this.mc.field_1724.method_73189().method_1020(class_16572.method_73189()).method_1029();
        double d = Math.toRadians(class_16572.method_36454());
        double d2 = Math.toRadians(class_16572.method_36455());
        class_243 class_2433 = new class_243(-Math.sin(d) * Math.cos(d2), -Math.sin(d2), Math.cos(d) * Math.cos(d2)).method_1029();
        if (!(class_2433.method_1026(class_2432) < 0.0)) return false;
        return true;
    }

    @Override
    public void onDisable() {
        this.cooldown = 0;
    }

    @Subscribe
    public void onAttack(AttackEvent attackEvent) {
        if (this.mc.field_1755 != null || this.w(0)) return;
        attackEvent.cancel();
    }

    public TriggerBot() {
        super("Trigger Bot", "Attacks eligible targets under your crosshair with configurable timing.", -1, Category.COMBAT);
        this.hitDelay = new RangeSetting("Hit Delay", 0.0, 20.0, 1.0, 9.0, 11.0);
        this.checkShield = new BoolSetting("Check Shield", false);
        this.onlyCrit = new BoolSetting("Only Crit", false);
        this.whileAscending = new BoolSetting("While Ascending", false);
        this.allEntities = new BoolSetting("All Entities", false);
        this.samePlayer = new BoolSetting("Same Player", false);
        this.onlyItem = new BoolSetting("Only Item", false);
        this.item = new ItemSetting("Item", class_1802.field_8162);
        this.addSettings(new Setting[]{this.ignoreFriends, this.onLeftClick, this.hitDelay, this.checkShield, this.onlyCrit, this.whileAscending, this.allEntities, this.samePlayer, this.onlyItem, this.item});
        SettingGroup.set(this.item, this.onlyItem::getValue);
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.cooldown > 0) {
            --this.cooldown;
            return;
        } else if (this.mc.field_1724 == null || this.mc.field_1761 == null) {
            this.cooldown = 0;
            return;
        } else {
            class_239 class_2392;
            if (this.mc.field_1755 != null || this.onlyItem.getValue() && this.mc.field_1724.method_6047().method_7909() != this.item.getItem() || this.onLeftClick.getValue() && !this.w(0) || (TriggerBot.J(this.mc.field_1724.method_6047()) || TriggerBot.J(this.mc.field_1724.method_6079())) && this.w(1)) return;
            if (!this.whileAscending.getValue()) {
                if (!this.mc.field_1724.method_24828() && this.mc.field_1724.method_18798().field_1351 > 0.0 && !this.mc.field_1724.method_52535() && this.mc.field_1724.method_55667().method_26204() != class_2246.field_10343) {
                    return;
                }
                if (!this.mc.field_1724.method_24828() && this.mc.field_1724.field_6017 <= 0.0) {
                    return;
                }
            }
            if (!((class_2392 = this.mc.field_1765) instanceof class_3966)) return;
            class_3966 class_39662 = (class_3966)class_2392;
            class_1297 class_12972 = class_39662.method_17782();
            if (this.s(class_12972)) {
                return;
            }
            if (this.mc.field_1724.method_6052() != null && this.samePlayer.getValue() && class_12972 != this.mc.field_1724.method_6052() || !(class_12972 instanceof class_1657) && !(class_12972 instanceof class_1642) && !this.allEntities.getValue()) return;
            if (class_12972 instanceof class_1657) {
                class_1657 class_16572 = (class_1657)class_12972;
                if (this.checkShield.getValue() && class_16572.method_6039() && !this.k(class_16572)) return;
            }
            if (this.onlyCrit.getValue() && this.mc.field_1724.field_6017 <= 0.0 || !class_12972.method_5805() || this.mc.field_1724.method_5858(class_12972) > this.mc.field_1724.method_55755() * this.mc.field_1724.method_55755()) return;
            if (this.s(class_12972)) {
                return;
            }
            this.mc.field_1761.method_2918((class_1657)this.mc.field_1724, class_12972);
            this.mc.field_1724.method_6104(class_1268.field_5808);
            this.cooldown = this.hitDelay.getRandomIntInRange();
        }
    }

    private boolean s(class_1297 class_12972) {
        if (!this.ignoreFriends.getValue()) return false;
        if (!FriendUtil.isFriend(class_12972)) return false;
        return true;
    }

    static {
        a = new String[]{"Item", "Ignore Friends", "On Left Click", "While Ascending", "Skip names entered in the Friends module.", "Hit Delay", "Only Crit", "Same Player", "All Entities", "Attacks eligible targets under your crosshair with configurable timing.", "Only Item", "Trigger Bot", "Check Shield"};
    }
}
