package krispy.modules.combat;

public enum Automatic {
    Automatic,
    Manual;

}
