package krispy.modules.macros;

import net.minecraft.class_2350;

class SwitchMapNetMinecraftUtilMathDirectionAxis {
    static final int[] $SwitchMap$net$minecraft$util$math$Direction$Axis = new int[class_2350.class_2351.values().length];

    static {
        try {
            SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction$Axis[class_2350.class_2351.field_11048.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction$Axis[class_2350.class_2351.field_11052.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
        try {
            SwitchMapNetMinecraftUtilMathDirectionAxis.$SwitchMap$net$minecraft$util$math$Direction$Axis[class_2350.class_2351.field_11051.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {

        }
    }
}
