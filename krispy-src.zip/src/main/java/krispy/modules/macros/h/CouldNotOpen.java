package krispy.modules.macros.h;

import net.minecraft.class_1792;
import java.util.function.Consumer;
import krispy.modules.macros.h.Each;
import krispy.modules.macros.h.Thread;
import krispy.modules.macros.h.Worker;
import krispy.util.KrispyClient;
import krispy.util.Root;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_7923;

@Environment(value=EnvType.CLIENT)
final class CouldNotOpen {
    static final int YOUR_ORDERS_BUTTON = 51;
    static final int ORDER_SLOTS = 45;
    private static final long OPEN_TIMEOUT_MS = 10000L;
    private static final String[] a = new String[]{"your order", "new order", "Could not open /orders.", "orders (page", "your orders", "orders", "orders", "Could not open Your Orders.", "auction", "stained_glass_pane", "your orders"};

    private CouldNotOpen() {
    }

    static boolean o(Thread thread, Worker worker, Consumer<Root> consumer) {
        worker.k();
        thread.p(150L);
        worker.T("orders");
        if (!thread.K(CouldNotOpen::q, 10000L)) {
            consumer.accept(KrispyClient.body().warn("Could not open /orders."));
            worker.k();
            return false;
        }
        String string = worker.u();
        worker.P(51, 0, class_1713.field_7790);
        if (thread.K(CouldNotOpen::b, 2500L)) {
            return true;
        }
        if (worker.h(string, 1000L)) {
            thread.p(150L);
            return true;
        }
        consumer.accept(KrispyClient.body().warn("Could not open Your Orders."));
        worker.k();
        return false;
    }

    static boolean q() {
        if (!Worker.J()) {
            return false;
        }
        String string = Each.v(Worker.m().field_1755.method_25440());
        String[] stringArray = a;
        if (string.startsWith("orders (page")) return true;
        if (string.equals("orders")) {
            return true;
        }
        stringArray = a;
        if (string.contains("your orders")) return false;
        if (string.contains("auction")) {
            return false;
        }
        if (string.contains("orders")) {
            return true;
        }
        boolean bl = Worker.B(Worker.S(51)).contains("your order");
        return bl;
    }

    static boolean b() {
        if (!Worker.J()) {
            return false;
        }
        String string = Each.v(Worker.m().field_1755.method_25440());
        if (string.contains("your orders")) return true;
        if (Worker.v(CouldNotOpen::d, 45) < 0) return false;
        return true;
    }

    static boolean d(class_1799 class_17992) {
        if (!class_17992.method_31574(class_1802.field_8871)) return false;
        if (!Worker.B(class_17992).contains("new order")) return false;
        return true;
    }

    static boolean m(class_1799 class_17992) {
        if (class_17992.method_7960()) return true;
        if (!class_7923.field_41178.method_10221((class_1792)class_17992.method_7909()).method_12832().contains("stained_glass_pane")) return false;
        return true;
    }
}
