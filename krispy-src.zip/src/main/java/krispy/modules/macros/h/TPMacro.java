package krispy.modules.macros.h;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import krispy.event.MacroPacketReceiveEvent;
import krispy.event.MacroTickEvent;
import krispy.module.MacroCategories;
import krispy.module.MacroSubscribe;
import krispy.module.settings.MacroEnchantSetting;
import krispy.module.settings.MacroModeSetting;
import krispy.module.settings.MacroNumberSetting;
import krispy.modules.macros.h.Each;
import krispy.modules.macros.h.Teleport;
import krispy.modules.misc.MacroModule;
import krispy.util.KrispyClient;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_7439;
import net.minecraft.class_746;

@Environment(value=EnvType.CLIENT)
public final class TPMacro
extends MacroModule {
    private static Pattern RATE_LIMIT;
    private static Pattern VALID_NAME;
    private final MacroModeSetting command = this.addSetting("command", new MacroModeSetting("Command", "tpa", "tpa", "tpahere"));
    private final MacroEnchantSetting target = this.addSetting("player", new MacroEnchantSetting("Player", "").hint("Player name"));
    private final MacroNumberSetting interval = this.addSetting("interval", new MacroNumberSetting("Interval (s)", 1.0f, 0.25f, 60.0f).step(0.25f));
    private final Teleport confirm = new Teleport(this);
    private volatile long holdUntil;
    private long nextAt;
    private int sent;
    private static String[] a;

    public TPMacro() {
        super("tp-macro", "TP Macro", "Sends /tpa or /tpahere to one player on a timer.", MacroCategories.DONUT_MACROS);
        this.usesNotifications();
        this.target.privateValue();
    }

    @Override
    public boolean persistEnabled() {
        return false;
    }

    @Override
    public void onEnable() {
        String string = this.target.get().trim();
        if (!VALID_NAME.matcher(string).matches()) {
            String[] stringArray = a;
            KrispyClient.send((MacroModule)this, KrispyClient.body().warn("Set a valid Player name first."));
            this.requestDisable();
            return;
        } else {
            this.confirm.E();
            this.holdUntil = 0L;
            this.nextAt = 0L;
            this.sent = 0;
            KrispyClient.send((MacroModule)this, KrispyClient.body().text("Sending ").value("/" + this.command.get() + " " + string).text(" every ").value(this.interval.formatted() + "s").text("."));
        }
    }

    @Override
    public void onDisable() {
        if (this.sent <= 0) return;
        KrispyClient.send((MacroModule)this, KrispyClient.body().text("Sent ").value(this.sent).text(this.sent == 1 ? " request." : " requests."));
    }

    @MacroSubscribe
    public void onMacroPacketReceive(MacroPacketReceiveEvent macroPacketReceiveEvent) {
        class_7439 class_74392;
        Object object = macroPacketReceiveEvent.packet;
        if (!(object instanceof class_7439) || (class_74392 = (class_7439)object).comp_763() == null || !((Matcher)(object = RATE_LIMIT.matcher(Each.B(class_74392.comp_763().getString())))).find()) return;
        try {
            this.holdUntil = System.currentTimeMillis() + (long)Math.ceil(Double.parseDouble(((Matcher)object).group(1)) * 1000.0) + 80L;
            return;
        }
        catch (NumberFormatException numberFormatException) {

        }
    }

    @MacroSubscribe
    public void onMacroTick(MacroTickEvent macroTickEvent) {
        class_310 class_3102 = class_310.method_1551();
        class_746 class_7462 = class_3102.field_1724;
        if (class_7462 == null || class_3102.method_1562() == null || class_7462.method_29504()) return;
        this.confirm.X(class_3102);
        long l = System.currentTimeMillis();
        if (l < this.nextAt || l < this.holdUntil) return;
        class_7462.field_3944.method_45730(this.command.get() + " " + this.target.get().trim());
        ++this.sent;
        this.nextAt = l + (long)(this.interval.get() * 1000.0f);
    }

    static {
        String[] stringArray = a = new String[]{"Sends /tpa or /tpahere to one player on a timer.", " every ", "\\.?[A-Za-z0-9_]{1,16}", "Interval (s)", "Sending ", " request.", "tpa", " requests.", "TP Macro", "Sent ", "Command", "command", "tpa", "Player", "you need to wait another ([\\d.]+) seconds? to execute a command", "Set a valid Player name first.", "Player name", "player", "interval", "tpahere", "tp-macro"};
        RATE_LIMIT = Pattern.compile(stringArray[14]);
        VALID_NAME = Pattern.compile(stringArray[2]);
    }
}
