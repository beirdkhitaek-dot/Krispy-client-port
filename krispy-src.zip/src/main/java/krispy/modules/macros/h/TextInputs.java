package krispy.modules.macros.h;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import krispy.modules.macros.h.Component;
import krispy.modules.macros.h.Each;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11419;
import net.minecraft.class_1799;

@Environment(value=EnvType.CLIENT)
class TextInputs {
    public final class_11419 dialog;
    public final String title;
    public final List<Component> buttons;
    public final List<String> body;
    public final List<String> textInputs;
    public final List<class_1799> items;

    public TextInputs(class_11419 dialog, String title, List<Component> buttons, List<String> body, List<String> textInputs, List<class_1799> items) {
        this.dialog = dialog;
        this.title = title;
        this.buttons = buttons;
        this.body = body;
        this.textInputs = textInputs;
        this.items = items;
    }

    public class_11419 dialog() {
        return this.dialog;
    }

    public String title() {
        return this.title;
    }

    public List<Component> buttons() {
        return this.buttons;
    }

    public List<String> body() {
        return this.body;
    }

    public List<String> textInputs() {
        return this.textInputs;
    }

    public List<class_1799> items() {
        return this.items;
    }
    Component find(Predicate<Component> predicate) {
        for (Component component : this.buttons) {
            if (!predicate.test(component)) continue;
            return component;
        }
        return null;
    }

    Component labelled(String ... stringArray) {
        for (String string2 : stringArray) {
            final String key = Each.p(string2);
            Component component = this.find(arg_0 -> TextInputs.lmbd$labelled$0(key, arg_0));
            if (component == null) continue;
            return component;
        }
        for (String string2 : stringArray) {
            final String key = Each.p(string2);
            Component component = this.find(arg_0 -> TextInputs.lmbd$labelled$1(key, arg_0));
            if (component == null) continue;
            return component;
        }
        return null;
    }

    boolean titled(String string) {
        return this.title.contains(string);
    }

    String describe() {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Component component : this.buttons) {
            if (!component.label().isBlank()) {
                arrayList.add(component.label());
            }
            if (arrayList.size() < 12) continue;
            return "'" + this.title + "' buttons: " + (arrayList.isEmpty() ? "(none)" : String.join((CharSequence)", ", arrayList));
        }
        return "'" + this.title + "' buttons: " + (arrayList.isEmpty() ? "(none)" : String.join((CharSequence)", ", arrayList));
    }

    private static boolean lmbd$labelled$1(String string, Component component) {
        return component.key().contains(string);
    }

    private static boolean lmbd$labelled$0(String string, Component component) {
        return component.key().equals(string);
    }
}
