package krispy.modules.macros.h;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;
import krispy.modules.macros.h.MacroAbort;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;

@Environment(value=EnvType.CLIENT)
final class Thread {
    private static final long POLL_MS = 50L;
    private static final long CALL_TIMEOUT_SECONDS = 10L;
    private final String name;
    private volatile java.lang.Thread thread;
    private static final String a = Thread.a(68, Thread.a("\f ;F\u0007w'=h:\u000f\u00046$7<~\u0014\u0005e:7&:"));

    Thread(String string) {
        this.name = string;
    }

    synchronized void X(Runnable runnable, Consumer<Throwable> consumer) {
        this.i();
        java.lang.Thread thread = new java.lang.Thread(() -> this.lmbd$start$0(runnable, consumer), this.name);
        thread.setDaemon(true);
        this.thread = thread;
        thread.start();
    }

    synchronized void i() {
        java.lang.Thread thread = this.thread;
        this.thread = null;
        if (thread == null || thread == java.lang.Thread.currentThread()) return;
        thread.interrupt();
    }

    boolean b() {
        if (this.thread == null) return false;
        return true;
    }

    void n() {
        if (this.thread == java.lang.Thread.currentThread() && !java.lang.Thread.currentThread().isInterrupted()) return;
        throw new MacroAbort();
    }

    void p(long l) {
        this.n();
        try {
            java.lang.Thread.sleep(Math.max(0L, l));
        }
        catch (InterruptedException interruptedException) {
            java.lang.Thread.currentThread().interrupt();
            throw new MacroAbort();
        }
        this.n();
    }

    void S(int n) {
        this.p((long)n * 50L);
    }

    <T> T c(Supplier<T> supplier) {
        this.n();
        java.lang.Thread thread = java.lang.Thread.currentThread();
        CompletableFuture completableFuture = class_310.method_1551().method_5385(() -> this.lmbd$call$0(thread, supplier));
        try {
            return (T)completableFuture.get(10L, TimeUnit.SECONDS);
        }
        catch (InterruptedException interruptedException) {
            completableFuture.cancel(false);
            java.lang.Thread.currentThread().interrupt();
            throw new MacroAbort();
        }
        catch (ExecutionException executionException) {
            Throwable throwable = executionException.getCause();
            if (throwable instanceof RuntimeException) {
                RuntimeException runtimeException = (RuntimeException)throwable;
                throw runtimeException;
            }
            if (!(throwable instanceof Error)) throw new IllegalStateException(throwable);
            Error error = (Error)throwable;
            throw error;
        }
        catch (TimeoutException timeoutException) {
            completableFuture.cancel(false);
            throw new IllegalStateException(a);
        }
    }

    void q(Runnable runnable) {
        this.c(() -> Thread.lmbd$run$0(runnable));
    }

    boolean K(BooleanSupplier booleanSupplier, long l) {
        long l2 = System.currentTimeMillis() + l;
        while (!this.c(booleanSupplier::getAsBoolean).booleanValue()) {
            if (System.currentTimeMillis() >= l2) {
                return false;
            }
            this.p(50L);
        }
        return true;
    }

    private static Boolean lmbd$run$0(Runnable runnable) {
        runnable.run();
        return Boolean.TRUE;
    }

    private Object lmbd$call$0(java.lang.Thread thread, Supplier supplier) {
        if (this.thread == thread && !thread.isInterrupted()) return supplier.get();
        throw new MacroAbort();
    }

    private void lmbd$start$0(Runnable runnable, Consumer consumer) {
        try {
            runnable.run();
            return;
        }
        catch (MacroAbort d32) {
            Thread thread = this;
            synchronized (thread) {
                if (this.thread != java.lang.Thread.currentThread()) return;
                this.thread = null;
                return;
            }
        }
        catch (Throwable throwable) {
            if (this.thread != java.lang.Thread.currentThread()) return;
            consumer.accept(throwable);
            return;
        }
        finally {
            Thread thread = this;
            synchronized (thread) {
                if (this.thread == java.lang.Thread.currentThread()) {
                    this.thread = null;
                }
            }
        }
    }

    private static char[] a(String string) {
        char[] cArray = string.toCharArray();
        if (cArray.length >= 2) return cArray;
        cArray = cArray;
        cArray[0] = (char)(cArray[0] ^ 0xE);
        return cArray;
    }

    private static String a(int n, char[] cArray) {
        char[] cArray2;
        block11: {
            int n2;
            int n3;
            int n4;
            block10: {
                n4 = n;
                cArray2 = cArray;
                n3 = cArray.length;
                n2 = 0;
                if (!true) break block10;
                n3 = n3;
                if (n3 <= n2) break block11;
            }
            do {
                n4 = n4;
                cArray2 = cArray2;
                int n5 = n2;
                cArray2[n5] = (char)(cArray2[n5] ^ (n4 ^ (switch (n2 % 7) {
                    case 0 -> 28;
                    case 1 -> 12;
                    case 2 -> 26;
                    case 3 -> 34;
                    case 4 -> 36;
                    case 5 -> 82;
                    default -> 14;
                })));
                ++n2;
                n3 = n3;
            } while (n3 > n2);
        }
        return new String(cArray2).intern();
    }
}
