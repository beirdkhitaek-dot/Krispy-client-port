package krispy.modules.macros.h;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
enum DialogPhase {
    IDLE,
    OPENING,
    MOVING,
    CONFIRMING;

}
