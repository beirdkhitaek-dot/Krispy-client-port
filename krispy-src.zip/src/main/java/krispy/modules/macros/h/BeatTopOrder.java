package krispy.modules.macros.h;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Predicate;
import krispy.modules.macros.h.Each;
import krispy.modules.macros.h.Level;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9304;

@Environment(value=EnvType.CLIENT)
class BeatTopOrder {
    public final class_1792 item;
    public final String id;
    public final String search;
    public final String displayName;
    public final long minPrice;
    public final List<Level> enchants;
    public final boolean restock;
    public final int orderAmount;
    public final boolean beatTopOrder;
    public final long fixedPrice;
    public final long bidIncrement;
    public final long maxPrice;
    public final Predicate<class_1799> filter;

    public BeatTopOrder(class_1792 item, String id, String search, String displayName, long minPrice, List<Level> enchants, boolean restock, int orderAmount, boolean beatTopOrder, long fixedPrice, long bidIncrement, long maxPrice, Predicate<class_1799> filter) {
        this.item = item;
        this.id = id;
        this.search = search;
        this.displayName = displayName;
        this.minPrice = minPrice;
        this.enchants = enchants;
        this.restock = restock;
        this.orderAmount = orderAmount;
        this.beatTopOrder = beatTopOrder;
        this.fixedPrice = fixedPrice;
        this.bidIncrement = bidIncrement;
        this.maxPrice = maxPrice;
        this.filter = filter;
    }

    public class_1792 item() {
        return this.item;
    }

    public String id() {
        return this.id;
    }

    public String search() {
        return this.search;
    }

    public String displayName() {
        return this.displayName;
    }

    public long minPrice() {
        return this.minPrice;
    }

    public List<Level> enchants() {
        return this.enchants;
    }

    public boolean restock() {
        return this.restock;
    }

    public int orderAmount() {
        return this.orderAmount;
    }

    public boolean beatTopOrder() {
        return this.beatTopOrder;
    }

    public long fixedPrice() {
        return this.fixedPrice;
    }

    public long bidIncrement() {
        return this.bidIncrement;
    }

    public long maxPrice() {
        return this.maxPrice;
    }

    public Predicate<class_1799> filter() {
        return this.filter;
    }
    BeatTopOrder(class_1792 class_17922, String string, String string2, String string3, long l, List<Level> list, boolean bl, int n, boolean bl2, long l2, long l3, long l4) {
        this(class_17922, string, string2, string3, l, list, bl, n, bl2, l2, l3, l4, null);
    }

    static class_1792 resolveItem(String string) {
        class_2960 class_29602;
        Object object;
        Object object2 = object = string == null ? "" : string.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
        if (((String)object).isEmpty()) {
            return null;
        }
        if (!((String)object).contains(":")) {
            object = "minecraft:" + (String)object;
        }
        if ((class_29602 = class_2960.method_12829((String)object)) == null) return null;
        if (!class_7923.field_41178.method_10250(class_29602)) return null;
        class_1792 class_17922 = (class_1792)class_7923.field_41178.method_63535(class_29602);
        if (class_17922 == class_1802.field_8162) {
            return null;
        }
        class_1792 class_17923 = class_17922;
        return class_17923;
    }

    static String searchText(class_1792 class_17922) {
        return class_7923.field_41178.method_10221((class_1792)class_17922).method_12832().replace('_', ' ');
    }

    static List<Level> parseEnchants(String string) {
        ArrayList<Level> arrayList = new ArrayList<Level>();
        if (string == null) {
            return arrayList;
        }
        for (String string2 : string.split("[,;]")) {
            String string3;
            int n;
            String string4 = string2.trim();
            if (string4.isEmpty()) continue;
            int n2 = 1;
            int n3 = string4.lastIndexOf(32);
            if (n3 > 0 && (n = BeatTopOrder.parseLevel(string3 = string4.substring(n3 + 1).trim())) > 0) {
                n2 = n;
                string4 = string4.substring(0, n3).trim();
            }
            if ((string3 = Each.p(string4)).isEmpty()) continue;
            arrayList.add(new Level(string3, string4, n2));
        }
        return arrayList;
    }

    private static int parseLevel(String string) {
        try {
            int n = Integer.parseInt(string);
            if (n < 1) return 0;
            if (n > 10) return 0;
            int n2 = n;
            return n2;
        }
        catch (NumberFormatException numberFormatException) {
            return Each.s(string);
        }
    }

    boolean matches(class_1799 class_17992) {
        if (class_17992.method_7960() || !class_17992.method_31574(this.item)) return false;
        if (this.filter != null) {
            return this.filter.test(class_17992);
        }
        if (this.enchants.isEmpty()) {
            return true;
        }
        class_9304 class_93042 = class_1890.method_57532((class_1799)class_17992);
        for (Level level : this.enchants) {
            if (BeatTopOrder.levelOf(class_93042, level.key()) >= level.level()) continue;
            return false;
        }
        return true;
    }

    static boolean enchantsMatch(class_1799 class_17992, List<Level> list, boolean bl) {
        class_9304 class_93042 = class_1890.method_57532((class_1799)class_17992);
        if (bl && class_93042.method_57541() != list.size()) {
            return false;
        }
        for (Level level : list) {
            int n = BeatTopOrder.levelOf(class_93042, level.key());
            if (!(bl ? n != level.level() : n < level.level())) continue;
            return false;
        }
        return true;
    }

    private static int levelOf(class_9304 class_93042, String string) {
        for (Object2IntMap.Entry entry : class_93042.method_57539()) {
            class_5321 class_53213 = (class_5321)((class_6880)entry.getKey()).method_40230().orElse(null);
            String string2 = class_53213 == null ? "" : BeatTopOrder.lmbd$levelOf$0(class_53213);
            if (!Each.p(string2).equals(string)) continue;
            return entry.getIntValue();
        }
        return 0;
    }

    boolean nameMatches(String string, boolean bl) {
        String string2 = Each.p(string);
        String string3 = Each.p(class_7923.field_41178.method_10221((class_1792)this.item).method_12832());
        String string4 = Each.p(this.displayName);
        if (string2.equals(string3)) return true;
        if (string2.equals(string4)) return true;
        if (!bl) return false;
        if (string2.endsWith(string3)) return true;
        if (string4.isEmpty()) return false;
        if (!string2.endsWith(string4)) return false;
        return true;
    }

    String describe() {
        StringBuilder stringBuilder = new StringBuilder(this.displayName);
        if (this.enchants.isEmpty()) return stringBuilder.toString();
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Level level : this.enchants) {
            arrayList.add(level.label());
        }
        stringBuilder.append(" (").append(String.join((CharSequence)", ", arrayList)).append(')');
        return stringBuilder.toString();
    }

    private static String lmbd$levelOf$0(class_5321 class_53212) {
        return class_53212.method_29177().method_12832();
    }
}
