package krispy.modules.macros.h;

import net.minecraft.class_1792;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import krispy.modules.macros.h.Each;
import krispy.modules.macros.h.Thread;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2596;
import net.minecraft.class_2815;
import net.minecraft.class_310;
import net.minecraft.class_418;
import net.minecraft.class_465;
import net.minecraft.class_746;
import net.minecraft.class_7923;

@Environment(value=EnvType.CLIENT)
final class Worker {
    private static final int COMMAND_GAP_MS = 200;
    final Thread worker;
    private static final String a = Worker.a(69, Worker.a("XRorSKtw\u001dl=HI0"));

    Worker(Thread thread) {
        this.worker = thread;
    }

    static class_310 m() {
        return class_310.method_1551();
    }

    static class_746 f() {
        class_746 class_7462 = Worker.m().field_1724;
        if (class_7462 != null) return class_7462;
        throw new IllegalStateException(a);
    }

    String G() {
        return this.worker.c(Worker::lmbd$title$0);
    }

    boolean X() {
        return this.worker.c(Worker::J);
    }

    static boolean J() {
        class_746 class_7462 = Worker.m().field_1724;
        if (class_7462 == null) return false;
        if (class_7462.field_7512 == class_7462.field_7498) return false;
        if (!(Worker.m().field_1755 instanceof class_465)) return false;
        return true;
    }

    int Z() {
        return this.worker.c(Worker::lmbd$syncId$0);
    }

    static List<class_1799> Q() {
        ArrayList<class_1799> arrayList = new ArrayList<class_1799>();
        class_746 class_7462 = Worker.m().field_1724;
        if (class_7462 == null || class_7462.field_7512 == class_7462.field_7498) return arrayList;
        for (class_1735 class_17352 : class_7462.field_7512.field_7761) {
            if (class_17352.field_7871 instanceof class_1661) return arrayList;
            arrayList.add(class_17352.method_7677().method_7972());
        }
        return arrayList;
    }

    List<class_1799> R() {
        return this.worker.c(Worker::Q);
    }

    static String V() {
        StringBuilder stringBuilder = new StringBuilder();
        class_746 class_7462 = Worker.m().field_1724;
        if (class_7462 != null) {
            stringBuilder.append(class_7462.field_7512.field_7763).append('#');
        }
        for (class_1799 class_17992 : Worker.Q()) {
            stringBuilder.append(class_7923.field_41178.method_10221((class_1792)class_17992.method_7909())).append(':').append(class_17992.method_7947()).append(':').append(class_17992.method_7964().getString()).append('|');
        }
        return stringBuilder.toString();
    }

    String u() {
        return this.worker.c(Worker::V);
    }

    static class_1799 S(int n) {
        List<class_1799> list = Worker.Q();
        return n >= 0 && n < list.size() ? list.get(n) : class_1799.field_8037;
    }

    static int v(Predicate<class_1799> predicate, int n) {
        List<class_1799> list = Worker.Q();
        for (int i = 0; i < list.size() && i < n; ++i) {
            if (list.get(i).method_7960() || !predicate.test(list.get(i))) continue;
            return i;
        }
        return -1;
    }

    static String B(class_1799 class_17992) {
        return Each.v(class_17992.method_7964());
    }

    void P(int n, int n2, class_1713 class_17132) {
        this.worker.q(() -> Worker.lmbd$click$0(n, n2, class_17132));
    }

    void U(int n, int n2, class_1713 class_17132) {
        this.worker.q(() -> Worker.lmbd$clickInventory$0(n, n2, class_17132));
    }

    void F() {
        this.worker.q(Worker::lmbd$closeInventory$0);
    }

    void T(String string) {
        this.worker.q(() -> Worker.lmbd$command$0(string));
        this.worker.p(200L);
    }

    void k() {
        for (int i = 0; i < 4; ++i) {
            boolean bl = this.worker.c(Worker::lmbd$closeAll$0);
            if (!bl) {
                return;
            }
            this.worker.S(2);
        }
    }

    boolean h(String string, long l) {
        return this.worker.K(() -> Worker.lmbd$waitChange$0(string), l);
    }

    private static boolean lmbd$waitChange$0(String string) {
        if (Worker.V().equals(string)) return false;
        return true;
    }

    private static Boolean lmbd$closeAll$0() {
        class_746 class_7462 = Worker.m().field_1724;
        if (class_7462 == null) {
            return false;
        }
        if (class_7462.field_7512 != class_7462.field_7498) {
            class_7462.method_7346();
            return true;
        }
        if (Worker.m().field_1755 == null || Worker.m().field_1755 instanceof class_418) return false;
        Worker.m().field_1755.method_25419();
        return true;
    }

    private static void lmbd$command$0(String string) {
        Worker.f().field_3944.method_45730(string);
    }

    private static void lmbd$closeInventory$0() {
        class_746 class_7462 = Worker.f();
        if (class_7462.field_7512 != class_7462.field_7498) return;
        class_7462.field_3944.method_52787((class_2596)new class_2815(class_7462.field_7498.field_7763));
    }

    private static void lmbd$clickInventory$0(int n, int n2, class_1713 class_17132) {
        class_746 class_7462 = Worker.f();
        Worker.m().field_1761.method_2906(class_7462.field_7498.field_7763, n, n2, class_17132, (class_1657)class_7462);
    }

    private static void lmbd$click$0(int n, int n2, class_1713 class_17132) {
        class_746 class_7462 = Worker.f();
        class_1703 class_17032 = class_7462.field_7512;
        Worker.m().field_1761.method_2906(class_17032.field_7763, n, n2, class_17132, (class_1657)class_7462);
    }

    private static Integer lmbd$syncId$0() {
        return Worker.f().field_7512.field_7763;
    }

    private static String lmbd$title$0() {
        if (Worker.m().field_1755 == null) {
            return "";
        }
        String string = Each.v(Worker.m().field_1755.method_25440());
        return string;
    }

    private static char[] a(String string) {
        char[] cArray = string.toCharArray();
        if (cArray.length >= 2) return cArray;
        cArray = cArray;
        cArray[0] = (char)(cArray[0] ^ 0x11);
        return cArray;
    }

    private static String a(int n, char[] cArray) {
        char[] cArray2;
        block11: {
            int n2;
            int n3;
            int n4;
            block10: {
                n4 = n;
                cArray2 = cArray;
                n3 = cArray.length;
                n2 = 0;
                if (!true) break block10;
                n3 = n3;
                if (n3 <= n2) break block11;
            }
            do {
                n4 = n4;
                cArray2 = cArray2;
                int n5 = n2;
                cArray2[n5] = (char)(cArray2[n5] ^ (n4 ^ (switch (n2 % 7) {
                    case 0 -> 83;
                    case 1 -> 120;
                    case 2 -> 94;
                    case 3 -> 23;
                    case 4 -> 127;
                    case 5 -> 96;
                    default -> 17;
                })));
                ++n2;
                n3 = n3;
            } while (n3 > n2);
        }
        return new String(cArray2).intern();
    }
}
