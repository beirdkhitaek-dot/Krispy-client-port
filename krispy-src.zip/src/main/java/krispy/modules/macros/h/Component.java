package krispy.modules.macros.h;

import java.util.Optional;
import krispy.modules.macros.h.DialogReader;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11519;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5251;

@Environment(value=EnvType.CLIENT)
class Component {
    public final class_11519 raw;
    public final String label;
    public final String key;
    public final class_2561 component;

    public Component(class_11519 raw, String label, String key, class_2561 component) {
        this.raw = raw;
        this.label = label;
        this.key = key;
        this.component = component;
    }

    public class_11519 raw() {
        return this.raw;
    }

    public String label() {
        return this.label;
    }

    public String key() {
        return this.key;
    }

    public class_2561 component() {
        return this.component;
    }
    boolean green() {
        boolean[] blArray = new boolean[]{false};
        this.component.method_27658((arg_0, arg_1) -> Component.lmbd$green$0(blArray, arg_0, arg_1), class_2583.field_24360);
        return blArray[0];
    }

    private static Optional lmbd$green$0(boolean[] blArray, class_2583 class_25832, String string) {
        class_5251 class_52512 = class_25832.method_10973();
        if (string.isBlank() || class_52512 == null || !DialogReader.o(class_52512.method_27716())) return Optional.empty();
        blArray[0] = true;
        return Optional.empty();
    }
}
