package krispy.modules.macros.h;

import java.util.List;
import krispy.modules.macros.h.BeatTopOrder;
import krispy.modules.macros.h.Each;
import krispy.modules.macros.h.MarketFlipper;
import krispy.modules.macros.h.LastPriceCheck;
import krispy.modules.macros.h.ListingDelayMs;
import krispy.modules.macros.h.Order;
import krispy.modules.macros.h.Price;
import krispy.modules.macros.h.Thread;
import krispy.modules.macros.h.Worker;
import krispy.modules.macros.h.MacroAbort;
import krispy.util.KrispyClient;
import krispy.util.Root;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class YouOrdered {
    private static String[] a;
    private static final int MAX_LISTINGS_PER_PASS = 9;
    private static final long RECOVERY_MS = 3000L;
    final Order ah;
    final Thread worker;
    final Worker gui;
    final BeatTopOrder product;
    final ListingDelayMs config;
    private final LastPriceCheck stock;
    private final List<LastPriceCheck> stocks;
    private final Price restock;
    private final int[] inAh = new int[]{0};
    private boolean warnedFull;
    volatile long orderedAt;

    YouOrdered(MarketFlipper joinServerFirst, Thread thread, BeatTopOrder beatTopOrder, ListingDelayMs listingDelayMs, String string) {
        this.ah = new Order(joinServerFirst, thread, listingDelayMs, string);
        this.worker = thread;
        this.gui = this.ah.gui;
        this.product = beatTopOrder;
        this.config = listingDelayMs;
        this.stock = new LastPriceCheck(beatTopOrder, false);
        this.stocks = List.of(this.stock);
        this.restock = new Price(this);
    }

    void o(Root root) {
        this.ah.C(root);
    }

    boolean g() {
        return this.ah.S(this.product);
    }

    void X() {
        this.o(KrispyClient.body().text("Selling ").name(this.product.describe()).text(this.product.restock() ? ", restocking with orders." : "."));
        try {
            this.gui.k();
            if (this.ah.V(this.stocks)) {
                this.inAh[0] = this.stock.inAh;
            }
        }
        catch (MacroAbort d32) {
            throw d32;
        }
        catch (RuntimeException runtimeException) {
            this.gui.k();
        }
        while (true) {
            this.worker.n();
            try {
                this.c();
                continue;
            }
            catch (MacroAbort d33) {
                throw d33;
            }
            catch (RuntimeException runtimeException) {
                String string = runtimeException.getMessage() == null ? runtimeException.getClass().getSimpleName() : runtimeException.getMessage();
                this.o(KrispyClient.body().warn(string).text(", trying again."));
                this.worker.n();
                this.gui.k();
                this.worker.p(3000L);
            }
        }
    }

    private void c() {
        if (!this.ah.t()) {
            this.worker.p(2000L);
            return;
        } else {
            this.ah.m();
            this.ah.X(this.stock);
            this.inAh[0] = this.stock.inAh;
            if (this.stock.price <= 0L) {
                this.worker.p(Math.min(5000L, this.config.priceCheckMs()));
                return;
            } else {
                int n;
                int n2 = this.ah.O(this.product);
                if (n2 < this.config.perListing() && this.product.restock() && this.inAh[0] < this.config.maxListings() && this.restock.i()) {
                    n2 = this.ah.O(this.product);
                }
                if (n2 >= this.config.perListing()) {
                    n = this.config.maxListings() - this.inAh[0];
                    if (n <= 0) {
                        if (!this.warnedFull) {
                            this.o(KrispyClient.body().text("AH full (").value(this.inAh[0] + "/" + this.config.maxListings()).text("), waiting for sales."));
                        }
                        this.warnedFull = true;
                    } else {
                        this.warnedFull = false;
                        int n3 = this.ah.M(this.stock, Math.min(Math.min(n2 / this.config.perListing(), n), 9), this.inAh);
                        if (n3 > 0 && this.ah.O(this.product) >= this.config.perListing() && this.inAh[0] < this.config.maxListings()) {
                            this.worker.p(500L);
                            return;
                        }
                    }
                }
                this.ah.v();
                if (this.ah.V(this.stocks)) {
                    this.inAh[0] = this.stock.inAh;
                }
                if ((n = this.ah.O(this.product)) >= this.config.perListing() && this.inAh[0] < this.config.maxListings() || n >= this.config.perListing() || !this.product.restock() || this.inAh[0] >= this.config.maxListings()) return;
                this.restock.i();
            }
        }
    }

    void p(String string) {
        String string2 = Each.B(string);
        if (string2.isEmpty()) return;
        if (string2.startsWith("you ordered")) {
            this.orderedAt = System.currentTimeMillis();
        }
        this.ah.E(string2, this.stocks);
    }

    String S() {
        return Order.g(this.stocks);
    }

    static {
        a = new String[]{"Selling ", "AH full (", "), waiting for sales.", "you ordered", ", trying again.", ", restocking with orders."};
    }
}
