package krispy.modules.macros.h;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import krispy.mixin.DIALOGMixin;
import krispy.modules.macros.h.Component;
import krispy.modules.macros.h.Each;
import krispy.modules.macros.h.TextInputs;
import krispy.modules.macros.h.ValValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11414;
import net.minecraft.class_11419;
import net.minecraft.class_11424;
import net.minecraft.class_11426;
import net.minecraft.class_11430;
import net.minecraft.class_11432;
import net.minecraft.class_11434;
import net.minecraft.class_11435;
import net.minecraft.class_11437;
import net.minecraft.class_11438;
import net.minecraft.class_11444;
import net.minecraft.class_11473;
import net.minecraft.class_11519;
import net.minecraft.class_11521;
import net.minecraft.class_11722;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;

@Environment(value=EnvType.CLIENT)
final class DialogReader {
    private DialogReader() {
    }

    static TextInputs C(class_310 class_3102) {
        class_437 class_4372 = class_3102.field_1755;
        if (!(class_4372 instanceof class_11473)) {
            return null;
        }
        class_11473 class_114732 = (class_11473)class_4372;
        class_11419 dialog = ((DIALOGMixin)class_114732).krispy$dialog();
        if (dialog == null) {
            return null;
        }
        ArrayList<class_11519> arrayList = new ArrayList<class_11519>();
        if (dialog instanceof class_11426) {
            arrayList.addAll(((class_11426)dialog).comp_4317());
        }
        if (dialog instanceof class_11430) {
            arrayList.addAll(((class_11430)dialog).method_71698());
        }
        if (dialog instanceof class_11414) {
            ((class_11414)dialog).comp_4395().ifPresent(arrayList::add);
        }
        ArrayList<Component> buttons = new ArrayList<Component>(arrayList.size());
        for (class_11519 class_115192 : arrayList) {
            class_2561 class_25613 = class_115192.comp_4390().comp_4298();
            String string = DialogReader.P(class_25613);
            buttons.add(new Component(class_115192, Each.B(string), Each.p(string), class_25613));
        }
        ArrayList<String> body = new ArrayList<String>();
        ArrayList<class_1799> items = new ArrayList<class_1799>();
        for (class_11432 class_114322 : dialog.comp_4305().comp_4304()) {
            if (class_114322 instanceof class_11435) {
                body.add(Each.B(DialogReader.P(((class_11435)class_114322).comp_4330())));
            }
            if (!(class_114322 instanceof class_11434)) continue;
            class_11434 class_114342 = (class_11434)class_114322;
            items.add(class_114342.comp_4324());
            class_114342.comp_4325().ifPresent(arg_0 -> DialogReader.lmbd$current$0(body, arg_0));
        }
        ArrayList<String> inputs = new ArrayList<String>();
        for (class_11424 class_114242 : dialog.comp_4305().comp_4394()) {
            if (!(class_114242.comp_4313() instanceof class_11444)) continue;
            inputs.add(class_114242.comp_4312());
        }
        return new TextInputs(dialog, Each.B(DialogReader.P(dialog.comp_4305().comp_4301())), buttons, body, inputs, items);
    }

    static String P(class_2561 class_25612) {
        StringBuilder stringBuilder = new StringBuilder();
        DialogReader.H(class_25612, stringBuilder);
        return stringBuilder.toString();
    }

    private static void H(class_2561 class_25612, StringBuilder stringBuilder) {
        if (!(class_25612.method_10851() instanceof class_11722)) {
            class_25612.method_10851().method_27659(arg_0 -> DialogReader.lmbd$appendVisible$0(stringBuilder, arg_0));
        }
        for (class_2561 class_25613 : class_25612.method_10855()) {
            DialogReader.H(class_25613, stringBuilder);
        }
    }

    static boolean N(class_310 class_3102, TextInputs textInputs, Component component, Map<String, String> map) {
        Object object = class_3102.field_1755;
        if (!(object instanceof class_11473)) return false;
        class_11473 class_114732 = (class_11473)object;
        if (((DIALOGMixin)class_114732).krispy$dialog() != textInputs.dialog()) {
            return false;
        }
        HashMap<String, class_11521.class_11522> values = new HashMap<String, class_11521.class_11522>();
        for (class_11424 class_114242 : textInputs.dialog().comp_4305().comp_4394()) {
            class_11438 class_114382 = class_114242.comp_4313();
            if (class_114382 instanceof class_11444) {
                class_11444 class_114442 = (class_11444)class_114382;
                values.put(class_114242.comp_4312(), class_11521.class_11522.method_72070(map.getOrDefault(class_114242.comp_4312(), class_114442.comp_4354())));
                continue;
            }
            if (!(class_114382 instanceof class_11437)) continue;
            class_11437 class_114372 = (class_11437)class_114382;
            values.put(class_114242.comp_4312(), DialogReader.B(class_114372));
        }
        Optional optional = component.raw().comp_4391().flatMap(arg_0 -> DialogReader.lmbd$press$0(values, arg_0));
        class_114732.method_72141(optional);
        return true;
    }

    static void I(class_310 class_3102) {
        class_437 class_4372 = class_3102.field_1755;
        if (!(class_4372 instanceof class_11473)) return;
        class_11473 class_114732 = (class_11473)class_4372;
        class_114732.method_25419();
    }

    private static class_11521.class_11522 B(class_11437 class_114372) {
        boolean bl = class_114372.comp_4333();
        return new ValValue(bl, class_114372);
    }

    public static boolean o(int n) {
        int n2 = n >> 16 & 0xFF;
        int n3 = n >> 8 & 0xFF;
        int n4 = n & 0xFF;
        if (n3 < 192) return false;
        if (n2 >= 144) return false;
        if (n4 >= 144) return false;
        return true;
    }

    private static Optional lmbd$press$0(Map<String, class_11521.class_11522> map, class_11521 class_115212) {
        return class_115212.method_72068(map);
    }

    private static Optional lmbd$appendVisible$0(StringBuilder stringBuilder, String string) {
        stringBuilder.append(string);
        return Optional.empty();
    }

    private static void lmbd$current$0(List<String> list, class_11435 class_114352) {
        list.add(Each.B(DialogReader.P(class_114352.comp_4330())));
    }
}
