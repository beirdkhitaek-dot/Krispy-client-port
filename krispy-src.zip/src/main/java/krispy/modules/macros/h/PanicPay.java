package krispy.modules.macros.h;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import krispy.event.MacroPacketReceiveEvent;
import krispy.module.MacroCategories;
import krispy.module.MacroSubscribe;
import krispy.module.settings.MacroBoolSetting;
import krispy.module.settings.MacroEnchantSetting;
import krispy.modules.macros.h.Component;
import krispy.modules.macros.h.Each;
import krispy.modules.macros.h.PaymentState;
import krispy.modules.macros.h.TextInputs;
import krispy.modules.macros.h.Thread;
import krispy.modules.macros.h.Worker;
import krispy.modules.macros.h.MacroException;
import krispy.modules.macros.h.DialogReader;
import krispy.modules.misc.MacroModule;
import krispy.util.KrispyClient;
import krispy.util.Root;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_7439;
import net.minecraft.class_746;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(value=EnvType.CLIENT)
public final class PanicPay
extends MacroModule {
    private static Logger LOGGER;
    private static Pattern VALID_NAME;
    private static Pattern RATE_LIMIT;
    private static final int INVENTORY_SLOTS = 36;
    private static final int CONFIRM_SLOT = 53;
    private static final int MAX_STRIKES = 2;
    private static final int MAX_SELL_ROUNDS = 6;
    private static int[] ARMOR_MENU_SLOTS;
    private static final int OFFHAND_MENU_SLOT = 45;
    private static final long COMMAND_GAP_MS = 1000L;
    private static final long OPEN_TIMEOUT_MS = 8000L;
    private static final long REPLY_TIMEOUT_MS = 6000L;
    private final MacroEnchantSetting payTo = this.addSetting("pay-to", new MacroEnchantSetting("Pay To", "").hint("Player name"));
    private final MacroBoolSetting sellArmor = this.addSetting("sell-armor", new MacroBoolSetting("Sell Armor", true));
    private final MacroBoolSetting sellOffhand = this.addSetting("sell-offhand", new MacroBoolSetting("Sell Offhand", true));
    private final Thread worker = new Thread("Krispy Panic Pay");
    private volatile boolean running;
    private volatile long paidAt;
    private volatile long poorAt;
    private volatile long errorAt;
    private volatile String errorText = "";
    private volatile long holdUntil;
    private volatile long balanceAt;
    private volatile double balance;
    private volatile String balanceText = "";
    private long lastCommandAt;
    private static String[] a;

    public PanicPay() {
        super("panic-pay", "Panic Pay", "Sells your whole inventory and armor with /sell, then pays all your money to one player.", MacroCategories.DONUT_MACROS);
        this.usesNotifications();
        this.payTo.sessionOnly();
    }

    @Override
    public boolean persistEnabled() {
        return false;
    }

    @Override
    public boolean inConfigs() {
        return false;
    }

    @Override
    public void onEnable() {
        class_310 class_3102 = class_310.method_1551();
        String string = this.payTo.get().trim();
        if (class_3102.field_1724 == null || class_3102.method_1562() == null) {
            String[] stringArray = a;
            this.C(KrispyClient.body().warn("Join a server first."));
            this.requestDisable();
            return;
        } else if (!VALID_NAME.matcher(string).matches()) {
            String[] stringArray = a;
            this.C(KrispyClient.body().warn("Set Pay To to a player name first."));
            this.requestDisable();
            return;
        } else if (string.equalsIgnoreCase(class_3102.method_1548().method_1676())) {
            String[] stringArray = a;
            this.C(KrispyClient.body().warn("Pay To is your own name."));
            this.requestDisable();
            return;
        } else {
            boolean bl = this.sellArmor.get();
            boolean bl2 = this.sellOffhand.get();
            this.running = true;
            this.lastCommandAt = 0L;
            this.C(KrispyClient.body().danger("Panic Pay started").text(": selling everything, then paying ").name(string).text(". Press the key again to cancel."));
            this.worker.X(() -> this.lmbd$onEnable$0(string, bl, bl2, class_3102), arg_0 -> this.lmbd$onEnable$1(class_3102, arg_0));
        }
    }

    private void j(class_310 class_3102) {
        class_3102.execute(this::lmbd$finish$0);
    }

    @Override
    public void onDisable() {
        boolean bl = this.running;
        this.running = false;
        this.worker.i();
        class_746 class_7462 = class_310.method_1551().field_1724;
        if (!bl || class_7462 == null || class_7462.field_7512 == class_7462.field_7498) return;
        class_7462.method_7346();
    }

    @MacroSubscribe
    public void onMacroPacketReceive(MacroPacketReceiveEvent macroPacketReceiveEvent) {
        class_7439 class_74392;
        if (!this.running || !(macroPacketReceiveEvent.packet instanceof class_7439) || (class_74392 = (class_7439)macroPacketReceiveEvent.packet).comp_763() == null) return;
        String object = class_74392.comp_763().getString();
        String string = Each.B(object);
        long l = System.currentTimeMillis();
        Matcher matcher = RATE_LIMIT.matcher(string);
        if (matcher.find()) {
            try {
                this.holdUntil = l + (long)Math.ceil(Double.parseDouble(matcher.group(1)) * 1000.0) + 100L;
                return;
            }
            catch (NumberFormatException numberFormatException) {}
            return;
        } else {
            String[] stringArray = a;
            if (string.startsWith("you paid ")) {
                this.paidAt = l;
                return;
            } else {
                stringArray = a;
                if (string.contains("enough money")) {
                    this.poorAt = l;
                    return;
                } else {
                    stringArray = a;
                    if (!(string.startsWith("you have $") || string.startsWith("balance") && string.contains("$"))) {
                        if (!string.contains("not online") && !string.contains("not found") && !string.contains("cannot pay") && !string.contains("can't pay") && !string.contains("not a valid") && !string.contains("invalid") && !string.contains("doesn't exist") && !string.contains("does not exist")) return;
                        this.errorText = object;
                        this.errorAt = l;
                        return;
                    } else {
                        String string2 = string.substring(string.indexOf(36));
                        List<Double> list = Each.a(string2);
                        String string3 = Each.A(string2);
                        if (list.isEmpty() || string3 == null) return;
                        this.balance = list.get(0);
                        this.balanceText = string3;
                        this.balanceAt = l;
                    }
                }
            }
        }
    }

    private void v(Worker worker, String string, boolean bl, boolean bl2) {
        worker.k();
        HashMap<class_1792, Integer> hashMap = new HashMap<class_1792, Integer>();
        int n = this.E(worker, hashMap);
        if ((bl || bl2) && this.q(worker, bl, bl2)) {
            n += this.E(worker, hashMap);
        }
        String[] stringArray = a;
        this.C(KrispyClient.body().text("Sold ").value(n).text(n == 1 ? " item" : " items").text(", paying ").name(string).text("."));
        this.t(worker, string);
    }

    private int E(Worker worker, Map<class_1792, Integer> map) {
        Map map2;
        int n = 0;
        for (int i = 0; i < 6 && !(map2 = this.worker.c(() -> PanicPay.lmbd$sellRounds$0(map))).isEmpty(); ++i) {
            this.b(worker);
            int n2 = this.worker.c(() -> PanicPay.lmbd$sellRounds$1(map));
            this.worker.S(2);
            if (n2 > 0 && this.worker.c(Worker::J).booleanValue()) {
                worker.P(53, 0, class_1713.field_7790);
            }
            this.worker.p(700L);
            worker.k();
            this.worker.p(400L);
            Map map3 = this.worker.c(() -> PanicPay.lmbd$sellRounds$2(map));
            for (Object object5 : map2.entrySet()) {
                Map.Entry entry = (Map.Entry)object5;
                int n3 = ((Integer)map3.getOrDefault(entry.getKey(), Integer.valueOf(0))).intValue();
                if (n3 < (Integer)entry.getValue()) {
                    n += (Integer)entry.getValue() - n3;
                    continue;
                }
                int n4 = map.merge((class_1792)entry.getKey(), 1, Integer::sum);
                if (n4 != 2) continue;
                this.C(KrispyClient.body().warn("Could not sell ").name(new class_1799((class_1935)entry.getKey()).method_7964().getString()).text(", skipping it."));
            }
        }
        return n;
    }

    private static Map<class_1792, Integer> U(Map<class_1792, Integer> map) {
        HashMap<class_1792, Integer> hashMap = new HashMap<class_1792, Integer>();
        class_1661 class_16612 = Worker.f().method_31548();
        for (int i = 0; i < 36; ++i) {
            class_1799 class_17992 = class_16612.method_5438(i);
            if (class_17992.method_7960() || map.getOrDefault(class_17992.method_7909(), 0) >= 2) continue;
            hashMap.merge(class_17992.method_7909(), class_17992.method_7947(), Integer::sum);
        }
        return hashMap;
    }

    private void b(Worker worker) {
        for (int i = 0; i < 3; ++i) {
            this.D(worker, "sell");
            if (this.worker.K(PanicPay::r, 8000L)) {
                this.worker.p(150L);
                return;
            }
            worker.k();
        }
        throw new MacroException("The sell menu did not open");
    }

    private static boolean r() {
        class_746 class_7462 = Worker.m().field_1724;
        if (class_7462 == null) return false;
        if (class_7462.field_7512 == class_7462.field_7498) return false;
        if (!(Worker.m().field_1755 instanceof class_465)) return false;
        int n = 0;
        for (class_1735 class_17352 : class_7462.field_7512.field_7761) {
            if (class_17352.field_7871 instanceof class_1661) continue;
            ++n;
        }
        if (n <= 53) return false;
        return true;
    }

    private boolean q(Worker worker, boolean bl, boolean bl2) {
        List list = this.worker.c(() -> PanicPay.lmbd$takeOff$0(bl, bl2));
        if (list.isEmpty()) {
            return false;
        }
        worker.k();
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            int n = (Integer)iterator.next();
            worker.U(n, 0, class_1713.field_7794);
            this.worker.S(1);
        }
        worker.F();
        this.worker.S(4);
        return true;
    }

    private void t(Worker worker, String string) {
        String string2 = this.h(worker);
        if (!(this.balance < 1.0)) {
            for (int i = 0; i < 3; ++i) {
                PaymentState pF = this.S(worker, string, string2);
                if (pF == PaymentState.PAID) {
                    String[] stringArray = a;
                    this.C(KrispyClient.body().good("Paid $" + string2).text(" to ").name(string).text("."));
                    return;
                }
                if (pF == PaymentState.POOR) {
                    String[] stringArray = a;
                    throw new MacroException("/pay " + string + " " + string2 + " was refused: not enough money");
                }
                if (pF != PaymentState.FAILED) continue;
                throw new MacroException("/pay failed: " + this.errorText);
            }
            throw new MacroException("No answer to /pay " + string + " " + string2);
        }
        String[] stringArray = a;
        this.C(KrispyClient.body().warn("You have no money to pay."));
    }

    private String h(Worker worker) {
        for (int i = 0; i < 3; ++i) {
            long l = System.currentTimeMillis();
            this.D(worker, "bal");
            if (!this.worker.K(() -> this.lmbd$readBalance$0(l), 6000L)) continue;
            return this.balanceText;
        }
        throw new MacroException("Could not read your balance from /bal");
    }

    private PaymentState S(Worker worker, String string, String string2) {
        long l = System.currentTimeMillis();
        this.D(worker, "pay " + string + " " + string2);
        Object[] objectArray = new Object[]{null};
        long l2 = l + 6000L;
        while (System.currentTimeMillis() < l2) {
            if (this.paidAt >= l) {
                return PaymentState.PAID;
            }
            if (this.poorAt >= l) {
                return PaymentState.POOR;
            }
            if (this.errorAt >= l) {
                return PaymentState.FAILED;
            }
            if (this.holdUntil > l) {
                return PaymentState.RETRY;
            }
            this.worker.q(() -> PanicPay.lmbd$pay$0(objectArray));
            this.worker.p(50L);
        }
        return PaymentState.RETRY;
    }

    private void D(Worker worker, String string) {
        long l = Math.max(this.holdUntil, this.lastCommandAt + 1000L) - System.currentTimeMillis();
        if (l > 0L) {
            this.worker.p(l);
        }
        worker.T(string);
        this.lastCommandAt = System.currentTimeMillis();
    }

    private void C(Root root) {
        KrispyClient.send((MacroModule)this, root);
    }

    private static void lmbd$pay$0(Object[] objectArray) {
        Component component;
        TextInputs textInputs = DialogReader.C(Worker.m());
        if (textInputs == null || textInputs.dialog() == objectArray[0] || (component = textInputs.labelled("confirm", "yes", "pay")) == null || !DialogReader.N(Worker.m(), textInputs, component, Map.of())) return;
        objectArray[0] = textInputs.dialog();
    }

    private boolean lmbd$readBalance$0(long l) {
        if (this.balanceAt < l) return false;
        return true;
    }

    private static List lmbd$takeOff$0(boolean bl, boolean bl2) {
        class_746 class_7462 = Worker.f();
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        if (bl) {
            for (int n : ARMOR_MENU_SLOTS) {
                if (!class_7462.field_7498.method_7611(n).method_7681()) continue;
                arrayList.add(n);
            }
        }
        if (!bl2 || !class_7462.field_7498.method_7611(45).method_7681()) return arrayList;
        arrayList.add(45);
        return arrayList;
    }

    private static Map lmbd$sellRounds$2(Map map) {
        return PanicPay.U(map);
    }

    private static Integer lmbd$sellRounds$1(Map map) {
        class_746 class_7462 = Worker.f();
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        for (class_1735 class_17352 : class_7462.field_7512.field_7761) {
            if (!(class_17352.field_7871 instanceof class_1661) || !class_17352.method_7681() || class_17352.method_34266() >= 36 || ((Integer)map.getOrDefault(class_17352.method_7677().method_7909(), 0)) >= 2) continue;
            arrayList.add(class_17352.field_7874);
        }
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            int n = (Integer)iterator.next();
            Worker.m().field_1761.method_2906(class_7462.field_7512.field_7763, n, 0, class_1713.field_7794, (class_1657)class_7462);
        }
        return arrayList.size();
    }

    private static Map lmbd$sellRounds$0(Map map) {
        return PanicPay.U(map);
    }

    private void lmbd$finish$0() {
        if (!this.running || !this.isEnabled()) return;
        this.toggle(false);
    }

    private void lmbd$onEnable$1(class_310 class_3102, Throwable throwable) {
        LOGGER.error("[Krispy] Panic Pay stopped", throwable);
        this.C(KrispyClient.body().danger("Stopped").text(": " + String.valueOf(throwable)));
        this.j(class_3102);
    }

    private void lmbd$onEnable$0(String string, boolean bl, boolean bl2, class_310 class_3102) {
        try {
            this.v(new Worker(this.worker), string, bl, bl2);
            return;
        }
        catch (MacroException c2) {
            this.C(KrispyClient.body().warn(c2.getMessage()).text(", stopped."));
            return;
        }
        finally {
            this.j(class_3102);
        }
    }

    static {
        String[] stringArray = a = new String[]{" was refused: not enough money", "/pay failed: ", "you need to wait another ([\\d.]+) seconds?", "No answer to /pay ", "Pay To is your own name.", "not found", "not a valid", "cannot pay", "Sell Offhand", "confirm", ": ", "Sold ", "balance", "\\.?[A-Za-z0-9_]{1,16}", "bal", "not online", "Player name", "pay-to", "does not exist", "You have no money to pay.", "Could not read your balance from /bal", "The sell menu did not open", "pay ", "Sell Armor", "yes", "/pay ", ": selling everything, then paying ", "you have $", "Paid $", " items", ". Press the key again to cancel.", "Sells your whole inventory and armor with /sell, then pays all your money to one player.", ", stopped.", "[Krispy] Panic Pay stopped", "Krispy Panic Pay", "Pay To", "panic-pay", ", paying ", " item", "pay", "Set Pay To to a player name first.", ", skipping it.", "Krispy", "sell", "invalid", "sell-armor", "Join a server first.", "you paid ", "Could not sell ", "can't pay", "Stopped", "enough money", "sell-offhand", "doesn't exist", "Panic Pay", "Panic Pay started", " to "};
        LOGGER = LoggerFactory.getLogger(stringArray[42]);
        VALID_NAME = Pattern.compile(stringArray[13]);
        RATE_LIMIT = Pattern.compile(stringArray[2]);
        ARMOR_MENU_SLOTS = new int[]{5, 6, 7, 8};
    }
}
