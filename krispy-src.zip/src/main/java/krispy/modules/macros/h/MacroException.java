package krispy.modules.macros.h;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class MacroException
extends RuntimeException {
    MacroException(String string) {
        super(string, null, false, false);
    }
}
