package krispy.modules.macros.h;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import krispy.event.MacroPacketReceiveEvent;
import krispy.module.MacroCategories;
import krispy.module.MacroSubscribe;
import krispy.module.settings.MacroEnchantSetting;
import krispy.module.settings.MacroModeSetting;
import krispy.module.settings.MacroNumberSetting;
import krispy.modules.macros.h.BeatTopOrder;
import krispy.modules.macros.h.Each;
import krispy.modules.macros.h.Level;
import krispy.modules.macros.h.ListingDelayMs;
import krispy.modules.macros.h.NothingSellRight;
import krispy.modules.macros.h.Thread;
import krispy.modules.macros.h.DialogReader;
import krispy.modules.misc.MacroModule;
import krispy.util.KrispyClient;
import krispy.util.Root;
import krispy.util.Viii;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import net.minecraft.class_7439;
import net.minecraft.class_746;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(value=EnvType.CLIENT)
public final class AHSell
extends MacroModule {
    private static Logger LOGGER;
    private static final int SLOTS = 9;
    private static String FIXED;
    private static String AUTO;
    private final MacroModeSetting count;
    private final MacroModeSetting pricing;
    private final MacroEnchantSetting[] items;
    private final MacroEnchantSetting[] enchants;
    private final MacroEnchantSetting[] prices;
    private final MacroEnchantSetting undercut;
    private final MacroNumberSetting priceCheck;
    private final MacroNumberSetting relistGap;
    private final MacroNumberSetting ignoreDrops;
    private final MacroNumberSetting salesCheck;
    private final MacroNumberSetting perListing;
    private final MacroNumberSetting maxListings;
    private final MacroNumberSetting listingDelay;
    private final Thread worker;
    private volatile NothingSellRight bot;
    private static String[] a;

    public AHSell() {
        super("ah-sell", "AH Sell", "Lists up to 9 items from your inventory on the Auction House at your price or the cheapest price.", MacroCategories.DONUT_MACROS);
        String[] stringArray = a;
        this.count = this.addSetting("items", new MacroModeSetting("Items", "1", "1", "2", "3", "4", "5", "6", "7", "8", "9"));
        this.pricing = this.addSetting("pricing", new MacroModeSetting("Pricing", "Fixed", "Fixed", "Auto (beat cheapest)"));
        this.items = new MacroEnchantSetting[9];
        this.enchants = new MacroEnchantSetting[9];
        this.prices = new MacroEnchantSetting[9];
        this.worker = new Thread("Krispy AH Sell");
        this.usesNotifications();
        for (int i = 0; i < 9; ++i) {
            int n = i + 1;
            int n2 = i;
            stringArray = a;
            this.items[i] = this.addSetting("item-" + n, new MacroEnchantSetting("Item " + n, "").hint("e.g. diamond_block").itemPicker());
            this.enchants[i] = this.addSetting("enchants-" + n, new MacroEnchantSetting("Enchantments " + n, "").enchantsFor(this.items[i]));
            this.prices[i] = this.addSetting("price-" + n, new MacroEnchantSetting("Price " + n + " (each)", "").hint("e.g. 5k (Auto: lowest price)"));
            this.items[i].visibleWhen(() -> this.lmbd$new$0(n));
            this.enchants[i].visibleWhen(() -> this.lmbd$new$1(n, n2));
            this.prices[i].visibleWhen(() -> this.lmbd$new$2(n));
        }
        this.undercut = this.addSetting("undercut", new MacroEnchantSetting("Undercut By", "100").hint("e.g. 100"));
        this.priceCheck = this.addSetting("price-check", new MacroNumberSetting("Price Check (s)", 120.0f, 10.0f, 600.0f).step(10.0f));
        this.relistGap = this.addSetting("relist-gap", new MacroNumberSetting("Relist Higher At (x undercut)", 3.0f, 1.0f, 20.0f).step(0.5f));
        this.ignoreDrops = this.addSetting("ignore-drops", new MacroNumberSetting("Ignore Drops Over (x undercut)", 20.0f, 1.0f, 100.0f).step(1.0f));
        this.salesCheck = this.addSetting("sales-check", new MacroNumberSetting("Sales Check (s)", 20.0f, 5.0f, 300.0f).step(5.0f));
        this.perListing = this.addSetting("per-listing", new MacroNumberSetting("Items Per Listing", 1.0f, 1.0f, 64.0f).step(1.0f));
        this.maxListings = this.addSetting("max-listings", new MacroNumberSetting("Max Listings", 25.0f, 1.0f, 50.0f).step(1.0f));
        this.listingDelay = this.addSetting("listing-delay", new MacroNumberSetting("Listing Delay (s)", 0.0f, 0.0f, 5.0f).step(0.25f));
        this.undercut.visibleWhen(this::n);
        this.priceCheck.visibleWhen(this::n);
        this.relistGap.visibleWhen(this::n);
        this.ignoreDrops.visibleWhen(this::n);
    }

    private int J() {
        return Integer.parseInt(this.count.get());
    }

    private boolean n() {
        return this.pricing.is("Auto (beat cheapest)");
    }

    @Override
    public boolean persistEnabled() {
        return false;
    }

    @Override
    public void onEnable() {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1724 != null && class_3102.method_1548() != null) {
            ArrayList<BeatTopOrder> arrayList = new ArrayList<BeatTopOrder>();
            String string = this.D(arrayList);
            if (string != null) {
                this.Y(KrispyClient.body().warn(string));
                this.requestDisable();
                return;
            } else {
                NothingSellRight nothingSellRight;
                ListingDelayMs listingDelayMs = new ListingDelayMs(Math.max(0L, Each.f(this.undercut.get())), (long)(this.priceCheck.get() * 1000.0f), (long)(this.salesCheck.get() * 1000.0f), this.perListing.getInt(), this.maxListings.getInt(), (long)(this.listingDelay.get() * 1000.0f), this.relistGap.get(), this.ignoreDrops.get(), 36, 15000L);
                this.bot = nothingSellRight = new NothingSellRight(this, this.worker, arrayList, !this.n(), listingDelayMs, class_3102.method_1548().method_1676());
                this.worker.X(nothingSellRight::c, arg_0 -> this.lmbd$onEnable$0(class_3102, nothingSellRight, arg_0));
            }
            return;
        } else {
            this.Y(KrispyClient.body().warn("Join a server first."));
            this.requestDisable();
        }
    }

    @Override
    public void onDisable() {
        NothingSellRight nothingSellRight = this.bot;
        this.bot = null;
        this.worker.i();
        class_310 class_3102 = class_310.method_1551();
        class_746 class_7462 = class_3102.field_1724;
        if (nothingSellRight == null || class_7462 == null) return;
        if (class_7462.field_7512 != class_7462.field_7498) {
            class_7462.method_7346();
        } else {
            DialogReader.I(class_3102);
        }
        this.Y(KrispyClient.body().text(nothingSellRight.P()));
    }

    @MacroSubscribe
    public void onMacroPacketReceive(MacroPacketReceiveEvent macroPacketReceiveEvent) {
        class_7439 class_74392;
        class_2596<?> class_25962;
        NothingSellRight nothingSellRight = this.bot;
        if (nothingSellRight == null || !((class_25962 = macroPacketReceiveEvent.packet) instanceof class_7439) || (class_74392 = (class_7439)class_25962).comp_763() == null) return;
        nothingSellRight.a(class_74392.comp_763().getString());
    }

    private String D(List<BeatTopOrder> list) {
        if (this.n() && Each.f(this.undercut.get()) < 0L) {
            String[] stringArray = a;
            return "Undercut By must be a price like 100.";
        }
        HashSet<class_1792> hashSet = new HashSet<class_1792>();
        for (int i = 0; i < this.J(); ++i) {
            String string = this.items[i].get().trim();
            if (string.isEmpty()) continue;
            class_1792 class_17922 = BeatTopOrder.resolveItem(string);
            if (class_17922 == null) {
                String[] stringArray = a;
                return "Item " + (i + 1) + ": unknown item '" + string + "'.";
            }
            if (!hashSet.add(class_17922)) {
                String[] stringArray = a;
                return "Item " + (i + 1) + ": " + string + " is listed twice.";
            }
            long l = Each.f(this.prices[i].get());
            if (l <= 0L) {
                String string2;
                if (this.n()) {
                    String[] stringArray = a;
                    string2 = " (the lowest price Auto may use).";
                    return "Item " + (i + 1) + ": set a price like 5k" + string2;
                } else {
                    string2 = ".";
                }
                return "Item " + (i + 1) + ": set a price like 5k" + string2;
            }
            List<Level> list2 = Viii.supports(class_17922) ? BeatTopOrder.parseEnchants(this.enchants[i].get()) : List.of();
            list.add(new BeatTopOrder(class_17922, string, BeatTopOrder.searchText(class_17922), new class_1799((class_1935)class_17922).method_7964().getString(), l, list2, false, 1, true, 1L, 1L, 0L));
        }
        if (!list.isEmpty()) return null;
        return "Set at least one item.";
    }

    private void Y(Root root) {
        KrispyClient.send((MacroModule)this, root);
    }

    private void lmbd$onEnable$0(class_310 class_3102, NothingSellRight nothingSellRight, Throwable throwable) {
        LOGGER.error("[Krispy] AH Sell stopped", throwable);
        this.Y(KrispyClient.body().danger("Stopped").text(": " + String.valueOf(throwable)));
        class_3102.execute(() -> this.lmbd$onEnable$1(nothingSellRight));
    }

    private void lmbd$onEnable$1(NothingSellRight nothingSellRight) {
        if (this.bot != nothingSellRight) return;
        this.toggle(false);
    }

    private boolean lmbd$new$2(int n) {
        if (n > this.J()) return false;
        return true;
    }

    private boolean lmbd$new$1(int n, int n2) {
        if (n > this.J()) return false;
        if (!Viii.supports(BeatTopOrder.resolveItem(this.items[n2].get()))) return false;
        return true;
    }

    private boolean lmbd$new$0(int n) {
        if (n > this.J()) return false;
        return true;
    }

    static {
        a = new String[]{"Relist Higher At (x undercut)", " is listed twice.", "Price ", "Undercut By must be a price like 100.", "pricing", "listing-delay", "Enchantments ", "Listing Delay (s)", " (the lowest price Auto may use).", "e.g. diamond_block", ": ", "Fixed", "enchants-", "Stopped", ": ", "Fixed", "Max Listings", "price-", "Ignore Drops Over (x undercut)", "ah-sell", " (each)", "[Krispy] AH Sell stopped", "Sales Check (s)", "Lists up to 9 items from your inventory on the Auction House at your price or the cheapest price.", "items", "Items Per Listing", ": set a price like 5k", "Auto (beat cheapest)", "Krispy", "100", "Join a server first.", "Item ", ": unknown item '", "Item ", "price-check", "sales-check", "undercut", "item-", "e.g. 5k (Auto: lowest price)", "'.", "Undercut By", "Auto (beat cheapest)", "ignore-drops", "Pricing", "Price Check (s)", "max-listings", "relist-gap", "Krispy AH Sell", "e.g. 100", "per-listing", "Set at least one item.", "AH Sell", "Items"};
        AUTO = a[27];
        FIXED = a[15];
        LOGGER = LoggerFactory.getLogger("Krispy");
    }
}
