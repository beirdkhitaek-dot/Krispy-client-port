package krispy.modules.macros.h;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.BiPredicate;
import krispy.module.settings.MacroItemSetting;
import krispy.modules.macros.h.DialogPhase;
import krispy.modules.misc.MacroModule;
import krispy.util.KrispyClient;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_634;
import net.minecraft.class_746;
import net.minecraft.class_7923;

@Environment(value=EnvType.CLIENT)
public final class Sell {
    private static final int INVENTORY_SLOTS = 36;
    private static final int CONFIRM_SLOT = 53;
    private static final int MAX_CONFIRMS = 3;
    private static final int STRIKES_TO_SKIP = 2;
    private static final int MAX_RESENDS = 3;
    private static final long CHECK_EVERY_MS = 500L;
    private static final long COMMAND_COOLDOWN_MS = 4000L;
    private static final long OPEN_TIMEOUT_MS = 10000L;
    private static final long STRAY_MENU_MS = 5000L;
    private static final long FAIL_COOLDOWN_MS = 30000L;
    private static final long CONFIRM_COOLDOWN_MS = 900L;
    private static final long POST_CONFIRM_MS = 250L;
    private static final long SKIP_MS = 600000L;
    private final MacroModule owner;
    private final MacroItemSetting neverSell;
    private final BiPredicate<Integer, class_1799> keep;
    private final Runnable onCommand;
    private DialogPhase state = DialogPhase.IDLE;
    private long nextCheckAt;
    private long lastCommandAt;
    private long deadline;
    private boolean rejected;
    private long retryAt;
    private int resends;
    private int menuId = -1;
    private int confirms;
    private final Map<class_1792, Integer> offered = new LinkedHashMap<class_1792, Integer>();
    private final Map<class_1792, Integer> strikes = new HashMap<class_1792, Integer>();
    private final Map<class_1792, Long> skipUntil = new HashMap<class_1792, Long>();
    private static final String[] a = new String[]{" item.", "The sell menu did not open", "sell", "Sold ", "Could not sell ", " items.", ", skipping it for 10 minutes.", ", trying again in 30s."};

    Sell(MacroModule macroModule, MacroItemSetting macroItemSetting, BiPredicate<Integer, class_1799> biPredicate, Runnable runnable) {
        this.owner = macroModule;
        this.neverSell = macroItemSetting;
        this.keep = biPredicate;
        this.onCommand = runnable;
    }

    void c() {
        this.state = DialogPhase.IDLE;
        this.nextCheckAt = 0L;
        this.lastCommandAt = 0L;
        this.rejected = false;
        this.menuId = -1;
        this.offered.clear();
        this.strikes.clear();
        this.skipUntil.clear();
    }

    boolean b() {
        if (this.state == DialogPhase.IDLE) return false;
        return true;
    }

    void l(long l) {
        if (this.state != DialogPhase.OPENING) return;
        this.rejected = true;
        this.retryAt = l;
    }

    void U(class_310 class_3102) {
        if (this.state == DialogPhase.IDLE) return;
        class_746 class_7462 = class_3102.field_1724;
        if (class_7462 != null && class_7462.field_7512 != class_7462.field_7498 && class_7462.field_7512.field_7763 == this.menuId) {
            class_7462.method_7346();
        }
        this.state = DialogPhase.IDLE;
        this.menuId = -1;
        this.offered.clear();
        this.nextCheckAt = System.currentTimeMillis() + 500L;
    }

    boolean D(class_310 class_3102, class_746 class_7462, class_634 class_6342, long l, boolean bl) {
        boolean bl2;
        switch (this.state.ordinal()) {
            default: {
                throw new MatchException(null, null);
            }
            case 0: {
                bl2 = this.H(class_3102, class_7462, class_6342, l, bl);
                return bl2;
            }
            case 1: {
                bl2 = this.F(class_3102, class_7462, class_6342, l);
                return bl2;
            }
            case 2: {
                bl2 = this.i(class_3102, class_7462, l);
                return bl2;
            }
            case 3: {
                bl2 = this.k(class_3102, class_7462, l);
            }
        }
        return bl2;
    }

    private boolean H(class_310 class_3102, class_746 class_7462, class_634 class_6342, long l, boolean bl) {
        if (l - this.lastCommandAt < 5000L && Sell.p(class_3102, class_7462)) {
            class_7462.method_7346();
            return true;
        }
        if (l < this.nextCheckAt) {
            return false;
        }
        this.nextCheckAt = l + 500L;
        if (class_3102.field_1755 != null || !bl || l - this.lastCommandAt < 4000L) {
            return false;
        }
        if (!this.m(class_7462.method_31548(), l)) {
            return false;
        }
        this.resends = 0;
        this.A(class_6342, l);
        return true;
    }

    private void A(class_634 class_6342, long l) {
        class_6342.method_45730("sell");
        this.lastCommandAt = l;
        this.onCommand.run();
        this.deadline = l + 10000L;
        this.rejected = false;
        this.state = DialogPhase.OPENING;
    }

    private boolean F(class_310 class_3102, class_746 class_7462, class_634 class_6342, long l) {
        if (Sell.p(class_3102, class_7462)) {
            this.menuId = class_7462.field_7512.field_7763;
            this.state = DialogPhase.MOVING;
            return true;
        }
        if (this.rejected && l >= this.retryAt && this.resends < 3) {
            ++this.resends;
            this.A(class_6342, l);
            return true;
        }
        if (l < this.deadline) {
            return true;
        }
        this.state = DialogPhase.IDLE;
        KrispyClient.send(this.owner, KrispyClient.body().warn("The sell menu did not open").text(", trying again in 30s."));
        this.nextCheckAt = l + 30000L;
        return false;
    }

    private boolean i(class_310 class_3102, class_746 class_7462, long l) {
        class_1703 class_17032 = class_7462.field_7512;
        if (!this.Q(class_7462)) {
            return this.L(null, l);
        }
        int n = 0;
        for (class_1735 class_17352 : class_17032.field_7761) {
            int n2;
            if (!(class_17352.field_7871 instanceof class_1661) || !class_17352.method_7681() || (n2 = class_17352.method_34266()) >= 36 || !this.f(n2, class_17352.method_7677(), l)) continue;
            class_3102.field_1761.method_2906(class_17032.field_7763, class_17352.field_7874, 0, class_1713.field_7794, (class_1657)class_7462);
            ++n;
        }
        if (n == 0) {
            return this.d(class_7462, null, l);
        }
        this.offered.clear();
        this.offered.putAll(Sell.g(class_17032));
        this.confirms = 0;
        this.deadline = l;
        this.state = DialogPhase.CONFIRMING;
        return true;
    }

    private boolean k(class_310 class_3102, class_746 class_7462, long l) {
        if (!this.Q(class_7462)) {
            return this.L(null, l);
        }
        if (l < this.deadline) {
            return true;
        }
        class_1703 class_17032 = class_7462.field_7512;
        if (this.confirms >= 3 || !Sell.P(class_17032)) return this.d(class_7462, Sell.g(class_17032), l);
        class_3102.field_1761.method_2906(class_17032.field_7763, 53, 0, class_1713.field_7790, (class_1657)class_7462);
        ++this.confirms;
        this.deadline = l + (this.confirms == 1 ? 250L : 900L);
        return true;
    }

    private boolean d(class_746 class_7462, Map<class_1792, Integer> map, long l) {
        if (!this.Q(class_7462)) return this.L(map, l);
        class_7462.method_7346();
        return this.L(map, l);
    }

    private boolean L(Map<class_1792, Integer> map, long l) {
        if (map != null) {
            this.B(map, l);
        }
        this.offered.clear();
        this.menuId = -1;
        this.state = DialogPhase.IDLE;
        this.nextCheckAt = l + 500L;
        return false;
    }

    private void B(Map<class_1792, Integer> map, long l) {
        int n = 0;
        for (Map.Entry<class_1792, Integer> entry : this.offered.entrySet()) {
            class_1792 class_17922 = entry.getKey();
            int n2 = map.getOrDefault(class_17922, 0);
            n += Math.max(0, entry.getValue() - n2);
            if (n2 <= 0) {
                this.strikes.remove(class_17922);
                continue;
            }
            if (this.strikes.merge(class_17922, 1, Integer::sum) < 2) continue;
            this.strikes.remove(class_17922);
            this.skipUntil.put(class_17922, l + 600000L);
            String[] stringArray = a;
            KrispyClient.send(this.owner, KrispyClient.body().warn("Could not sell ").name(class_17922.method_63680().getString()).text(", skipping it for 10 minutes."));
        }
        if (n <= 0) return;
        KrispyClient.send(this.owner, KrispyClient.body().text("Sold ").value(n).text(n == 1 ? " item." : " items."));
    }

    private boolean Q(class_746 class_7462) {
        if (class_7462.field_7512 == class_7462.field_7498) return false;
        if (class_7462.field_7512.field_7763 != this.menuId) return false;
        return true;
    }

    private boolean m(class_1661 class_16612, long l) {
        for (int i = 0; i < 36; ++i) {
            class_1799 class_17992 = class_16612.method_5438(i);
            if (class_17992.method_7960() || !this.f(i, class_17992, l)) continue;
            return true;
        }
        return false;
    }

    private boolean f(int n, class_1799 class_17992, long l) {
        if (this.t(class_17992.method_7909(), l)) return false;
        if (this.keep.test(n, class_17992)) return false;
        if (this.K(class_17992)) return false;
        return true;
    }

    private boolean t(class_1792 class_17922, long l) {
        Long l2 = this.skipUntil.get(class_17922);
        if (l2 == null) {
            return false;
        }
        if (l < l2) {
            return true;
        }
        this.skipUntil.remove(class_17922);
        return false;
    }

    private boolean K(class_1799 class_17992) {
        return Sell.e(class_17992, this.neverSell.get());
    }

    public static boolean e(class_1799 class_17992, List<String> list) {
        String string = class_7923.field_41178.method_10221((class_1792)class_17992.method_7909()).toString().toLowerCase(Locale.ROOT);
        String string2 = string.substring(string.indexOf(58) + 1);
        for (String string3 : list) {
            String string4 = string3.trim().toLowerCase(Locale.ROOT);
            if (string4.isEmpty()) continue;
            if (string.equals(string4) || string2.equals(string4)) {
                return true;
            }
            if (string4.indexOf(58) >= 0 || !string.contains(string4)) continue;
            return true;
        }
        return false;
    }

    private static boolean P(class_1703 class_17032) {
        for (class_1735 class_17352 : class_17032.field_7761) {
            if (class_17352.field_7871 instanceof class_1661 || class_17352.field_7874 == 53 || !class_17352.method_7681()) continue;
            return true;
        }
        return false;
    }

    private static Map<class_1792, Integer> g(class_1703 class_17032) {
        LinkedHashMap<class_1792, Integer> linkedHashMap = new LinkedHashMap<class_1792, Integer>();
        for (class_1735 class_17352 : class_17032.field_7761) {
            if (class_17352.field_7871 instanceof class_1661 || class_17352.field_7874 == 53 || !class_17352.method_7681()) continue;
            linkedHashMap.merge(class_17352.method_7677().method_7909(), class_17352.method_7677().method_7947(), Integer::sum);
        }
        return linkedHashMap;
    }

    private static boolean p(class_310 class_3102, class_746 class_7462) {
        class_1703 class_17032 = class_7462.field_7512;
        if (class_17032 == class_7462.field_7498) return false;
        if (!(class_3102.field_1755 instanceof class_465)) return false;
        if (Sell.o(class_17032) <= 53) return false;
        return true;
    }

    private static int o(class_1703 class_17032) {
        int n = 0;
        for (class_1735 class_17352 : class_17032.field_7761) {
            if (class_17352.field_7871 instanceof class_1661) continue;
            ++n;
        }
        return n;
    }
}
