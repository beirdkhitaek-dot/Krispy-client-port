package krispy.modules.macros.h;

import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import krispy.modules.macros.h.BeatTopOrder;
import krispy.modules.macros.h.Component;
import krispy.modules.macros.h.CouldNotOpen;
import krispy.modules.macros.h.Each;
import krispy.modules.macros.h.Level;
import krispy.modules.macros.h.TextInputs;
import krispy.modules.macros.h.Thread;
import krispy.modules.macros.h.Worker;
import krispy.modules.macros.h.YouOrdered;
import krispy.modules.macros.h.MacroException;
import krispy.modules.macros.h.DialogReader;
import krispy.util.KrispyClient;
import krispy.util.Root;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

@Environment(value=EnvType.CLIENT)
final class Price {
    private static final int ORDER_SLOTS = 45;
    private static final int DEFAULT_COLLECT_BUTTON = 13;
    private static final long OPEN_TIMEOUT_MS = 10000L;
    private static final long DIALOG_TIMEOUT_MS = 8000L;
    private static final long PICK_TIMEOUT_MS = 5000L;
    private final YouOrdered bot;
    private final Thread worker;
    private final Worker gui;
    private final BeatTopOrder product;
    private long nextCheckAt;
    private static final String[] a = new String[]{"skip", "enchant", "Your order did not open.", ", trying later.", "collect", " at $", "Top order is $", " (no New Order button).", "next", "amount", "Your ", "Picked ", "cancel", ". Use a Fixed order price for enchanted items.", "The enchantment menu closed after picking ", "Expected the review menu, got ", ", cancelled", "price", "Ordered ", "Collected ", "price", "confirm", "Choose Item did not open", "create order", "cancel", "skip enchantments", "confirm", " each.", "review order", "next", "The menu changed before picking ", " is not offered, ", "review", " was picked, continuing.", "No enchantment menu for ", "No free order slot", "amount", "No Create Order button, ", " from your order.", "search", "Expected the price menu, got ", "continue", "), cancelled", "Capped at your max price $", "done", " is not in the search results, ", "No collect button in your order.", " for ", " each.", "Expected the amount menu, got ", ", ", "how many", " order is still filling.", ", ordering at $", "No answer after clicking '", "item", "continue", "Order review did not match (", "order ", "Could not confirm ", " instead of ", "The review menu closed", "Button missing, ", "review", "The menu changed before clicking ", "create", "No order price found"};
    private static final String k6xO1L1rv4l43cjRXqks = "culbSWZUloE";

    Price(YouOrdered youOrdered) {
        this.bot = youOrdered;
        this.worker = youOrdered.worker;
        this.gui = youOrdered.gui;
        this.product = youOrdered.product;
    }

    private void u(Root root) {
        this.bot.o(root);
    }

    private static MacroException d(String string) {
        return new MacroException(string);
    }

    boolean i() {
        long l = System.currentTimeMillis();
        if (l < this.nextCheckAt) {
            return false;
        }
        this.nextCheckAt = l + this.bot.config.orderCheckMs();
        if (!this.A()) {
            return false;
        }
        int n = this.worker.c(this::lmbd$run$0);
        if (n >= 0) {
            if (this.a(n) <= 0) return false;
            return true;
        }
        this.gui.k();
        long l2 = this.t();
        if (l2 <= 0L) {
            return false;
        }
        this.j(l2);
        return false;
    }

    private boolean A() {
        return CouldNotOpen.o(this.worker, this.gui, this::u);
    }

    private boolean C() {
        return CouldNotOpen.b();
    }

    private static boolean Y(class_1799 class_17992) {
        return CouldNotOpen.d(class_17992);
    }

    private int a(int n) {
        String string = this.gui.u();
        this.gui.P(n, 0, class_1713.field_7790);
        boolean bl = this.worker.K(() -> this.lmbd$collect$0(string), 2000L);
        if (!bl) {
            String[] stringArray = a;
            this.u(KrispyClient.body().warn("Your order did not open."));
            this.gui.k();
            return 0;
        }
        this.worker.p(1000L);
        int[] nArray = this.worker.c(Price::lmbd$collect$1);
        if (nArray[0] == 1) {
            String[] stringArray = a;
            this.u(KrispyClient.body().text("Your ").name(this.product.displayName()).text(" order is still filling."));
            this.gui.k();
            return 0;
        }
        if (nArray[1] < 0) {
            String[] stringArray = a;
            this.u(KrispyClient.body().warn("No collect button in your order."));
            this.gui.k();
            return 0;
        }
        String string2 = this.gui.u();
        this.gui.P(nArray[1], 0, class_1713.field_7790);
        this.worker.p(250L);
        this.gui.h(string2, 2000L);
        this.worker.p(150L);
        int n2 = 0;
        for (int i = 0; i < 6 && this.worker.c(Worker::J).booleanValue() && !this.bot.g(); ++i) {
            boolean bl2 = false;
            List<class_1799> list = this.gui.R();
            for (int j = 0; j < list.size(); ++j) {
                class_1799 class_17992 = list.get(j);
                if (class_17992.method_7960() || !class_17992.method_31574(this.product.item())) continue;
                if (this.bot.g()) break;
                n2 += class_17992.method_7947();
                this.gui.P(j, 0, class_1713.field_7794);
                bl2 = true;
                this.worker.p(40L);
            }
            if (!bl2) break;
            this.worker.S(1);
        }
        this.gui.k();
        if (n2 <= 0) return n2;
        this.u(KrispyClient.body().good("Collected " + n2 + "x").text(" ").name(this.product.displayName()).text(" from your order."));
        return n2;
    }

    private long t() {
        long l;
        if (!this.product.beatTopOrder()) {
            l = this.product.fixedPrice();
        } else {
            String[] stringArray;
            double d = -1.0;
            for (int i = 1; i <= 3 && d <= 0.0; ++i) {
                this.gui.k();
                this.worker.p(i == 1 ? 800L : 1400L);
                stringArray = a;
                this.gui.T("order " + this.product.search());
                d = this.E(i == 3 ? 7000L : 4500L);
            }
            this.gui.k();
            if (d <= 0.0) {
                String string;
                stringArray = a;
                Root root = KrispyClient.body().warn("No order price found").text(" for ").name(this.product.describe());
                if (this.product.enchants().isEmpty()) {
                    string = ", trying later.";
                } else {
                    stringArray = a;
                    string = ". Use a Fixed order price for enchanted items.";
                }
                this.u(root.text(string));
                return -1L;
            }
            l = (long)Math.floor(d) + this.product.bidIncrement();
            this.u(KrispyClient.body().text("Top order is $").value(Each.t(d)).text(", ordering at $").value(Each.t(l)).text(" each."));
        }
        if (this.product.maxPrice() <= 0L) return l;
        if (l <= this.product.maxPrice()) return l;
        this.u(KrispyClient.body().text("Capped at your max price $").value(Each.t(this.product.maxPrice())).text("."));
        return this.product.maxPrice();
    }

    private double E(long l) {
        long l2 = System.currentTimeMillis() + l;
        while (System.currentTimeMillis() < l2) {
            double d = this.worker.c(this::lmbd$waitTopOrder$0);
            if (d > 0.0) {
                return d;
            }
            this.worker.p(50L);
        }
        return -1.0;
    }

    private void j(long l) {
        if (!this.A()) return;
        int n = this.worker.c(Price::lmbd$create$0);
        if (n < 0) {
            String[] stringArray = a;
            this.u(KrispyClient.body().warn("No free order slot").text(" (no New Order button)."));
            this.gui.k();
            return;
        } else {
            Component component;
            String[] stringArray;
            this.gui.P(n, 0, class_1713.field_7790);
            TextInputs textInputs = this.W(Price::lmbd$create$1, 10000L);
            if (textInputs == null) {
                String[] stringArray2 = a;
                throw Price.d("Choose Item did not open");
            }
            if (!textInputs.textInputs().isEmpty()) {
                String[] stringArray3 = new String[1];
                stringArray = a;
                stringArray3[0] = "search";
                component = textInputs.labelled(stringArray3);
                textInputs = this.P(textInputs, component, Map.of(textInputs.textInputs().get(0), this.product.search()));
            }
            if ((component = textInputs.find(this::lmbd$create$2)) == null) {
                component = this.X(textInputs);
            }
            if (component == null) {
                stringArray = a;
                throw Price.d(this.product.displayName() + " is not in the search results, " + textInputs.describe());
            }
            textInputs = this.P(textInputs, component, Map.of());
            this.H(textInputs);
            stringArray = a;
            if (textInputs.titled("enchant")) {
                textInputs = this.U(textInputs);
            } else if (!this.product.enchants().isEmpty()) {
                stringArray = a;
                throw Price.d("No enchantment menu for " + this.product.displayName() + ", " + textInputs.describe());
            }
            stringArray = a;
            if (!textInputs.titled("how many") && !textInputs.titled("amount")) {
                throw Price.d("Expected the amount menu, got " + textInputs.describe());
            }
            String[] stringArray4 = new String[2];
            stringArray = a;
            stringArray4[0] = "next";
            stringArray4[1] = "continue";
            if (!(textInputs = this.P(textInputs, textInputs.labelled(stringArray4), Price.F(textInputs, Integer.toString(this.product.orderAmount())))).titled("price")) {
                throw Price.d("Expected the price menu, got " + textInputs.describe());
            }
            String[] stringArray5 = new String[3];
            stringArray = a;
            stringArray5[0] = "review order";
            stringArray5[1] = "review";
            stringArray5[2] = "next";
            if (!(textInputs = this.P(textInputs, textInputs.labelled(stringArray5), Price.F(textInputs, Each.J(l)))).titled("review")) {
                throw Price.d("Expected the review menu, got " + textInputs.describe());
            }
            this.H(textInputs);
            String string = this.G(textInputs, l);
            if (string != null) {
                TextInputs textInputs2 = textInputs;
                String[] stringArray6 = new String[1];
                stringArray = a;
                stringArray6[0] = "cancel";
                Component component2 = textInputs2.labelled(stringArray6);
                if (component2 != null) {
                    this.worker.c(() -> Price.lmbd$create$3(textInputs2, component2));
                }
                stringArray = a;
                throw Price.d("Order review did not match (" + string + "), cancelled");
            }
            long l2 = System.currentTimeMillis();
            TextInputs textInputs3 = textInputs;
            String[] stringArray7 = new String[3];
            stringArray = a;
            stringArray7[0] = "create order";
            stringArray7[1] = "create";
            stringArray7[2] = "confirm";
            Component component3 = textInputs3.labelled(stringArray7);
            if (component3 == null) {
                throw Price.d("No Create Order button, " + textInputs3.describe());
            }
            if (!this.worker.c(() -> Price.lmbd$create$4(textInputs3, component3)).booleanValue()) {
                stringArray = a;
                throw Price.d("The review menu closed");
            }
            this.worker.K(() -> this.lmbd$create$5(l2, textInputs3), 8000L);
            this.worker.p(300L);
            this.gui.k();
            this.u(KrispyClient.body().good("Ordered " + this.product.orderAmount() + "x").text(" ").name(this.product.describe()).text(" at $").value(Each.t(l)).text(" each."));
        }
    }

    private Component X(TextInputs textInputs) {
        Component component = null;
        for (Component component2 : textInputs.buttons()) {
            if (!this.product.nameMatches(component2.label(), true) || component != null && component2.key().length() >= component.key().length()) continue;
            component = component2;
        }
        return component;
    }

    private void H(TextInputs textInputs) {
        if (textInputs.items().isEmpty()) return;
        for (class_1799 class_17992 : textInputs.items()) {
            if (!class_17992.method_31574(this.product.item())) continue;
            return;
        }
        String string = textInputs.items().get(0).method_7964().getString();
        this.worker.q(Price::lmbd$checkItem$0);
        throw Price.d("Picked " + (String)string + " instead of " + this.product.displayName() + ", cancelled");
    }

    private TextInputs U(TextInputs textInputs) {
        if (this.product.enchants().isEmpty()) {
            String[] stringArray = new String[2];
            String[] stringArray2 = a;
            stringArray[0] = "skip enchantments";
            stringArray[1] = "skip";
            return this.P(textInputs, textInputs.labelled(stringArray), Map.of());
        }
        for (Level level : this.product.enchants()) {
            String[] stringArray;
            Component component = Price.l(textInputs, level);
            if (component == null) {
                stringArray = a;
                throw Price.d(level.label() + " is not offered, " + textInputs.describe());
            }
            if (component.green()) continue;
            TextInputs textInputs2 = textInputs;
            if (!this.worker.c(() -> Price.lmbd$pickEnchants$0(textInputs2, component)).booleanValue()) {
                stringArray = a;
                throw Price.d("The menu changed before picking " + level.label());
            }
            TextInputs textInputs3 = this.W(arg_0 -> Price.lmbd$pickEnchants$1(textInputs2, arg_0), 5000L);
            if (textInputs3 == null && (textInputs3 = this.worker.c(Price::lmbd$pickEnchants$2)) == null) {
                stringArray = a;
                throw Price.d("The enchantment menu closed after picking " + level.label());
            }
            textInputs = textInputs3;
            Component component2 = Price.l(textInputs, level);
            if (component2 == null || component2.green()) continue;
            stringArray = a;
            this.u(KrispyClient.body().warn("Could not confirm ").text(level.label()).text(" was picked, continuing."));
        }
        return this.P(textInputs, textInputs.labelled("continue", "confirm", "done", "next"), Map.of());
    }

    static Component l(TextInputs textInputs, Level level) {
        String string = "";
        for (Component component : textInputs.buttons()) {
            int n = Each.s(component.label());
            if (n > 0) {
                if (!string.equals(level.key()) || n != level.level()) continue;
                return component;
            }
            if (component.label().isBlank()) continue;
            string = Each.p(Each.d(component.label()));
        }
        return null;
    }

    private String G(TextInputs textInputs, long l) {
        List<Double> list;
        for (String string : textInputs.body()) {
            if (!string.startsWith("amount") || (list = Each.a(string)).isEmpty() || !(Math.abs(list.get(0) - (double)this.product.orderAmount()) >= Each.k(string))) continue;
            return string;
        }
        for (String string : textInputs.body()) {
            double d;
            if (!string.startsWith("price") || (list = Each.a(string)).isEmpty() || !(Math.abs((d = list.get(0).doubleValue()) - (double)l) > Each.k(string))) continue;
            return string;
        }
        return null;
    }

    private static Map<String, String> F(TextInputs textInputs, String string) {
        return textInputs.textInputs().isEmpty() ? Map.of() : Map.of(textInputs.textInputs().get(0), string);
    }

    private TextInputs P(TextInputs textInputs, Component component, Map<String, String> map) {
        return this.J(textInputs, component, map, 8000L);
    }

    private TextInputs J(TextInputs textInputs, Component component, Map<String, String> map, long l) {
        if (component == null) {
            String[] stringArray = a;
            throw Price.d("Button missing, " + textInputs.describe());
        }
        if (!this.worker.c(() -> Price.lmbd$press$0(textInputs, component, map)).booleanValue()) {
            throw Price.d("The menu changed before clicking " + component.label());
        }
        TextInputs textInputs2 = this.W(arg_0 -> Price.lmbd$press$1(textInputs, arg_0), l);
        if (textInputs2 != null) return textInputs2;
        throw Price.d("No answer after clicking '" + component.label() + "'");
    }

    private TextInputs W(Predicate<TextInputs> predicate, long l) {
        long l2 = System.currentTimeMillis() + l;
        while (System.currentTimeMillis() < l2) {
            TextInputs textInputs = this.worker.c(Price::lmbd$waitDialog$0);
            if (textInputs != null && predicate.test(textInputs)) {
                return textInputs;
            }
            this.worker.p(50L);
        }
        return null;
    }

    private static TextInputs lmbd$waitDialog$0() {
        return DialogReader.C(Worker.m());
    }

    private static boolean lmbd$press$1(TextInputs textInputs, TextInputs textInputs2) {
        if (textInputs2.dialog() == textInputs.dialog()) return false;
        return true;
    }

    private static Boolean lmbd$press$0(TextInputs textInputs, Component component, Map map) {
        return DialogReader.N(Worker.m(), textInputs, component, map);
    }

    private static TextInputs lmbd$pickEnchants$2() {
        return DialogReader.C(Worker.m());
    }

    private static boolean lmbd$pickEnchants$1(TextInputs textInputs, TextInputs textInputs2) {
        if (textInputs2.dialog() == textInputs.dialog()) return false;
        return true;
    }

    private static Boolean lmbd$pickEnchants$0(TextInputs textInputs, Component component) {
        return DialogReader.N(Worker.m(), textInputs, component, Map.of());
    }

    private static void lmbd$checkItem$0() {
        DialogReader.I(Worker.m());
    }

    private boolean lmbd$create$5(long l, TextInputs textInputs) {
        if (this.bot.orderedAt >= l) return true;
        if (DialogReader.C(Worker.m()) == null) return true;
        if (DialogReader.C(Worker.m()).dialog() == textInputs.dialog()) return false;
        return true;
    }

    private static Boolean lmbd$create$4(TextInputs textInputs, Component component) {
        return DialogReader.N(Worker.m(), textInputs, component, Map.of());
    }

    private static Boolean lmbd$create$3(TextInputs textInputs, Component component) {
        return DialogReader.N(Worker.m(), textInputs, component, Map.of());
    }

    private boolean lmbd$create$2(Component component) {
        return this.product.nameMatches(component.label(), false);
    }

    private static boolean lmbd$create$1(TextInputs textInputs) {
        return textInputs.titled("item");
    }

    private static Integer lmbd$create$0() {
        return Worker.v(Price::Y, 45);
    }

    private Double lmbd$waitTopOrder$0() {
        if (!Worker.J()) {
            return -1.0;
        }
        for (class_1799 class_17992 : Worker.Q()) {
            if (class_17992.method_7960() || !class_17992.method_31574(this.product.item()) || !this.product.enchants().isEmpty() && !this.product.matches(class_17992)) continue;
            return Each.w(class_17992);
        }
        return -1.0;
    }

    private static int[] lmbd$collect$1() {
        List<class_1799> list = Worker.Q();
        int n = -1;
        for (int i = 0; i < list.size(); ++i) {
            class_1799 class_17992 = list.get(i);
            if (class_17992.method_7960()) continue;
            String string = Worker.B(class_17992);
            if (class_17992.method_31574(class_1802.field_8353) || string.contains("cancel")) {
                return new int[]{1, -1};
            }
            if (n >= 0 || !string.contains("collect")) continue;
            n = i;
        }
        if (n >= 0 || list.size() <= 13 || list.get(13).method_7960()) return new int[]{0, n};
        n = 13;
        return new int[]{0, n};
    }

    private boolean lmbd$collect$0(String string) {
        if (!Worker.J()) return false;
        if (this.C()) return false;
        if (Worker.V().equals(string)) return false;
        return true;
    }

    private Integer lmbd$run$0() {
        return Worker.v(this::lmbd$run$1, 45);
    }

    private boolean lmbd$run$1(class_1799 class_17992) {
        return class_17992.method_31574(this.product.item());
    }
}
