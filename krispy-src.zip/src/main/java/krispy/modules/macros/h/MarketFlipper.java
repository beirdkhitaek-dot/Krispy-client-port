package krispy.modules.macros.h;

import java.util.List;
import krispy.event.MacroPacketReceiveEvent;
import krispy.module.MacroCategories;
import krispy.module.MacroSubscribe;
import krispy.module.settings.MacroBoolSetting;
import krispy.module.settings.MacroEnchantSetting;
import krispy.module.settings.MacroModeSetting;
import krispy.module.settings.MacroNumberSetting;
import krispy.module.settings.MacroSetting;
import krispy.modules.macros.h.BeatTopOrder;
import krispy.modules.macros.h.Each;
import krispy.modules.macros.h.ListingDelayMs;
import krispy.modules.macros.h.Thread;
import krispy.modules.macros.h.YouOrdered;
import krispy.modules.macros.h.DialogReader;
import krispy.modules.misc.MacroModule;
import krispy.util.KrispyClient;
import krispy.util.Root;
import krispy.util.Viii;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import net.minecraft.class_7439;
import net.minecraft.class_746;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(value=EnvType.CLIENT)
public final class MarketFlipper
extends MacroModule {
    private static Logger LOGGER;
    private static final int PRODUCTS = 5;
    private static String PRICE_BEAT;
    private static String PRICE_FIXED;
    private final MacroModeSetting productSlot;
    private final MacroEnchantSetting[] items;
    private final MacroEnchantSetting[] minPrices;
    private final MacroEnchantSetting[] enchants;
    private final MacroBoolSetting[] restock;
    private final MacroEnchantSetting[] orderAmounts;
    private final MacroModeSetting[] priceModes;
    private final MacroEnchantSetting[] fixedPrices;
    private final MacroEnchantSetting[] bidIncrements;
    private final MacroEnchantSetting[] maxPrices;
    private final MacroEnchantSetting undercut;
    private final MacroNumberSetting priceCheck;
    private final MacroNumberSetting salesCheck;
    private final MacroNumberSetting perListing;
    private final MacroNumberSetting maxListings;
    private final MacroNumberSetting listingDelay;
    private final MacroNumberSetting relistGap;
    private final MacroNumberSetting ignoreDrops;
    private final MacroNumberSetting collectSlots;
    private final MacroNumberSetting orderCheck;
    private final MacroBoolSetting advanced;
    private final Thread worker;
    private volatile YouOrdered bot;
    private static String[] a;

    public MarketFlipper() {
        super("market-flipper", "Market Flipper", "Sells an item on the Auction House, undercuts other sellers and restocks through orders.", MacroCategories.DONUT_MACROS);
        int n;
        int n2;
        String[] stringArray = a;
        this.productSlot = this.addSetting("product", new MacroModeSetting("Product", "1", "1", "2", "3", "4", "5"));
        this.items = new MacroEnchantSetting[5];
        this.minPrices = new MacroEnchantSetting[5];
        this.enchants = new MacroEnchantSetting[5];
        this.restock = new MacroBoolSetting[5];
        this.orderAmounts = new MacroEnchantSetting[5];
        this.priceModes = new MacroModeSetting[5];
        this.fixedPrices = new MacroEnchantSetting[5];
        this.bidIncrements = new MacroEnchantSetting[5];
        this.maxPrices = new MacroEnchantSetting[5];
        this.advanced = this.addSetting("advanced", new MacroBoolSetting("Advanced Settings", false));
        this.worker = new Thread("Krispy Market Flipper");
        this.usesNotifications();
        for (n2 = 0; n2 < 5; ++n2) {
            MacroSetting[] macroSettingArray;
            String string;
            n = n2 + 1;
            stringArray = a;
            String string2 = "product-" + n + "-";
            stringArray = a;
            this.items[n2] = this.addSetting(string2 + "item", new MacroEnchantSetting("Item", n == 1 ? "barrel" : "").hint("e.g. barrel or diamond_chestplate").itemPicker());
            String string3 = string2 + "min-price";
            if (n == 1) {
                string = "3k";
            } else {
                stringArray = a;
                string = "1k";
            }
            stringArray = a;
            this.minPrices[n2] = this.addSetting(string3, new MacroEnchantSetting("Minimum Sell Price", string).hint("e.g. 3k"));
            this.enchants[n2] = this.addSetting(string2 + "enchants", new MacroEnchantSetting("Enchantments", "").enchantsFor(this.items[n2]));
            this.restock[n2] = this.addSetting(string2 + "restock", new MacroBoolSetting("Restock With Orders", false));
            this.orderAmounts[n2] = this.addSetting(string2 + "order-amount", new MacroEnchantSetting("Order Amount", "64").hint("e.g. 64"));
            this.priceModes[n2] = this.addSetting(string2 + "order-price", new MacroModeSetting("Order Price", "Beat Top Order", "Beat Top Order", "Fixed"));
            this.fixedPrices[n2] = this.addSetting(string2 + "fixed-price", new MacroEnchantSetting("Fixed Order Price (each)", "100").hint("e.g. 150k"));
            this.bidIncrements[n2] = this.addSetting(string2 + "bid-increment", new MacroEnchantSetting("Beat By", "1").hint("e.g. 1 or 100"));
            this.maxPrices[n2] = this.addSetting(string2 + "max-price", new MacroEnchantSetting("Maximum Buy Price", "").hint("Empty = no limit"));
            int n3 = n2;
            for (MacroSetting macroSetting : macroSettingArray = new MacroSetting[]{this.items[n2], this.minPrices[n2], this.enchants[n2], this.restock[n2], this.orderAmounts[n2], this.priceModes[n2], this.fixedPrices[n2], this.bidIncrements[n2], this.maxPrices[n2]}) {
                macroSetting.visibleWhen(() -> this.lmbd$new$0(n3));
            }
            this.enchants[n2].visibleWhen(() -> this.lmbd$new$1(n3));
            this.orderAmounts[n2].visibleWhen(() -> this.lmbd$new$2(n3));
            this.priceModes[n2].visibleWhen(() -> this.lmbd$new$3(n3));
            this.fixedPrices[n2].visibleWhen(() -> this.lmbd$new$4(n3));
            this.bidIncrements[n2].visibleWhen(() -> this.lmbd$new$5(n3));
            this.maxPrices[n2].visibleWhen(() -> this.lmbd$new$6(n3));
        }
        this.undercut = this.addSetting("undercut", new MacroEnchantSetting("Undercut By", "100").hint("e.g. 100"));
        this.priceCheck = this.addSetting("price-check", new MacroNumberSetting("Price Check (s)", 120.0f, 10.0f, 600.0f).step(10.0f));
        this.salesCheck = this.addSetting("ugjcu+encem", new MacroNumberSetting("Sales Check (s)", 20.0f, 5.0f, 300.0f).step(5.0f));
        this.perListing = this.addSetting("per-listing", new MacroNumberSetting("Items Per Listing", 1.0f, 1.0f, 64.0f).step(1.0f));
        this.maxListings = this.addSetting("max-listings", new MacroNumberSetting("Max Listings", 25.0f, 1.0f, 50.0f).step(1.0f));
        this.listingDelay = this.addSetting("listing-delay", new MacroNumberSetting("Listing Delay (s)", 0.0f, 0.0f, 5.0f).step(0.25f));
        this.relistGap = this.addSetting("relist-gap", new MacroNumberSetting("Relist Higher At (x undercut)", 3.0f, 1.0f, 20.0f).step(0.5f));
        this.ignoreDrops = this.addSetting("ignore-drops", new MacroNumberSetting("Ignore Drops Over (x undercut)", 20.0f, 1.0f, 100.0f).step(1.0f));
        this.collectSlots = this.addSetting("collect-slots", new MacroNumberSetting("Collect Up To (slots)", 18.0f, 1.0f, 36.0f).step(1.0f));
        this.orderCheck = this.addSetting("order-check", new MacroNumberSetting("Order Check (s)", 15.0f, 5.0f, 300.0f).step(5.0f));
        this.collectSlots.visibleWhen(this::w);
        this.orderCheck.visibleWhen(this::w);
        for (n2 = 0; n2 < 5; ++n2) {
            final int idx = n2;
            this.enchants[n2].visibleWhen(() -> this.lmbd$new$7(idx));
            this.priceModes[n2].visibleWhen(() -> this.lmbd$new$8(idx));
            this.fixedPrices[n2].visibleWhen(() -> this.lmbd$new$9(idx));
            this.bidIncrements[n2].visibleWhen(() -> this.lmbd$new$10(idx));
        }
        for (MacroSetting macroSetting : new MacroSetting[]{this.undercut, this.priceCheck, this.salesCheck, this.maxListings, this.listingDelay, this.relistGap, this.ignoreDrops}) {
            macroSetting.visibleWhen(this.advanced::get);
        }
        this.collectSlots.visibleWhen(this::lmbd$new$11);
        this.orderCheck.visibleWhen(this::lmbd$new$12);
        this.getSettings().remove(this.advanced.krispy());
        this.getSettings().add(this.advanced.krispy());
    }

    private int a() {
        return Integer.parseInt(this.productSlot.get()) - 1;
    }

    private boolean w() {
        return this.restock[this.a()].get();
    }

    @Override
    public boolean persistEnabled() {
        return false;
    }

    @Override
    public void onEnable() {
        class_310 class_3102 = class_310.method_1551();
        if (class_3102.field_1724 != null && class_3102.method_1548() != null) {
            String string = this.A();
            if (string != null) {
                this.W(KrispyClient.body().warn(string));
                this.requestDisable();
                return;
            } else {
                YouOrdered youOrdered;
                this.bot = youOrdered = new YouOrdered(this, this.worker, this.m(), this.M(), class_3102.method_1548().method_1676());
                this.worker.X(youOrdered::X, arg_0 -> this.lmbd$onEnable$0(class_3102, youOrdered, arg_0));
            }
            return;
        } else {
            this.W(KrispyClient.body().warn("Join a server first."));
            this.requestDisable();
        }
    }

    @Override
    public void onDisable() {
        YouOrdered youOrdered = this.bot;
        this.bot = null;
        this.worker.i();
        class_310 class_3102 = class_310.method_1551();
        class_746 class_7462 = class_3102.field_1724;
        if (youOrdered == null || class_7462 == null) return;
        if (class_7462.field_7512 != class_7462.field_7498) {
            class_7462.method_7346();
        } else {
            DialogReader.I(class_3102);
        }
        this.W(KrispyClient.body().text(youOrdered.S()));
    }

    @MacroSubscribe
    public void onMacroPacketReceive(MacroPacketReceiveEvent macroPacketReceiveEvent) {
        class_7439 class_74392;
        class_2596<?> class_25962;
        YouOrdered youOrdered = this.bot;
        if (youOrdered == null || !((class_25962 = macroPacketReceiveEvent.packet) instanceof class_7439) || (class_74392 = (class_7439)class_25962).comp_763() == null) return;
        youOrdered.p(class_74392.comp_763().getString());
    }

    private String A() {
        int n = this.a();
        class_1792 class_17922 = BeatTopOrder.resolveItem(this.items[n].get());
        if (class_17922 == null) {
            String[] stringArray = a;
            return "Product " + (n + 1) + ": unknown item '" + this.items[n].get() + "'.";
        }
        if (Each.f(this.minPrices[n].get()) <= 0L) {
            String[] stringArray = a;
            return "Product " + (n + 1) + ": Min Price must be a price like 3k.";
        }
        if (Each.f(this.undercut.get()) < 0L) {
            String[] stringArray = a;
            return "Undercut By must be a price like 100.";
        }
        if (!this.restock[n].get()) {
            return null;
        }
        if (MarketFlipper.r(this.orderAmounts[n].get()) <= 0) {
            String[] stringArray = a;
            return "Product " + (n + 1) + ": Order Amount must be a whole number.";
        }
        String[] stringArray = a;
        if (this.priceModes[n].is("Fixed") && Each.f(this.fixedPrices[n].get()) <= 0L) {
            return "Product " + (n + 1) + ": Fixed Order Price must be a price like 150k.";
        }
        stringArray = a;
        if (this.priceModes[n].is("Beat Top Order") && Each.f(this.bidIncrements[n].get()) <= 0L) {
            return "Product " + (n + 1) + ": Beat By must be a price like 1.";
        }
        if (this.maxPrices[n].get().isBlank()) return null;
        if (Each.f(this.maxPrices[n].get()) > 0L) return null;
        String string = "Product " + (n + 1) + ": Max Order Price must be empty or a price like 200k.";
        return string;
    }

    private BeatTopOrder m() {
        int n = this.a();
        class_1792 class_17922 = BeatTopOrder.resolveItem(this.items[n].get());
        long l = this.maxPrices[n].get().isBlank() ? 0L : Each.f(this.maxPrices[n].get());
        return new BeatTopOrder(class_17922, this.items[n].get().trim(), BeatTopOrder.searchText(class_17922), new class_1799((class_1935)class_17922).method_7964().getString(), Each.f(this.minPrices[n].get()), Viii.supports(class_17922) ? BeatTopOrder.parseEnchants(this.enchants[n].get()) : List.of(), this.restock[n].get(), MarketFlipper.r(this.orderAmounts[n].get()), this.priceModes[n].is("Beat Top Order"), Math.max(1L, Each.f(this.fixedPrices[n].get())), Math.max(1L, Each.f(this.bidIncrements[n].get())), Math.max(0L, l));
    }

    private ListingDelayMs M() {
        return new ListingDelayMs(Math.max(0L, Each.f(this.undercut.get())), (long)(this.priceCheck.get() * 1000.0f), (long)(this.salesCheck.get() * 1000.0f), this.perListing.getInt(), this.maxListings.getInt(), (long)(this.listingDelay.get() * 1000.0f), this.relistGap.get(), this.ignoreDrops.get(), this.collectSlots.getInt(), (long)(this.orderCheck.get() * 1000.0f));
    }

    private static int r(String string) {
        try {
            int n = Integer.parseInt(string.trim());
            if (n <= 0) return -1;
            int n2 = n;
            return n2;
        }
        catch (NumberFormatException numberFormatException) {
            return -1;
        }
    }

    private void W(Root root) {
        KrispyClient.send((MacroModule)this, root);
    }

    private void lmbd$onEnable$0(class_310 class_3102, YouOrdered youOrdered, Throwable throwable) {
        LOGGER.error("[Krispy] Market Flipper stopped", throwable);
        this.W(KrispyClient.body().danger("Urivvcb").text(": " + String.valueOf(throwable)));
        class_3102.execute(() -> this.lmbd$onEnable$1(youOrdered));
    }

    private void lmbd$onEnable$1(YouOrdered youOrdered) {
        if (this.bot != youOrdered) return;
        this.toggle(false);
    }

    private boolean lmbd$new$12() {
        if (!this.advanced.get()) return false;
        if (!this.w()) return false;
        return true;
    }

    private boolean lmbd$new$11() {
        if (!this.advanced.get()) return false;
        if (!this.w()) return false;
        return true;
    }

    private boolean lmbd$new$10(int n) {
        if (!this.advanced.get()) return false;
        if (this.a() != n) return false;
        if (!this.restock[n].get()) return false;
        if (!this.priceModes[n].is("Beat Top Order")) return false;
        return true;
    }

    private boolean lmbd$new$9(int n) {
        if (!this.advanced.get()) return false;
        if (this.a() != n) return false;
        if (!this.restock[n].get()) return false;
        if (!this.priceModes[n].is("Fixed")) return false;
        return true;
    }

    private boolean lmbd$new$8(int n) {
        if (!this.advanced.get()) return false;
        if (this.a() != n) return false;
        if (!this.restock[n].get()) return false;
        return true;
    }

    private boolean lmbd$new$7(int n) {
        if (!this.advanced.get()) return false;
        if (this.a() != n) return false;
        if (!Viii.supports(BeatTopOrder.resolveItem(this.items[n].get()))) return false;
        return true;
    }

    private boolean lmbd$new$6(int n) {
        if (this.a() != n) return false;
        if (!this.restock[n].get()) return false;
        return true;
    }

    private boolean lmbd$new$5(int n) {
        if (this.a() != n) return false;
        if (!this.restock[n].get()) return false;
        if (!this.priceModes[n].is("Beat Top Order")) return false;
        return true;
    }

    private boolean lmbd$new$4(int n) {
        if (this.a() != n) return false;
        if (!this.restock[n].get()) return false;
        if (!this.priceModes[n].is("Fixed")) return false;
        return true;
    }

    private boolean lmbd$new$3(int n) {
        if (this.a() != n) return false;
        if (!this.restock[n].get()) return false;
        return true;
    }

    private boolean lmbd$new$2(int n) {
        if (this.a() != n) return false;
        if (!this.restock[n].get()) return false;
        return true;
    }

    private boolean lmbd$new$1(int n) {
        if (this.a() != n) return false;
        if (!Viii.supports(BeatTopOrder.resolveItem(this.items[n].get()))) return false;
        return true;
    }

    private boolean lmbd$new$0(int n) {
        if (this.a() != n) return false;
        return true;
    }

    static {
        a = new String[]{"barrel", "Order Check (s)", "Minimum Sell Price", "Beat Top Order", "Market Flipper", "order-check", ": Order Amount must be a whole number.", "Item", "3k", "ignore-drops", "enchants", "Relist Higher At (x undercut)", "collect-slots", "relist-gap", "advanced", ": Min Price must be a price like 3k.", "order-price", "Listing Delay (s)", ": unknown item '", "Join a server first.", "order-amount", "e.g. 64", "Collect Up To (slots)", "Maximum Buy Price", "100", ": Beat By must be a price like 1.", ": Fixed Order Price must be a price like 150k.", "Undercut By must be a price like 100.", "listing-delay", "Krispy Market Flipper", "Ignore Drops Over (x undercut)", "Empty = no limit", "product-", ": Max Order Price must be empty or a price like 200k.", "e.g. 150k", "Advanced Settings", "Krispy", "bid-increment", "market-flipper", "e.g. barrel or diamond_chestplate", "restock", "undercut", "1k", "e.g. 1 or 100", "Order Price", "100", "Items Per Listing", "e.g. 3k", "Restock With Orders", "Undercut By", "price-check", "Sells an item on the Auction House, undercuts other sellers and restocks through orders.", "max-listings", "Product ", "item", "Order Amount", "Price Check (s)", "64", "e.g. 100", "Product ", "product", "Fixed Order Price (each)", "Sales Check (s)", "Product", ": ", "min-price", "Fixed", "fixed-price", "'.", "per-listing", "[Krispy] Market Flipper stopped", "Beat Top Order", "Enchantments", "Max Listings", "Fixed", "max-price", "Beat By", "Urivvcb", "ugjcu+encem"};
        PRICE_FIXED = a[74];
        PRICE_BEAT = a[71];
        LOGGER = LoggerFactory.getLogger("Krispy");
    }
}
