package krispy.modules.macros.h;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

@Environment(value=EnvType.CLIENT)
final class Each {
    private static Pattern FORMATTING;
    private static Pattern MONEY_EXACT;
    private static Pattern MONEY_ANY;
    private static String SMALL_CAPS;
    private static String SMALL_CAPS_PLAIN;
    private static String[] ROMAN;
    private static String[] a;

    private Each() {
    }

    static String B(String string) {
        if (string == null) {
            return "";
        }
        String string2 = FORMATTING.matcher(string).replaceAll("");
        StringBuilder stringBuilder = new StringBuilder(string2.length());
        for (int i = 0; i < string2.length(); ++i) {
            char c = string2.charAt(i);
            int n = "\u1d00\u0299\u1d04\u1d05\u1d07\ua730\u0262\u029c\u026a\u1d0a\u1d0b\u029f\u1d0d\u0274\u1d0f\u1d18\u0280\u0455\ua731\u1d1b\u1d1c\u1d20\u1d21\u028f\u1d22".indexOf(c);
            if (n >= 0) {
                stringBuilder.append("abcdefghijklmnoprsstuvwyz".charAt(n));
                continue;
            }
            if (c != '\u279c' && c != '\u2192') {
                stringBuilder.append(c);
                continue;
            }
            stringBuilder.append('-');
        }
        return stringBuilder.toString().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
    }

    static String v(class_2561 class_25612) {
        if (class_25612 == null) {
            return "";
        }
        String string = Each.B(class_25612.getString());
        return string;
    }

    static String p(String string) {
        String string2 = Each.B(string);
        StringBuilder stringBuilder = new StringBuilder(string2.length());
        for (int i = 0; i < string2.length(); ++i) {
            char c = string2.charAt(i);
            if ((c < 'a' || c > 'z') && (c < '0' || c > '9')) continue;
            stringBuilder.append(c);
        }
        return stringBuilder.toString();
    }

    static long f(String string) {
        if (string == null) {
            return -1L;
        }
        Matcher matcher = MONEY_EXACT.matcher(string.trim().toLowerCase(Locale.ROOT));
        if (!matcher.matches()) {
            return -1L;
        }
        long l = Math.round(Each.u(matcher.group(1), matcher.group(2)));
        return l;
    }

    static List<Double> a(String string) {
        ArrayList<Double> arrayList = new ArrayList<Double>();
        if (string == null) {
            return arrayList;
        }
        Matcher matcher = MONEY_ANY.matcher(Each.B(string));
        while (matcher.find()) {
            double d = Each.u(matcher.group(1), matcher.group(2));
            if (!(d > 0.0)) continue;
            arrayList.add(d);
        }
        return arrayList;
    }

    static String A(String string) {
        Matcher matcher = MONEY_ANY.matcher(Each.B(string));
        if (!matcher.find()) {
            return null;
        }
        String string2 = matcher.group(2);
        return matcher.group(1).replace(",", "") + (string2 == null ? "" : string2);
    }

    static double k(String string) {
        Matcher matcher = MONEY_ANY.matcher(Each.B(string));
        if (!matcher.find()) {
            return 1.0;
        }
        String string2 = matcher.group(1);
        int n = string2.indexOf(46);
        int n2 = n < 0 ? 0 : string2.length() - n - 1;
        return Math.max(1.0, Each.u("1", matcher.group(2)) / Math.pow(10.0, n2));
    }

    private static double u(String string, String string2) {
        double d;
        double d2;
        try {
            d2 = Double.parseDouble(string.replace(",", ""));
        }
        catch (NumberFormatException numberFormatException) {
            return -1.0;
        }
        if (string2 == null) {
            return d2;
        }
        switch (string2) {
            case "k": {
                d = d2 * 1000.0;
                return d;
            }
            case "m": {
                d = d2 * 1000000.0;
                return d;
            }
            case "b": {
                d = d2 * 1.0E9;
                return d;
            }
            default: {
                d = d2;
            }
        }
        return d;
    }

    static String J(long l) {
        if (l >= 1000000000L && l % 1000000000L == 0L) {
            return l / 1000000000L + "b";
        }
        if (l >= 1000000L && l % 1000000L == 0L) {
            return l / 1000000L + "m";
        }
        if (l < 1000000L || l % 100000L != 0L) return l >= 1000L && l % 1000L == 0L ? l / 1000L + "k" : Long.toString(l);
        return l / 1000000L + "." + l % 1000000L / 100000L + "m";
    }

    static String t(double d) {
        if (d >= 1.0E9) {
            return Each.L(d / 1.0E9) + "b";
        }
        if (!(d >= 1000000.0)) return d >= 1000.0 ? Each.L(d / 1000.0) + "k" : Long.toString(Math.round(d));
        return Each.L(d / 1000000.0) + "m";
    }

    private static String L(double d) {
        String string = String.format(Locale.ROOT, "%.2f", d);
        return string.contains(".") ? string.replaceAll("0+$", "").replaceAll("\\.$", "") : string;
    }

    static int s(String string) {
        String string2 = Each.B(string);
        for (int i = 0; i < ROMAN.length; ++i) {
            if (!ROMAN[i].equals(string2)) continue;
            return i + 1;
        }
        return 0;
    }

    static String d(String string) {
        String string2 = Each.B(string);
        int n = string2.lastIndexOf(32);
        return n > 0 && Each.s(string2.substring(n + 1)) > 0 ? string2.substring(0, n) : string2;
    }

    static List<String> R(class_1799 class_17992) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (class_2561 class_25612 : ((class_9290)class_17992.method_58695(class_9334.field_49632, (Object)class_9290.field_49340)).comp_2400()) {
            arrayList.add(class_25612.getString());
        }
        return arrayList;
    }

    static double Q(class_1799 class_17992) {
        Object object;
        List<String> list = Each.R(class_17992);
        double d = -1.0;
        for (String string : list) {
            object = Each.B(string);
            if (!((String)object).contains("price") && !((String)object).contains("cost") && !((String)object).contains("buy")) continue;
            for (double d2 : Each.a(string)) {
                if (!(d2 >= 100.0) || !(d < 0.0) && !(d2 < d)) continue;
                d = d2;
            }
        }
        if (d > 0.0) {
            return d;
        }
        for (String string : list) {
            if (!string.contains("$")) continue;
            java.util.Iterator<Double> iterator = Each.a(string).iterator();
            while (iterator.hasNext()) {
                double d3 = iterator.next();
                if (!(d3 >= 100.0) || !(d < 0.0) && !(d3 < d)) continue;
                d = d3;
            }
        }
        return d;
    }

    static double w(class_1799 class_17992) {
        Object object;
        List<String> list = Each.R(class_17992);
        double d = -1.0;
        for (String string : list) {
            object = Each.B(string);
            if (!string.contains("$") || !((String)object).contains("price") && !((String)object).contains("each") && !((String)object).contains("per item") && !((String)object).contains("pay")) continue;
            for (double d2 : Each.a(string)) {
                if (!(d2 > 0.0) || !(d < 0.0) && !(d2 < d)) continue;
                d = d2;
            }
        }
        if (d > 0.0) {
            return d;
        }
        for (String string : list) {
            List<Double> list2 = Each.a(string);
            if (!string.contains("$") || list2.isEmpty()) continue;
            return list2.get(0);
        }
        return -1.0;
    }

    static {
        ROMAN = new String[]{"i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x"};
        a = new String[]{"\\.$", "buy", "vii", "^\\$?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*([kmb])?$", "each", "vi", "%.2f", "iv", "abcdefghijklmnoprsstuvwyz", "0+$", "pay", "ix", "ii", "\u1d00\u0299\u1d04\u1d05\u1d07\ua730\u0262\u029c\u026a\u1d0a\u1d0b\u029f\u1d0d\u0274\u1d0f\u1d18\u0280\u0455\ua731\u1d1b\u1d1c\u1d20\u1d21\u028f\u1d22", "price", "\u1d00\u0299\u1d04\u1d05\u1d07\ua730\u0262\u029c\u026a\u1d0a\u1d0b\u029f\u1d0d\u0274\u1d0f\u1d18\u0280\u0455\ua731\u1d1b\u1d1c\u1d20\u1d21\u028f\u1d22", "\\s+", "iii", "\u00a7.", "price", "abcdefghijklmnoprsstuvwyz", "\\$?[ \\t]*([0-9][0-9,]*(?:\\.[0-9]+)?)[ \\t]*([kmb])?(?![a-z])", "viii", "cost", "per item"};
        SMALL_CAPS_PLAIN = a[20];
        SMALL_CAPS = a[13];
        String[] stringArray = a;
        FORMATTING = Pattern.compile(stringArray[18]);
        MONEY_EXACT = Pattern.compile(stringArray[3]);
        MONEY_ANY = Pattern.compile(stringArray[21]);
    }
}
