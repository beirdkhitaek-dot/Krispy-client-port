package krispy.modules.misc;

import krispy.client.KrispyClient;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.Setting;
import krispy.module.settings.StringSetting;
import krispy.util.SecureString;

public class NameProtect
extends Module {
    private static String[] a;
    private final StringSetting fakeName = new StringSetting("Fake Name", "Player");

    public NameProtect() {
        super(SecureString.of("Name Protect"), SecureString.of("Replaces your name with given one."), -1, Category.MISC);
        this.addSettings(new Setting[]{this.fakeName});
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    public String S() {
        String string = this.fakeName.getValue();
        if (string == null) return "Player";
        if (string.isBlank()) {
            return "Player";
        }
        String string2 = string.trim();
        return string2;
    }

    public static String O(String string) {
        if (string == null || string.isEmpty()) {
            return "";
        }
        if (KrispyClient.INSTANCE != null && KrispyClient.INSTANCE.getModuleManager() != null) {
            NameProtect nameProtect;
            return (nameProtect = (NameProtect)KrispyClient.INSTANCE.getModuleManager().getModuleByClass(NameProtect.class)) != null && nameProtect.isEnabled() ? nameProtect.S() : string;
        }
        return string;
    }

    static {
        a = new String[]{"Fake Name", "Player", "Player", "Replaces your name with given one.", "Name Protect"};
    }
}
