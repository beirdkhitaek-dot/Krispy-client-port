package krispy.modules.misc;

import krispy.client.KrispyClient;
import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.Setting;
import krispy.modules.misc.AutoEat;
import krispy.util.SecureString;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_3965;

public final class AutoMine
extends Module {
    private static String[] a;
    private final BoolSetting lockView = new BoolSetting(SecureString.of("Lock View"), true);
    private final NumberSetting pitch = new NumberSetting(SecureString.of("Pitch"), -180.0, 180.0, 0.0, 0.1);
    private final NumberSetting yaw = new NumberSetting(SecureString.of("Yaw"), -180.0, 180.0, 0.0, 0.1);

    public AutoMine() {
        super(SecureString.of("Auto Mine"), SecureString.of("Module that allows players to automatically mine"), -1, Category.MISC);
        this.addSettings(new Setting[]{this.lockView, this.pitch, this.yaw});
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        Module module;
        if (this.mc.field_1755 != null || (module = KrispyClient.INSTANCE.MODULE_MANAGER.getModuleByClass(AutoEat.class)).isEnabled() && ((AutoEat)module).k()) return;
        this.P(true);
        if (!this.lockView.getValue()) return;
        float f = this.mc.field_1724.method_36454();
        float f2 = this.mc.field_1724.method_36455();
        float f3 = this.yaw.getFloatValue();
        float f4 = this.pitch.getFloatValue();
        if (f == f3 && f2 == f4) return;
        this.mc.field_1724.method_36456(f3);
        this.mc.field_1724.method_36457(f4);
    }

    private void P(boolean bl) {
        if (this.mc.field_1724.method_6115()) return;
        if (bl && this.mc.field_1765 != null && this.mc.field_1765.method_17783() == class_239.class_240.field_1332) {
            class_2350 class_23502;
            class_3965 class_39652 = (class_3965)this.mc.field_1765;
            class_2338 class_23382 = ((class_3965)this.mc.field_1765).method_17777();
            if (this.mc.field_1687.method_8320(class_23382).method_26215() || !this.mc.field_1761.method_2902(class_23382, class_23502 = class_39652.method_17780())) return;
            this.mc.field_1724.method_6104(class_1268.field_5808);
            return;
        } else {
            this.mc.field_1761.method_2925();
        }
    }

    static {
        a = new String[]{"Yaw", "Module that allows players to automatically mine", "Auto Mine", "Pitch", "Lock View"};
    }
}
