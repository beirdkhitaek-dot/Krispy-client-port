package krispy.modules.misc;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import krispy.event.AttackBlockEvent;
import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.Setting;
import krispy.modules.misc.Score;
import krispy.util.SecureString;
import krispy.util.InventoryUtil;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1820;
import net.minecraft.class_2202;
import net.minecraft.class_2211;
import net.minecraft.class_2338;
import net.minecraft.class_2397;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3489;

public final class AutoTool
extends Module {
    private static String[] a;
    private static final int MANUAL_GRACE_MS = 450;
    private static final int MAX_SWITCHES = 10;
    private static final int SWITCH_WINDOW_MS = 4000;
    private final BoolSetting legit = new BoolSetting(SecureString.of("Legit"), false).setDescription(SecureString.of("Adds human-like delay, hold time, variation and switch limits"));
    private final BoolSetting antiBreak = new BoolSetting(SecureString.of("Anti Break"), true);
    private final NumberSetting antiBreakPercentage = new NumberSetting(SecureString.of("Anti Break Percentage"), 1.0, 100.0, 5.0, 1.0);
    private final Deque<Long> switchTimes = new ArrayDeque<Long>();
    private int pendingSlot = -1;
    private class_2338 pendingBlock;
    private long switchAt;
    private long nextSwitchAllowedAt;
    private long lastManualChangeAt;
    private int lastObservedSlot = -1;
    private int lastAutomaticSlot = -1;

    public AutoTool() {
        super(SecureString.of("Auto Tool"), SecureString.of("Automatically switches to the best tool"), -1, Category.MISC);
        this.addSettings(new Setting[]{this.legit, this.antiBreak, this.antiBreakPercentage});
    }

    @Override
    public void onEnable() {
        this.I();
        if (this.mc.field_1724 != null) {
            this.lastObservedSlot = this.mc.field_1724.method_31548().method_67532();
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.I();
        super.onDisable();
    }

    private void I() {
        this.pendingSlot = -1;
        this.pendingBlock = null;
        this.switchAt = 0L;
        this.nextSwitchAllowedAt = 0L;
        this.lastManualChangeAt = 0L;
        this.lastObservedSlot = -1;
        this.lastAutomaticSlot = -1;
        this.switchTimes.clear();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            this.pendingSlot = -1;
            this.pendingBlock = null;
            return;
        }
        long l = System.currentTimeMillis();
        int n = this.mc.field_1724.method_31548().method_67532();
        if (this.lastObservedSlot == -1) {
            this.lastObservedSlot = n;
        }
        if (n != this.lastObservedSlot) {
            if (n != this.lastAutomaticSlot) {
                this.lastManualChangeAt = l;
                this.pendingSlot = -1;
                this.pendingBlock = null;
            }
            this.lastObservedSlot = n;
            this.lastAutomaticSlot = -1;
        }
        while (!this.switchTimes.isEmpty() && l - this.switchTimes.peekFirst() > 4000L) {
            this.switchTimes.removeFirst();
        }
        if (!this.legit.getValue() || this.pendingSlot < 0) {
            return;
        }
        if (this.mc.field_1755 != null || !this.mc.field_1690.field_1886.method_1434() || this.pendingBlock == null) {
            this.pendingSlot = -1;
            this.pendingBlock = null;
            return;
        }
        if (l < this.switchAt || l < this.nextSwitchAllowedAt || l - this.lastManualChangeAt < 450L) {
            return;
        }
        if (this.switchTimes.size() >= 10 || this.mc.field_1687.method_8320(this.pendingBlock).method_26215()) {
            this.pendingSlot = -1;
            this.pendingBlock = null;
            return;
        }
        this.w(this.pendingSlot, l);
        this.pendingSlot = -1;
        this.pendingBlock = null;
    }

    @Subscribe
    public void onAttackBlock(AttackBlockEvent attackBlockEvent) {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
            return;
        }
        class_2680 class_26802 = this.mc.field_1687.method_8320(attackBlockEvent.pos);
        class_1799 class_17992 = this.mc.field_1724.method_6047();
        if (this.g(class_17992) && AutoTool.D(class_17992)) {
            this.mc.field_1690.field_1886.method_23481(false);
            this.pendingSlot = -1;
            this.pendingBlock = null;
            attackBlockEvent.cancel();
            return;
        }
        Score score = this.T(class_26802, this.legit.getValue());
        if (score.slot() < 0) {
            return;
        }
        double d = AutoTool.E(class_17992, class_26802, this::lmbd$handleAttackBlockEvent$0);
        if (score.slot() == this.mc.field_1724.method_31548().method_67532() || !this.M(d, score.score())) {
            return;
        }
        if (!this.legit.getValue()) {
            this.w(score.slot(), System.currentTimeMillis());
            return;
        }
        long l = System.currentTimeMillis();
        if (l - this.lastManualChangeAt < 450L || l < this.nextSwitchAllowedAt) {
            return;
        }
        if (ThreadLocalRandom.current().nextDouble() < 0.03) {
            return;
        }
        this.pendingSlot = score.slot();
        this.pendingBlock = attackBlockEvent.pos.method_10062();
        int n = ThreadLocalRandom.current().nextInt(30, 76);
        int n2 = ThreadLocalRandom.current().nextInt(55, 126);
        this.switchAt = l + (long)n + (long)n2;
    }

    private Score T(class_2680 class_26802, boolean bl) {
        int n;
        int[] nArray = new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8};
        if (bl) {
            ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();
            for (n = nArray.length - 1; n > 0; --n) {
                int n2 = threadLocalRandom.nextInt(n + 1);
                int n3 = nArray[n];
                nArray[n] = nArray[n2];
                nArray[n2] = n3;
            }
        }
        int n4 = -1;
        n = -1;
        double d = -1.0;
        double d2 = -1.0;
        for (int n5 : nArray) {
            double d3 = AutoTool.E(this.mc.field_1724.method_31548().method_5438(n5), class_26802, this::lmbd$findBestChoice$1);
            if (d3 > d) {
                n = n4;
                d2 = d;
                n4 = n5;
                d = d3;
                continue;
            }
            if (!(d3 > d2)) continue;
            n = n5;
            d2 = d3;
        }
        if (!bl || n < 0 || !(d > 0.0) || !(d2 / d >= 0.92) || !(ThreadLocalRandom.current().nextDouble() < 0.12)) return new Score(n4, d);
        return new Score(n, d2);
    }

    private boolean M(double d, double d2) {
        if (d2 < 0.0) {
            return false;
        }
        if (d < 0.0) {
            return true;
        }
        if (!this.legit.getValue()) {
            if (!(d2 > d)) return false;
            return true;
        }
        if (d2 <= 0.0) {
            return false;
        }
        if (d / d2 >= 0.96) {
            return false;
        }
        if (!(d2 >= d * 1.08)) return false;
        return true;
    }

    private void w(int n, long l) {
        if (n < 0 || n > 8 || this.mc.field_1724 == null) {
            return;
        }
        InventoryUtil.swap(n);
        this.lastAutomaticSlot = n;
        this.lastObservedSlot = n;
        this.switchTimes.addLast(l);
        this.nextSwitchAllowedAt = l + (long)ThreadLocalRandom.current().nextInt(95, 221);
    }

    public static double E(class_1799 class_17992, class_2680 class_26802, Predicate<class_1799> predicate) {
        boolean bl;
        if (!predicate.test(class_17992)) return -1.0;
        if (!AutoTool.D(class_17992)) {
            return -1.0;
        }
        boolean bl2 = class_17992.method_41409().method_40220(class_3489.field_42611) && (class_26802.method_26204() instanceof class_2211 || class_26802.method_26204() instanceof class_2202);
        boolean bl3 = bl = class_17992.method_7909() instanceof class_1820 && class_26802.method_26204() instanceof class_2397;
        if (!(class_17992.method_7951(class_26802) || bl2 || bl)) {
            if (!class_26802.method_26164(class_3481.field_15481)) return -1.0;
        }
        boolean bl4 = true;
        boolean bl5 = bl4;
        if (!bl5) return -1.0;
        double d = class_17992.method_7924(class_26802) * 1000.0f;
        return d;
    }

    public static boolean D(class_1799 class_17992) {
        return AutoTool.t(class_17992.method_7909());
    }

    public static boolean t(class_1792 class_17922) {
        if (class_17922.method_40131().method_40220(class_3489.field_42612)) return true;
        if (class_17922.method_40131().method_40220(class_3489.field_42613)) return true;
        if (class_17922.method_40131().method_40220(class_3489.field_42614)) return true;
        if (class_17922.method_40131().method_40220(class_3489.field_42615)) return true;
        if (!(class_17922 instanceof class_1820)) return false;
        return true;
    }

    private boolean g(class_1799 class_17992) {
        if (!this.antiBreak.getValue()) return false;
        if (!class_17992.method_7963()) return false;
        if (class_17992.method_7936() - class_17992.method_7919() >= class_17992.method_7936() * this.antiBreakPercentage.getIntValue() / 100) return false;
        return true;
    }

    private boolean lmbd$findBestChoice$1(class_1799 class_17992) {
        if (this.g(class_17992)) return false;
        return true;
    }

    private boolean lmbd$handleAttackBlockEvent$0(class_1799 class_17992) {
        if (this.g(class_17992)) return false;
        return true;
    }

    static {
        a = new String[]{"Legit", "Adds human-like delay, hold time, variation and switch limits", "Anti Break Percentage", "Auto Tool", "Automatically switches to the best tool", "Anti Break"};
    }
}
