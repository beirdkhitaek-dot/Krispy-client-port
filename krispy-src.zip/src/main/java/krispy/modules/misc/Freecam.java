package krispy.modules.misc;

import krispy.cinematic.InputLocked;
import krispy.client.KrispyClient;
import krispy.event.KeyEvent;
import krispy.event.MarkClosedEvent;
import krispy.event.MouseButtonEvent;
import krispy.event.MouseScrollEvent;
import krispy.event.ScreenOpenEvent;
import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.mixin.SetMovementVECTORMixin;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.Setting;
import krispy.modules.misc.Freelook;
import krispy.util.SecureString;
import krispy.util.Unknown2;
import krispy.util.FileUtil;
import net.minecraft.class_10185;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import net.minecraft.class_638;
import net.minecraft.class_744;
import net.minecraft.class_746;
import org.joml.Vector3d;
import org.joml.Vector3dc;

public final class Freecam
extends Module {
    private static String[] a;
    private static final double MIN_SPEED = 0.01;
    private static final double MAX_SCROLL_SPEED = 12.0;
    private static final double ACCELERATION = 12.0;
    private static final double SCROLL_STEP = 0.25;
    private final NumberSetting speed = new NumberSetting(SecureString.of("Speed"), 0.01, 50.0, 1.0, 0.1);
    private final NumberSetting scrollSensitivity = new NumberSetting(SecureString.of("Scroll Sensitivity"), 0.0, 5.0, 1.0, 0.1);
    private final BoolSetting keepWalking = new BoolSetting(SecureString.of("Keep Walking"), false);
    private final BoolSetting keepJumping = new BoolSetting(SecureString.of("Keep Jumping"), false);
    private final BoolSetting keepSneaking = new BoolSetting(SecureString.of("Keep Sneaking"), false);
    public final Vector3d currentPosition = new Vector3d();
    public final Vector3d previousPosition = new Vector3d();
    private final Vector3d smoothedVelocity = new Vector3d();
    private class_5498 savedPerspective;
    private class_746 attachedPlayer;
    private class_638 attachedWorld;
    private boolean cameraActive;
    private boolean savedChunkCulling;
    private float savedPlayerYaw;
    private float savedPlayerPitch;
    private class_10185 lockedInput = class_10185.field_54098;
    private class_241 lockedMovementVector = class_241.field_1340;
    private boolean lockedSprinting;
    private double movementSpeed;
    private long lastMovementNanos;
    public float yaw;
    public float pitch;
    public float previousYaw;
    public float previousPitch;
    private boolean isMovingForward;
    private boolean isMovingBackward;
    private boolean isMovingRight;
    private boolean isMovingLeft;
    private boolean isMovingUp;
    private boolean isMovingDown;

    public Freecam() {
        super(SecureString.of("Freecam"), SecureString.of("Moves the camera independently from the real player"), -1, Category.MISC);
        this.addSettings(new Setting[]{this.speed, this.scrollSensitivity, this.keepWalking, this.keepJumping, this.keepSneaking});
    }

    @Override
    public void onEnable() {
        if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
            Freelook freelook = (Freelook)KrispyClient.INSTANCE.getModuleManager().getModuleByClass(Freelook.class);
            if (freelook != null && freelook.isEnabled()) {
                freelook.toggle(false);
            }
            this.attachedPlayer = this.mc.field_1724;
            this.attachedWorld = this.mc.field_1687;
            this.cameraActive = true;
            this.savedPerspective = this.mc.field_1690.method_31044();
            this.mc.field_1730 = this.savedChunkCulling = this.mc.field_1730;
            this.savedPlayerYaw = this.mc.field_1724.method_36454();
            this.savedPlayerPitch = this.mc.field_1724.method_36455();
            this.yaw = this.savedPlayerYaw;
            this.pitch = this.savedPlayerPitch;
            if (this.savedPerspective == class_5498.field_26666) {
                this.yaw += 180.0f;
                this.pitch = -this.pitch;
            }
            class_243 class_2432 = this.mc.field_1773.method_19418().method_71156();
            FileUtil.copyVector(this.currentPosition, class_2432);
            FileUtil.copyVector(this.previousPosition, class_2432);
            this.previousYaw = this.yaw;
            this.previousPitch = this.pitch;
            this.smoothedVelocity.zero();
            this.movementSpeed = this.speed.getValue();
            this.lastMovementNanos = System.nanoTime();
            this.lockedInput = this.mc.field_1724.field_3913.field_54155;
            this.lockedMovementVector = this.mc.field_1724.field_3913.method_3128();
            this.lockedSprinting = this.mc.field_1724.method_5624();
            this.isMovingForward = this.mc.field_1690.field_1894.method_1434();
            this.isMovingBackward = this.mc.field_1690.field_1881.method_1434();
            this.isMovingRight = this.mc.field_1690.field_1849.method_1434();
            this.isMovingLeft = this.mc.field_1690.field_1913.method_1434();
            this.isMovingUp = this.mc.field_1690.field_1903.method_1434();
            this.isMovingDown = this.mc.field_1690.field_1832.method_1434();
            this.O();
            super.onEnable();
            return;
        } else {
            this.toggle(false);
        }
    }

    @Override
    public void onDisable() {
        if (!this.cameraActive) return;
        this.cameraActive = false;
        this.J();
        if (this.savedPerspective != null) {
            this.mc.field_1690.method_31043(this.savedPerspective);
        }
        this.mc.field_1730 = this.savedChunkCulling;
        if (this.mc.field_1724 != null && this.mc.field_1724 == this.attachedPlayer) {
            this.mc.field_1724.field_3913.field_54155 = class_10185.field_54098;
            ((SetMovementVECTORMixin)this.mc.field_1724.field_3913).krispy$setMovementVector(class_241.field_1340);
            this.mc.field_1724.method_5660(false);
        }
        this.lockedInput = class_10185.field_54098;
        this.lockedMovementVector = class_241.field_1340;
        this.lockedSprinting = false;
        this.attachedPlayer = null;
        this.attachedWorld = null;
        this.savedPerspective = null;
        this.previousPosition.set((Vector3dc)this.currentPosition);
        this.previousYaw = this.yaw;
        this.previousPitch = this.pitch;
        class_304.method_1424();
        super.onDisable();
    }

    private void O() {
        this.mc.field_1690.field_1894.method_23481(false);
        this.mc.field_1690.field_1881.method_23481(false);
        this.mc.field_1690.field_1849.method_23481(false);
        this.mc.field_1690.field_1913.method_23481(false);
        this.mc.field_1690.field_1903.method_23481(false);
        this.mc.field_1690.field_1832.method_23481(false);
    }

    private void J() {
        this.isMovingLeft = false;
        this.isMovingRight = false;
        this.isMovingBackward = false;
        this.isMovingForward = false;
        this.isMovingDown = false;
        this.isMovingUp = false;
        this.smoothedVelocity.zero();
    }

    @Subscribe
    private void onScreenOpen(ScreenOpenEvent screenOpenEvent) {
        this.J();
        this.O();
    }

    @Subscribe
    private void onTick(TickEvent tickEvent) {
        if (this.mc.field_1724 == this.attachedPlayer && this.mc.field_1687 == this.attachedWorld && this.mc.field_1724 != null && this.mc.field_1687 != null) {
            if (this.mc.field_1690.method_31044().method_31034()) return;
            this.mc.field_1690.method_31043(class_5498.field_26664);
            return;
        } else {
            this.toggle(false);
        }
    }

    public void d(class_744 class_7442) {
        class_10185 class_101852;
        if (!this.isEnabled() || !this.cameraActive || this.mc.field_1724 != this.attachedPlayer || this.mc.field_1687 != this.attachedWorld || class_7442 != this.mc.field_1724.field_3913 || InputLocked.inputLocked()) return;
        class_7442.field_54155 = class_101852 = Freecam.s(this.lockedInput, this.keepWalking.getValue(), this.keepJumping.getValue(), this.keepSneaking.getValue(), this.lockedSprinting);
        ((SetMovementVECTORMixin)class_7442).krispy$setMovementVector(this.keepWalking.getValue() ? this.lockedMovementVector : class_241.field_1340);
        this.mc.field_1724.method_5728(class_101852.comp_3165());
        this.mc.field_1724.method_5660(class_101852.comp_3164());
    }

    static class_10185 s(class_10185 class_101852, boolean bl, boolean bl2, boolean bl3, boolean bl4) {
        return new class_10185(bl && class_101852.comp_3159(), bl && class_101852.comp_3160(), bl && class_101852.comp_3161(), bl && class_101852.comp_3162(), bl2 && class_101852.comp_3163(), bl3 & class_101852.comp_3164(), bl && bl4 && !(bl3 & class_101852.comp_3164()));
    }

    public void T() {
        if (!this.isEnabled() || !this.cameraActive || this.mc.field_1724 != this.attachedPlayer || this.mc.field_1687 != this.attachedWorld) return;
        if (this.mc.field_1755 != null || InputLocked.inputLocked()) {
            this.J();
            this.lastMovementNanos = System.nanoTime();
            this.previousPosition.set((Vector3dc)this.currentPosition);
            return;
        }
        this.previousPosition.set((Vector3dc)this.currentPosition);
        this.previousYaw = this.yaw;
        this.previousPitch = this.pitch;
        long l = System.nanoTime();
        double d = class_3532.method_15350((double)((double)(l - this.lastMovementNanos) / 1.0E9), 0.001, 0.1);
        this.lastMovementNanos = l;
        double d2 = Math.toRadians(this.yaw);
        double d3 = -Math.sin(d2);
        double d4 = Math.cos(d2);
        double d5 = -Math.cos(d2);
        double d6 = -Math.sin(d2);
        double d7 = class_3532.method_15350((double)this.movementSpeed, 0.01, 12.0) * 4.0;
        if (this.mc.field_1690.field_1867.method_1434()) {
            d7 *= 2.0;
        }
        double d8 = 0.0;
        double d9 = 0.0;
        double d10 = 0.0;
        if (this.isMovingForward) {
            d8 += d3 * d7;
            d10 += d4 * d7;
        }
        if (this.isMovingBackward) {
            d8 -= d3 * d7;
            d10 -= d4 * d7;
        }
        if (this.isMovingRight) {
            d8 += d5 * d7;
            d10 += d6 * d7;
        }
        if (this.isMovingLeft) {
            d8 -= d5 * d7;
            d10 -= d6 * d7;
        }
        if (this.isMovingUp) {
            d9 += d7;
        }
        if (this.isMovingDown) {
            d9 -= d7;
        }
        double d11 = 1.0 - Math.exp(-12.0 * d);
        this.smoothedVelocity.x = class_3532.method_16436((double)d11, (double)this.smoothedVelocity.x, (double)d8);
        this.smoothedVelocity.y = class_3532.method_16436((double)d11, (double)this.smoothedVelocity.y, (double)d9);
        this.smoothedVelocity.z = class_3532.method_16436((double)d11, (double)this.smoothedVelocity.z, (double)d10);
        this.currentPosition.add(this.smoothedVelocity.x * d, this.smoothedVelocity.y * d, this.smoothedVelocity.z * d);
    }

    @Subscribe
    private void onKey(KeyEvent keyEvent) {
        if (this.mc.field_1755 != null) return;
        if (InputLocked.inputLocked()) return;
        if (Unknown2.isKeyPressed(292)) return;
        boolean bl = true;
        class_11908 class_119082 = new class_11908(keyEvent.key, 0, 0);
        if (this.mc.field_1690.field_1894.method_1417(class_119082)) {
            this.isMovingForward = keyEvent.mode != 0;
        } else if (this.mc.field_1690.field_1881.method_1417(class_119082)) {
            this.isMovingBackward = keyEvent.mode != 0;
        } else if (this.mc.field_1690.field_1849.method_1417(class_119082)) {
            this.isMovingRight = keyEvent.mode != 0;
        } else if (this.mc.field_1690.field_1913.method_1417(class_119082)) {
            this.isMovingLeft = keyEvent.mode != 0;
        } else if (this.mc.field_1690.field_1903.method_1417(class_119082)) {
            this.isMovingUp = keyEvent.mode != 0;
        } else {
            if (!this.mc.field_1690.field_1832.method_1417(class_119082)) return;
            this.isMovingDown = keyEvent.mode != 0;
        }
        if (!bl) return;
        this.O();
        keyEvent.cancel();
    }

    @Subscribe
    private void onMouseButton(MouseButtonEvent mouseButtonEvent) {
        if (this.mc.field_1755 != null) return;
        if (InputLocked.inputLocked()) return;
        boolean bl = true;
        class_11909 class_119092 = new class_11909(0.0, 0.0, new class_11910(mouseButtonEvent.button, 0));
        if (this.mc.field_1690.field_1894.method_1433(class_119092)) {
            this.isMovingForward = mouseButtonEvent.actions != 0;
        } else if (this.mc.field_1690.field_1881.method_1433(class_119092)) {
            this.isMovingBackward = mouseButtonEvent.actions != 0;
        } else if (this.mc.field_1690.field_1849.method_1433(class_119092)) {
            this.isMovingRight = mouseButtonEvent.actions != 0;
        } else if (this.mc.field_1690.field_1913.method_1433(class_119092)) {
            this.isMovingLeft = mouseButtonEvent.actions != 0;
        } else if (this.mc.field_1690.field_1903.method_1433(class_119092)) {
            this.isMovingUp = mouseButtonEvent.actions != 0;
        } else {
            if (!this.mc.field_1690.field_1832.method_1433(class_119092)) return;
            this.isMovingDown = mouseButtonEvent.actions != 0;
        }
        if (!bl) return;
        this.O();
        mouseButtonEvent.cancel();
    }

    @Subscribe
    private void onMouseScroll(MouseScrollEvent mouseScrollEvent) {
        if (this.mc.field_1755 != null || mouseScrollEvent.amount == 0.0) return;
        double d = this.scrollSensitivity.getValue();
        if (d > 0.0) {
            double d2 = class_3532.method_15350((double)Math.abs(mouseScrollEvent.amount), 0.25, 8.0);
            double d3 = Math.pow(1.0 + 0.25 * d, d2);
            this.movementSpeed = mouseScrollEvent.amount > 0.0 ? class_3532.method_15350((double)(this.movementSpeed * d3), 0.01, 12.0) : class_3532.method_15350((double)(this.movementSpeed / d3), 0.01, 12.0);
        }
        mouseScrollEvent.cancel();
    }

    @Subscribe
    private void onMarkClosed(MarkClosedEvent markClosedEvent) {
        markClosedEvent.cancel();
    }

    public void k(double d, double d2) {
        this.previousYaw = this.yaw;
        this.previousPitch = this.pitch;
        this.yaw = class_3532.method_15393((float)(this.yaw + (float)d));
        this.pitch = class_3532.method_15363((float)(this.pitch + (float)d2), -90.0f, 90.0f);
    }

    public double F(float f) {
        return class_3532.method_16436((double)f, (double)this.previousPosition.x, (double)this.currentPosition.x);
    }

    public double t(float f) {
        return class_3532.method_16436((double)f, (double)this.previousPosition.y, (double)this.currentPosition.y);
    }

    public double n(float f) {
        return class_3532.method_16436((double)f, (double)this.previousPosition.z, (double)this.currentPosition.z);
    }

    public double A(float f) {
        return class_3532.method_16439((float)f, (float)this.previousYaw, (float)this.yaw);
    }

    public double e(float f) {
        return class_3532.method_16439((float)f, (float)this.previousPitch, (float)this.pitch);
    }

    static {
        a = new String[]{"Keep Jumping", "Freecam", "Speed", "Keep Walking", "Keep Sneaking", "Scroll Sensitivity", "Moves the camera independently from the real player"};
    }
}
