package krispy.modules.misc;

import java.util.concurrent.CompletableFuture;
import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.KeybindSetting;
import krispy.module.settings.Setting;
import krispy.module.settings.StringSetting;
import krispy.util.DiscordWebhookURL;
import krispy.util.SecureString;
import krispy.util.Unknown2;
import net.minecraft.class_2338;
import net.minecraft.class_2561;

public final class CordSnapper
extends Module {
    private final KeybindSetting activateKey = new KeybindSetting(SecureString.of("Activate Key"), -1, false);
    private final StringSetting webhookUrl = new StringSetting(SecureString.of("Discord Webhook"), "");
    private boolean wasPressed;
    private static final String[] a = new String[]{"Activate Key", "Discord Webhook", "Sends your current coordinates to a Discord webhook", " Z: ", "\u00a7aCord Snapper: coordinates sent.", "Krispy coordinates\nDimension: ", "\nX: ", "Krispy Cord Snapper: ", "Cord Snapper", " Y: ", "\u00a7cCord Snapper failed: "};

    public CordSnapper() {
        super(SecureString.of("Cord Snapper"), SecureString.of("Sends your current coordinates to a Discord webhook"), -1, Category.MISC);
        this.addSettings(new Setting[]{this.activateKey, this.webhookUrl});
    }

    @Override
    public void onEnable() {
        this.wasPressed = false;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.wasPressed = false;
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null || this.activateKey.getValue() < 0) {
            return;
        }
        boolean bl = Unknown2.isKeyPressed(this.activateKey.getValue());
        if (bl && !this.wasPressed) {
            this.o();
        }
        this.wasPressed = bl;
    }

    private void o() {
        class_2338 class_23382 = this.mc.field_1724.method_24515();
        String string = this.mc.field_1687.method_27983().method_29177().toString();
        int n = class_23382.method_10260();
        int n2 = class_23382.method_10264();
        int n3 = class_23382.method_10263();
        String string2 = string;
        String string3 = "Krispy coordinates\nDimension: " + string2 + "\nX: " + n3 + " Y: " + n2 + " Z: " + n;
        String string4 = this.webhookUrl.getValue();
        CompletableFuture.runAsync(() -> this.lmbd$sendCoordinates$0(string3, string4));
    }

    private void C(String string) {
        this.mc.execute(() -> this.lmbd$showStatus$1(string));
    }

    private static String f(Throwable throwable) {
        String string = throwable.getMessage();
        if (string == null || string.isBlank()) {
            return throwable.getClass().getSimpleName();
        }
        if (string.length() <= 160) return string;
        return string.substring(0, 160) + "\u2026";
    }

    private void lmbd$showStatus$1(String string) {
        if (this.mc.field_1724 == null) return;
        this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)string), false);
    }

    private void lmbd$sendCoordinates$0(String string, String string2) {
        try {
            DiscordWebhookURL discordWebhookURL = new DiscordWebhookURL(string2);
            discordWebhookURL.a(string);
            discordWebhookURL.execute();
            this.C("\u00a7aCord Snapper: coordinates sent.");
            return;
        }
        catch (Throwable throwable) {
            System.err.println("Krispy Cord Snapper: " + throwable.getMessage());
            this.C("\u00a7cCord Snapper failed: " + CordSnapper.f(throwable));
        }
    }
}
