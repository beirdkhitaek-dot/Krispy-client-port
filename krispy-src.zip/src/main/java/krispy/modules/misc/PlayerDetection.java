package krispy.modules.misc;

import java.awt.Color;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.Setting;
import krispy.module.settings.StringSetting;
import krispy.util.DiscordWebhookURL;
import krispy.util.SecureString;
import krispy.util.Title;
import net.minecraft.class_1657;
import net.minecraft.class_2561;

public final class PlayerDetection
extends Module {
    private final BoolSetting notifications = new BoolSetting(SecureString.of("Chat Alerts"), true);
    private final StringSetting whitelist = new StringSetting(SecureString.of("Whitelist"), "FreeCamera").setDescription(SecureString.of("Comma-separated player names to ignore"));
    private final BoolSetting disconnect = new BoolSetting(SecureString.of("Disconnect"), true);
    private final BoolSetting disableOnDetect = new BoolSetting(SecureString.of("Disable On Detect"), true);
    private final BoolSetting stopBaritone = new BoolSetting(SecureString.of("Stop Baritone"), true);
    private final BoolSetting webhook = new BoolSetting(SecureString.of("Webhook"), false);
    private final StringSetting webhookUrl = new StringSetting(SecureString.of("Discord Webhook"), "");
    private final BoolSetting panicPay = new BoolSetting(SecureString.of("Panic Pay"), false);
    private final StringSetting panicPayTarget = new StringSetting(SecureString.of("Panic Pay Target"), "");
    private final StringSetting panicPayAmount = new StringSetting(SecureString.of("Panic Pay Amount"), "");
    private final Set<String> detectedPlayers = new HashSet<String>();
    private int scanDelay;
    private static final String[] a = new String[]{"\u00a7c[Player Detection] Webhook URL is empty.", "Comma-separated player names to ignore", "Disconnect", "Panic Pay Amount", "Player(s) detected: ", ", ", "Discord Webhook", "Panic Pay Target", "Alerts and optionally disconnects when another player enters view", "#stop", "Disable On Detect", "Server", "FreeCamera", "Player(s) detected: ", "freecamera", "Krispy Player Detection webhook failed: ", "pay ", "Player Detection", "Chat Alerts", "\u00a7c[Player Detection] \u00a7fPlayer(s) detected: \u00a7e", "Whitelist", "Panic Pay", "[,;\\s]+", "Player Detection Alert", "Stop Baritone", "Webhook", "Single Player"};

    public PlayerDetection() {
        super(SecureString.of("Player Detection"), SecureString.of("Alerts and optionally disconnects when another player enters view"), -1, Category.MISC);
        this.addSettings(new Setting[]{this.notifications, this.whitelist, this.disconnect, this.disableOnDetect, this.stopBaritone, this.webhook, this.webhookUrl, this.panicPay, this.panicPayTarget, this.panicPayAmount});
    }

    @Override
    public void onEnable() {
        this.detectedPlayers.clear();
        this.scanDelay = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.detectedPlayers.clear();
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
            this.detectedPlayers.clear();
            return;
        }
        if (this.scanDelay++ > 0 && this.scanDelay < 10) {
            return;
        }
        this.scanDelay = 0;
        Set<String> set = this.i();
        HashSet<String> hashSet = new HashSet<String>();
        for (class_1657 class_16572 : this.mc.field_1687.method_18456()) {
            String string;
            if (class_16572 == this.mc.field_1724 || class_16572.method_31481() || set.contains((string = class_16572.method_5477().getString()).toLowerCase(Locale.ROOT))) continue;
            hashSet.add(string);
        }
        HashSet hashSet2 = new HashSet(hashSet);
        hashSet2.removeAll(this.detectedPlayers);
        this.detectedPlayers.clear();
        this.detectedPlayers.addAll(hashSet);
        if (hashSet2.isEmpty()) return;
        this.V(hashSet2);
    }

    private Set<String> i() {
        HashSet<String> hashSet = new HashSet<String>();
        hashSet.add("freecamera");
        Arrays.stream(this.whitelist.getValue().split("[,;\\s]+")).map(PlayerDetection::lmbd$parseWhitelist$0).filter(PlayerDetection::lmbd$parseWhitelist$1).forEach(hashSet::add);
        return hashSet;
    }

    private void V(Set<String> set) {
        String[] stringArray = a;
        String string = String.join((CharSequence)", ", set);
        if (this.notifications.getValue()) {
            this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)("\u00a7c[Player Detection] \u00a7fPlayer(s) detected: \u00a7e" + string)), false);
        }
        if (this.stopBaritone.getValue() && this.mc.method_1562() != null) {
            this.mc.method_1562().method_45729("#stop");
        }
        if (this.panicPay.getValue() && this.mc.method_1562() != null && !this.panicPayTarget.getValue().isBlank() && !this.panicPayAmount.getValue().isBlank()) {
            this.mc.method_1562().method_45730("pay " + this.panicPayTarget.getValue().trim() + " " + this.panicPayAmount.getValue().trim());
        }
        if (this.webhook.getValue()) {
            this.g(string);
        }
        if (this.disableOnDetect.getValue()) {
            this.toggle(false);
        }
        if (!this.disconnect.getValue()) return;
        CompletableFuture.delayedExecutor(500L, TimeUnit.MILLISECONDS).execute(() -> this.lmbd$handleDetection$3(string));
    }

    private void g(String string) {
        String string2 = this.webhookUrl.getValue();
        if (string2.isBlank()) {
            if (!this.notifications.getValue()) return;
            this.mc.field_1724.method_7353((class_2561)class_2561.method_43470((String)"\u00a7c[Player Detection] Webhook URL is empty."), false);
            return;
        }
        String string3 = this.mc.method_1558() == null ? "Single Player" : this.mc.method_1558().field_3761;
        CompletableFuture.runAsync(() -> PlayerDetection.lmbd$sendWebhook$4(string2, string, string3));
    }

    private static void lmbd$sendWebhook$4(String string, String string2, String string3) {
        try {
            DiscordWebhookURL discordWebhookURL = new DiscordWebhookURL(string);
            discordWebhookURL.addEmbed(new Title().setTitle("Player Detection Alert").setDescription("Player(s) detected: " + string2).setColor(new Color(231, 76, 60)).addField("Server", string3, true));
            discordWebhookURL.execute();
            return;
        }
        catch (Throwable throwable) {
            System.err.println("Krispy Player Detection webhook failed: " + throwable.getMessage());
        }
    }

    private void lmbd$handleDetection$3(String string) {
        this.mc.execute(() -> this.lmbd$handleDetection$2(string));
    }

    private void lmbd$handleDetection$2(String string) {
        if (this.mc.method_1562() == null) return;
        this.mc.method_1562().method_48296().method_10747((class_2561)class_2561.method_43470((String)("Player(s) detected: " + string)));
    }

    private static boolean lmbd$parseWhitelist$1(String string) {
        if (string.isBlank()) return false;
        return true;
    }

    private static String lmbd$parseWhitelist$0(String string) {
        return string.trim().toLowerCase(Locale.ROOT);
    }
}
