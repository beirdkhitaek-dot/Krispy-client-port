package krispy.modules.misc;

import krispy.event.ItemUseReturnEvent;
import krispy.event.Subscribe;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.Setting;
import krispy.util.SecureString;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1811;
import net.minecraft.class_9334;

public class FastPlace
extends Module {
    private static String[] a;
    private final BoolSetting onlyXP = new BoolSetting("Only XP", false);
    private final BoolSetting allowBlocks = new BoolSetting("Blocks", true);
    private final BoolSetting allowItems = new BoolSetting("Items", true);
    private final NumberSetting useDelay = new NumberSetting("Delay", 0.0, 10.0, 0.0, 1.0);

    public FastPlace() {
        super(SecureString.of("Fast Place"), SecureString.of("Spams use action."), -1, Category.MISC);
        this.addSettings(new Setting[]{this.onlyXP, this.allowBlocks, this.allowItems, this.useDelay});
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onItemUseReturn(ItemUseReturnEvent itemUseReturnEvent) {
        class_1799 class_17992 = this.mc.field_1724.method_6047();
        class_1799 class_17993 = this.mc.field_1724.method_6079();
        class_1792 class_17922 = class_17992.method_7909();
        class_1792 class_17923 = this.mc.field_1724.method_6079().method_7909();
        if (!class_17992.method_31574(class_1802.field_8287) && !class_17993.method_31574(class_1802.field_8287) && this.onlyXP.getValue()) return;
        if (!this.onlyXP.getValue() && (!(class_17922 instanceof class_1747) && !(class_17923 instanceof class_1747) ? !this.allowItems.getValue() : !this.allowBlocks.getValue())) {
            return;
        }
        if (class_17992.method_58694(class_9334.field_50075) != null || class_17993.method_58694(class_9334.field_50075) != null || class_17992.method_31574(class_1802.field_23141) || class_17992.method_31574(class_1802.field_8801) || class_17993.method_31574(class_1802.field_23141) || class_17993.method_31574(class_1802.field_8801) || class_17922 instanceof class_1811 || class_17923 instanceof class_1811) return;
        itemUseReturnEvent.cooldown = this.useDelay.getIntValue();
    }

    static {
        a = new String[]{"Delay", "Fast Place", "Only XP", "Items", "Blocks", "Spams use action."};
    }
}
