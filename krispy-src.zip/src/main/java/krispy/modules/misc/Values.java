package krispy.modules.misc;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.ColorSetting;
import krispy.module.settings.ModeSetting;
import krispy.module.settings.NumberSetting;
import krispy.module.settings.RangeSetting;
import krispy.module.settings.Setting;

public abstract class Values
extends Module {
    private final Map<String, Setting> values = new LinkedHashMap<String, Setting>();

    protected Values(String string, Category category, String string2) {
        super(string, string2, -1, category);
    }

    protected final <T extends Setting> T define(T t) {
        this.values.put(t.getName().toString(), t);
        this.addSetting(t);
        return t;
    }

    protected final void number(String string, double d, double d2, double d3, double d4) {
        this.define(new NumberSetting(string, d2, d3, d, d4));
    }

    protected final void bool(String string, boolean bl) {
        this.define(new BoolSetting(string, bl));
    }

    protected final void choice(String string, String string2, String ... stringArray) {
        this.define(new ModeSetting(string, string2, List.of(stringArray)));
    }

    protected final void range(String string, double d, double d2, double d3, double d4, double d5) {
        this.define(new RangeSetting(string, d, d2, d3, d4, d5));
    }

    public final <T> T getSetting(String string, T t) {
        Object object;
        boolean bl = string.endsWith("_lo");
        boolean bl2 = string.endsWith("_hi");
        Setting setting = this.values.get(bl || bl2 ? string.substring(0, string.length() - 3) : string);
        Object object2 = t;
        if (setting instanceof BoolSetting) {
            object = (BoolSetting)((Object)setting);
            object2 = ((BoolSetting)((Object)object)).getValue();
        } else if (setting instanceof ModeSetting) {
            ModeSetting modeSetting = (ModeSetting)setting;
            object2 = modeSetting.getMode();
        } else if (setting instanceof ColorSetting) {
            ColorSetting colorSetting = (ColorSetting)setting;
            object2 = colorSetting.getArgb();
        } else if (setting instanceof NumberSetting) {
            NumberSetting numberSetting = (NumberSetting)setting;
            object2 = numberSetting.getValue();
        } else if (setting instanceof RangeSetting) {
            RangeSetting rangeSetting = (RangeSetting)setting;
            object2 = bl ? rangeSetting.getCurrentMin() : rangeSetting.getCurrentMax();
        }
        if (!(object2 instanceof Number)) return (T)object2;
        object = (Number)object2;
        if (t instanceof Integer) {
            object2 = ((Number)object).intValue();
            return (T)object2;
        } else if (t instanceof Float) {
            object2 = Float.valueOf(((Number)object).floatValue());
            return (T)object2;
        } else if (t instanceof Long) {
            object2 = ((Number)object).longValue();
            return (T)object2;
        } else {
            if (!(t instanceof Double)) return (T)object2;
            object2 = ((Number)object).doubleValue();
        }
        return (T)object2;
    }

    public void onTick() {
    }
}
