package krispy.modules.misc;

import java.util.Locale;
import krispy.client.KrispyClient;
import krispy.event.PacketSendEvent;
import krispy.event.Subscribe;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.BoolSetting;
import krispy.module.settings.Setting;
import krispy.modules.donut.FakeScoreboard;
import krispy.util.SecureString;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_3417;
import net.minecraft.class_5250;
import net.minecraft.class_7472;
import net.minecraft.class_9449;

public final class FakePay
extends Module {
    private final BoolSetting sound = new BoolSetting(SecureString.of("Sound"), true);
    private final BoolSetting actionBar = new BoolSetting(SecureString.of("Action Bar"), true);
    private final BoolSetting removeFromScoreboard = new BoolSetting(SecureString.of("Remove From Fake Scoreboard"), false).setDescription(SecureString.of("Subtracts every fake payment from Fake Scoreboard's money amount"));
    private static final String[] a = new String[]{"Action Bar", "Fakes /pay instead of sending it", "Sound", "Subtracts every fake payment from Fake Scoreboard's money amount", "%.2f", "You paid ", "0+$", "\\s+", "\\.$", " $", "Remove From Fake Scoreboard", "pay", "Fake Pay"};

    public FakePay() {
        super(SecureString.of("Fake Pay"), SecureString.of("Fakes /pay instead of sending it"), -1, Category.MISC);
        this.addSettings(new Setting[]{this.sound, this.actionBar, this.removeFromScoreboard});
    }

    @Subscribe
    public void onPacketSend(PacketSendEvent packetSendEvent) {
        String string = null;
        class_2596<?> class_25962 = packetSendEvent.packet;
        if (class_25962 instanceof class_7472) {
            class_7472 class_74722 = (class_7472)class_25962;
            string = class_74722.comp_808();
        } else {
            class_25962 = packetSendEvent.packet;
            if (class_25962 instanceof class_9449) {
                class_9449 class_94492 = (class_9449)class_25962;
                string = class_94492.comp_2532();
            }
        }
        if (string == null || !this.V(string)) return;
        packetSendEvent.cancel();
    }

    private boolean V(String string) {
        FakeScoreboard fakeScoreboard;
        if (this.mc.field_1724 == null) {
            return false;
        }
        String[] stringArray = a;
        String[] stringArray2 = string.trim().split("\\s+");
        if (stringArray2.length < 3 || !"pay".equals(stringArray2[0].toLowerCase(Locale.ROOT))) {
            return false;
        }
        Double d = FakePay.a(stringArray2[2]);
        if (d == null || !Double.isFinite(d) || d <= 0.0) {
            return false;
        }
        class_5250 class_52502 = class_2561.method_43470((String)"You paid ").method_27692(class_124.field_1080).method_10852((class_2561)class_2561.method_43470((String)stringArray2[1]).method_27692(class_124.field_1075)).method_10852((class_2561)class_2561.method_43470((String)(" $" + FakePay.q(d))).method_27692(class_124.field_1060)).method_10852((class_2561)class_2561.method_43470((String)".").method_27692(class_124.field_1080));
        this.mc.field_1724.method_7353((class_2561)class_52502, false);
        if (this.actionBar.getValue()) {
            this.mc.field_1724.method_7353((class_2561)class_52502.method_27661(), true);
        }
        if (this.sound.getValue()) {
            this.mc.field_1724.method_5783(class_3417.field_15224, 1.0f, 1.0f);
        }
        if (!this.removeFromScoreboard.getValue() || (fakeScoreboard = (FakeScoreboard)KrispyClient.INSTANCE.getModuleManager().getModuleByClass(FakeScoreboard.class)) == null) return true;
        fakeScoreboard.b(d);
        return true;
    }

    private static Double a(String string) {
        if (string == null) {
            return null;
        }
        String string2 = string.trim().replace(",", "").replace("$", "").toUpperCase(Locale.ROOT);
        double d = 1.0;
        if (string2.endsWith("K")) {
            d = 1000.0;
            string2 = string2.substring(0, string2.length() - 1);
        } else if (string2.endsWith("M")) {
            d = 1000000.0;
            string2 = string2.substring(0, string2.length() - 1);
        } else if (string2.endsWith("B")) {
            d = 1.0E9;
            string2 = string2.substring(0, string2.length() - 1);
        } else if (string2.endsWith("T")) {
            d = 1.0E12;
            string2 = string2.substring(0, string2.length() - 1);
        }
        try {
            return Double.parseDouble(string2) * d;
        }
        catch (NumberFormatException numberFormatException) {
            return null;
        }
    }

    private static String q(double d) {
        if (d >= 1.0E12) {
            return FakePay.c(d / 1.0E12) + "T";
        }
        if (d >= 1.0E9) {
            return FakePay.c(d / 1.0E9) + "B";
        }
        if (d >= 1000000.0) {
            return FakePay.c(d / 1000000.0) + "M";
        }
        if (!(d >= 1000.0)) return FakePay.c(d);
        return FakePay.c(d / 1000.0) + "K";
    }

    private static String c(double d) {
        if (Math.rint(d) != d) return String.format(Locale.ROOT, "%.2f", d).replaceAll("0+$", "").replaceAll("\\.$", "");
        return Long.toString((long)d);
    }
}
