package krispy.modules.misc;

import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.CycleSetting;
import krispy.module.settings.RangeSetting;
import krispy.module.settings.Setting;
import krispy.module.settings.StringSetting;
import krispy.modules.misc.Tpahere;
import krispy.util.SecureString;
import net.minecraft.class_634;

public final class AutoTpa
extends Module {
    private static String[] a;
    private final RangeSetting delayRange = new RangeSetting(SecureString.of("Delay"), 1.0, 80.0, 1.0, 10.0, 30.0);
    private final CycleSetting<Tpahere> mode = new CycleSetting<Tpahere>(SecureString.of("Mode"), Tpahere.TPAHERE, Tpahere.class);
    private final StringSetting playerName = new StringSetting(SecureString.of("Player"), "DrDonutt");
    private int delayCounter;

    public AutoTpa() {
        super(SecureString.of("Auto Tpa"), SecureString.of("Module that helps you teleport streamers to you"), -1, Category.MISC);
        this.addSettings(new Setting[]{this.mode, this.delayRange, this.playerName});
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.delayCounter > 0) {
            --this.delayCounter;
            return;
        } else {
            class_634 class_6342 = this.mc.method_1562();
            String string = this.mode.getValue().equals((Object)Tpahere.TPA) ? "tpa " : "tpahere ";
            class_6342.method_45730(string + this.playerName.getValue());
            this.delayCounter = this.delayRange.getRandomIntInRange();
        }
    }

    static {
        a = new String[]{"DrDonutt", "Mode", "Delay", "Module that helps you teleport streamers to you", "Player", "Auto Tpa"};
    }
}
