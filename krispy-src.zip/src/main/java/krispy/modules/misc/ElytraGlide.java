package krispy.modules.misc;

import krispy.event.ItemUseHeadEvent;
import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.module.Category;
import krispy.module.Module;
import krispy.util.SecureString;
import krispy.util.InventoryUtil;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public final class ElytraGlide
extends Module {
    private static String[] a;
    private boolean isFlyingTriggered;
    private boolean isFireworkUsed;
    private boolean isJumpKeyPressed;

    public ElytraGlide() {
        super(SecureString.of("Elytra Glide"), SecureString.of("Starts flying when attempting to use a firework"), -1, Category.MISC);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.mc.field_1755 != null) return;
        if (this.isJumpKeyPressed) {
            this.isJumpKeyPressed = false;
            class_304.method_1416((class_3675.class_306)this.mc.field_1690.field_1903.method_1429(), (boolean)false);
            return;
        } else {
            if (!this.isFlyingTriggered) return;
            if (this.isFireworkUsed) {
                int n = this.mc.field_1724.method_31548().method_67532();
                if (!this.mc.field_1724.method_6047().method_31574(class_1802.field_8639) && !InventoryUtil.swap(class_1802.field_8639)) {
                    return;
                }
                this.mc.field_1761.method_2919((class_1657)this.mc.field_1724, this.mc.field_1724.method_6058());
                this.mc.field_1724.method_31548().method_61496(n);
                this.isFireworkUsed = false;
                this.isFlyingTriggered = false;
                return;
            } else if (this.mc.field_1724.method_24828()) {
                class_304.method_1416((class_3675.class_306)this.mc.field_1690.field_1903.method_1429(), (boolean)true);
                this.isJumpKeyPressed = true;
                return;
            } else {
                class_304.method_1416((class_3675.class_306)this.mc.field_1690.field_1903.method_1429(), (boolean)true);
                this.isJumpKeyPressed = true;
                this.isFireworkUsed = true;
            }
        }
    }

    @Subscribe
    public void onItemUseHead(ItemUseHeadEvent itemUseHeadEvent) {
        if (!this.mc.field_1724.method_6047().method_31574(class_1802.field_8639) || !this.mc.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833) || !this.mc.field_1724.method_6128()) return;
        this.isFlyingTriggered = true;
    }

    static {
        a = new String[]{"Starts flying when attempting to use a firework", "Elytra Glide"};
    }
}
