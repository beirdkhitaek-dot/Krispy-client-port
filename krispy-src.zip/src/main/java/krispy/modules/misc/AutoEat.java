package krispy.modules.misc;

import krispy.event.Subscribe;
import krispy.event.TickEvent;
import krispy.mixin.InvokeDOItemUseMixin;
import krispy.module.Category;
import krispy.module.Module;
import krispy.module.settings.NumberSetting;
import krispy.util.SecureString;
import krispy.util.InventoryUtil;
import net.minecraft.class_4174;
import net.minecraft.class_9334;

public final class AutoEat
extends Module {
    private static String[] a;
    private final NumberSetting healthThreshold = new NumberSetting(SecureString.of("Health Threshold"), 0.0, 19.0, 17.0, 1.0);
    private final NumberSetting hungerThreshold = new NumberSetting(SecureString.of("Hunger Threshold"), 0.0, 19.0, 19.0, 1.0);
    public boolean isEa;
    private int selectedFoodSlot;
    private int previousSelectedSlot;

    public AutoEat() {
        super(SecureString.of("Auto Eat"), SecureString.of(" It detects whenever the hungerbar/health falls a certain threshold, selects food in your hotbar, and starts eating."), -1, Category.MISC);
        this.addSettings(this.healthThreshold, this.hungerThreshold);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onTick(TickEvent tickEvent) {
        if (this.isEa) {
            if (this.k()) {
                if (this.mc.field_1724.method_31548().method_5438(this.selectedFoodSlot).method_58694(class_9334.field_50075) != null) {
                    int n = this.U();
                    if (n == -1) {
                        this.I();
                        return;
                    }
                    this.G(n);
                }
                this.i();
                return;
            } else {
                this.I();
            }
            return;
        } else {
            if (!this.k()) return;
            this.selectedFoodSlot = this.U();
            if (this.selectedFoodSlot == -1) return;
            this.j();
        }
    }

    public boolean k() {
        boolean bl = this.mc.field_1724.method_6032() <= (float)this.healthThreshold.getIntValue();
        boolean bl2 = this.mc.field_1724.method_7344().method_7586() <= this.hungerThreshold.getIntValue();
        if (this.U() == -1) return false;
        if (bl) return true;
        if (!bl2) return false;
        return true;
    }

    private int U() {
        int n = -1;
        int n2 = -1;
        for (int i = 0; i < 9; ++i) {
            int n3;
            class_4174 class_41742 = (class_4174)this.mc.field_1724.method_31548().method_5438(i).method_58694(class_9334.field_50075);
            if (class_41742 == null || (n3 = class_41742.comp_2491()) <= n2) continue;
            n = i;
            n2 = n3;
        }
        return n;
    }

    private void j() {
        this.previousSelectedSlot = this.mc.field_1724.method_31548().method_67532();
        this.i();
    }

    private void i() {
        this.G(this.selectedFoodSlot);
        this.X(true);
        if (!this.mc.field_1724.method_6115()) {
            ((InvokeDOItemUseMixin)this.mc).invokeDoItemUse();
        }
        this.isEa = true;
    }

    private void I() {
        this.G(this.previousSelectedSlot);
        this.X(false);
        this.isEa = false;
    }

    private void X(boolean bl) {
        this.mc.field_1690.field_1904.method_23481(bl);
    }

    private void G(int n) {
        InventoryUtil.swap(n);
        this.selectedFoodSlot = n;
    }

    static {
        a = new String[]{"Auto Eat", "Hunger Threshold", " It detects whenever the hungerbar/health falls a certain threshold, selects food in your hotbar, and starts eating.", "Health Threshold"};
    }
}
